# PSC Multi-Source Degradation Learning — v0.1 → v0.8

Reproducible evolution repository for heterogeneous-data learning of perovskite solar-cell ageing.

## What this repository is

This repository keeps **every model version v0.1–v0.8**, the code used by that version, the real-data training outputs, and a GitHub Actions matrix that retrains all versions independently. The central external evaluation task is prediction of the **fully held-out 25 °C Accelerated-v2 domain** from higher-temperature training devices.

Raw Hartono / Accelerated / Chakar archives are intentionally not committed. The repository contains the derived, compact processed data required for the version-comparison workflows. Rebuilding the processed data from raw sources remains available inside the later version folders when the raw files are supplied locally.

## Version history

| Version | Main question / change | Representative N=12 RMSE @ held-out 25 °C |
|---|---|---:|
| v0.1 | Frozen Hartono prior + residual GP | 0.1577 ± 0.0297 |
| v0.2 | Adaptive multi-source prior prototype | 0.1955 ± 0.0021 |
| v0.3 | Direct + mediated + full source-factor graph | 0.1170 ± 0.0072 |
| v0.4 | Automatic source/path auditor | 0.1283 ± 0.0286* |
| v0.5 | Safe path-level multiple-kernel fusion | 0.1235 ± 0.0253 |
| v0.6 | Adaptive context granularity | **0.1077 ± 0.0184** |
| v0.7 | Optional diffraction structural expert | **0.1077 ± 0.0184**† |
| v0.8 | Shared/private stage-specific experts | 0.1097 ± 0.0272 |

\* v0.4 is an auditor, not one fixed predictor; this number is the mean of the two candidate-source audit roles and must not be interpreted as a clean leaderboard entry.  
† No real diffraction source is currently supplied, so the v0.7 safety property requires it to collapse exactly to v0.6.

![Version RMSE comparison](results/figures/version_rmse_comparison.png)

The comparison is an **evolution audit**, not evidence that version number should monotonically improve test error. In particular v0.2 is intentionally retained because its negative-transfer failure motivated v0.3–v0.6.

## Repository layout

```text
versions/
  v0.1/ ... v0.8/     historical code snapshots + version results
benchmark/
  run_version.sh       one-version reproducible runner
  run_all_versions.sh  local sequential runner
  aggregate_results.py version comparison table/figure
data/processed/         compact real-data derived inputs used by CI
results/
  tables/version_comparison.csv
  figures/version_rmse_comparison.png
.github/workflows/
  train-all-versions.yml
```

`v0.3` has no surviving standalone ZIP archive. Its directory is explicitly marked as a reconstruction from the v0.4 archive retaining only the v0.3-era scripts/modules/results. See `versions/v0.3/RECONSTRUCTION_NOTE.md`.

## Reproduce locally

```bash
python -m pip install -r requirements.txt
./benchmark/run_all_versions.sh
```

Or one version:

```bash
./benchmark/run_version.sh v0.6
python benchmark/aggregate_results.py
```

## GitHub Actions

Open **Actions → train-all-versions → Run workflow**. The workflow launches eight independent matrix jobs:

```text
v0.1 v0.2 v0.3 v0.4 v0.5 v0.6 v0.7 v0.8
```

Each job uploads its CSV/PNG results as an artifact. A final comparison job downloads all artifacts and regenerates:

- `results/tables/version_comparison.csv`
- `results/VERSION_COMPARISON.md`
- `results/figures/version_rmse_comparison.png`

## Scientific comparison rules

1. **25 °C remains external** to model/path/granularity/stage selection.
2. Train/test sampling is at parent-device level rather than pixel-row level.
3. Failed versions are retained; results are not selected based on the 25 °C test score.
4. v0.4 is identified as a source auditor rather than disguised as a single predictive model.
5. v0.7 cannot claim a diffraction benefit until a real diffraction source is supplied.
6. v0.8's stage-specific local gains do not justify claiming it globally outperforms v0.6.

See `results/VERSION_COMPARISON.md` for the current aggregate table.
