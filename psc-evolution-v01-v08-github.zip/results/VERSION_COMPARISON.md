# v0.1–v0.8 representative comparison

> Important: this table is an evolution audit, not a perfectly controlled leaderboard. v0.4 is an auditor rather than one predictor; v0.7 intentionally equals v0.6 when diffraction data are missing. All entries use the fully held-out 25 °C domain and N=12 where the historical version permits it.

| version   | representative_model         |   train_devices |   rmse_25C |    std | note                                                                          |   rank |   improvement_vs_v01_pct |
|:----------|:-----------------------------|----------------:|-----------:|-------:|:------------------------------------------------------------------------------|-------:|-------------------------:|
| v0.1      | frozen Hartono prior + GP    |              12 |     0.1577 | 0.0297 | exact historical predictor; rerun at N=12                                     |      7 |                   0.0000 |
| v0.2      | adaptive source prior + GP   |              12 |     0.1955 | 0.0021 | quick run uses available v0.2 seeds                                           |      8 |                 -23.9520 |
| v0.3      | full source-factor graph     |              12 |     0.1170 | 0.0072 | diagnostic-era predictor                                                      |      4 |                  25.8299 |
| v0.4      | automatic source auditor     |              12 |     0.1283 | 0.0286 | mean across Hartono-as-C and Chakar-as-C audits; not a single final predictor |      6 |                  18.6766 |
| v0.5      | safe path-MKL fusion         |              12 |     0.1235 | 0.0253 | directional transfer-CV safety blend                                          |      5 |                  21.7140 |
| v0.6      | adaptive granularity         |              12 |     0.1077 | 0.0184 | coarse-to-fine context alignment                                              |      1 |                  31.7158 |
| v0.7      | optional diffraction expert  |              12 |     0.1077 | 0.0184 | no diffraction source present: must reduce to v0.6                            |      1 |                  31.7158 |
| v0.8      | shared/private stage experts |              12 |     0.1097 | 0.0272 | prototype stage model; local gains but not globally best                      |      3 |                  30.4466 |
