# v0.8 — Shared–Specific Stage Experts

v0.8 separates heterogeneous-source knowledge into a **shared latent** and **source-private residuals**. The shared latent is usable throughout ageing. Private residuals can only act through one of three smooth stage experts. Stage boundaries are selected from source/target training data by directional lower-temperature transfer CV; 25 C remains external audit only.

This avoids two opposite errors: forcing all source-specific information to be globally transferable, and manually hard-coding arbitrary early/mid/late intervals. Soft gates prevent discontinuities at change points.

The current transparent implementation uses the mean of standardized Hartono/Chakar/Chakar-stress factors as the shared latent and residual-to-mean components as private features. This is deliberately interpretable. A later version may replace this with learned shared/private encoders plus orthogonality/independence penalties.

## Relevant literature and what is borrowed
- Domain Separation Networks (Bousmalis et al., NeurIPS 2016): explicit shared/private representations motivate separating transferable common factors from source-specific residuals.
- Zhong, Pan & Lei (AISTATS 2025), *Bridging Domains with Approximately Shared Features*: argues that approximately shared features can be more useful than requiring strict invariance, supporting a soft shared/private split rather than binary common/specific labeling.
- Two-phase GP degradation models and recent adaptive multistage sparse GPR work: motivate learning change points/regimes and allowing stage-dependent degradation functions rather than a single global law.
- Adaptive multi-scale feature fusion + adaptive MoE for RUL/health tasks (RESS 2024; ESWA 2025) and AttMoE (J. Energy Storage 2024): motivate shared representation plus expert routing rather than one monolithic predictor.

v0.8 differs in the combination: heterogeneous scientific source factors are split into shared/private components, private information is stage-gated, stage boundaries are selected using extrapolation-oriented validation, and the entire construction is evaluated on PSC ageing cross-temperature transfer rather than standard in-domain RUL interpolation.
