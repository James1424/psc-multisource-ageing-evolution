"""v0.8 shared-general + stage-specific heterogeneous source learning.

External 25 C is never used for stage boundary, path, ridge, or blend selection.
"""
from pathlib import Path
import argparse,warnings
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.adaptive_granularity import fit_adaptive_granularity,predict_adaptive_granularity
from psc_prior_al.stage_shared_specific import fit_stage_shared_specific,predict_stage_shared_specific
warnings.filterwarnings('ignore')

def thin(df,maxn=6):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h');i=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int));out.append(g.iloc[i])
    return pd.concat(out,ignore_index=True)

def rmse(y,p):return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))

def stage_rmse(test,p,bounds):
    # recompute within-device normalized progress
    u=np.zeros(len(test))
    for _,idx in test.groupby(['temperature_c','sample_id']).indices.items():
        ii=np.asarray(idx);t=test.iloc[ii].time_h.to_numpy(float);u[ii]=t/max(t.max(),1.)
    b1,b2=bounds
    stages=np.where(u<b1,1,np.where(u<b2,2,3));return {f'stage{k}_rmse':rmse(test.retention.to_numpy()[stages==k],np.asarray(p)[stages==k]) for k in (1,2,3) if np.any(stages==k)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,default=3);ap.add_argument('--quick',action='store_true');a=ap.parse_args()
    c=load_config('configs/default.yaml');root=Path('.');proc=resolve(root,c['paths']['processed']);res=resolve(root,c['paths']['results']);res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz');hp=joblib.load(proc/'hartono_pca.joblib');cs=pd.read_csv(proc/'chakar_daily_shape.csv');cstress=pd.read_csv(proc/'chakar_stress_shape.csv');ea=float(c['model']['arrhenius_ea_ev_prior']);hold=float(c['benchmark']['holdout_temperature_c'])
    test=thin(d[d.temperature_c==hold]);pool=d[d.temperature_c!=hold];groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rows=[];wrows=[]
    for n in [6,12,24]:
      for seed in range(a.seeds):
        rng=np.random.default_rng(seed);ch=groups.iloc[rng.choice(len(groups),n,replace=False)];tr=thin(pool.merge(ch,on=['temperature_c','sample_id']))
        # v0.6 reference
        f6=fit_adaptive_granularity(tr,hp,cs,cstress,ea_ev=ea,maxiter=12 if a.quick else 18)
        p6,pbase,_=predict_adaptive_granularity(tr,test,f6,hp,cs,cstress,ea_ev=ea)
        fs=fit_stage_shared_specific(tr,hp,cs,cstress,ea_ev=ea, boundary_grid=((0.30,0.65),(0.30,0.70),(0.35,0.70)) if a.quick else ((0.25,0.60),(0.25,0.70),(0.30,0.65),(0.30,0.70),(0.35,0.70),(0.35,0.75)), ridge_grid=(0.03,) if a.quick else (0.01,0.03,0.08), maxiter=7 if a.quick else 18)
        ps,p0,_=predict_stage_shared_specific(tr,test,fs,hp,cs,cstress,ea_ev=ea)
        for name,p in [('target_only',p0),('v06_adaptive_granularity',p6),('v08_stage_shared_specific',ps)]:
            rr={'train_devices':n,'seed':seed,'model':name,'rmse_25C':rmse(test.retention,p),'b1':fs.bounds[0],'b2':fs.bounds[1]};rr.update(stage_rmse(test,p,fs.bounds));rows.append(rr)
        wrows.append({'train_devices':n,'seed':seed,'b1':fs.bounds[0],'b2':fs.bounds[1],'gamma':fs.gamma,'activated':float(fs.activated),'cv_rmse':fs.cv_rmse,'baseline_cv_rmse':fs.baseline_cv_rmse,**{f'w_{k}':v for k,v in fs.weight_dict().items()}})
    out=pd.DataFrame(rows);out.to_csv(res/'stage_shared_specific_v08.csv',index=False);wt=pd.DataFrame(wrows);wt.to_csv(res/'stage_shared_specific_weights_v08.csv',index=False)
    summ=out.groupby(['train_devices','model']).agg(rmse=('rmse_25C','mean'),std=('rmse_25C','std'),stage1=('stage1_rmse','mean'),stage2=('stage2_rmse','mean'),stage3=('stage3_rmse','mean')).reset_index();summ.to_csv(res/'stage_shared_specific_v08_summary.csv',index=False)
    ws=wt.groupby('train_devices').mean(numeric_only=True).reset_index();ws.to_csv(res/'stage_shared_specific_weights_v08_summary.csv',index=False)
    print('\nExternal 25C audit')
    print(summ.round(4).to_string(index=False))
    print('\nLearned stage boundaries/path weights')
    print(ws.round(4).to_string(index=False))
if __name__=='__main__':main()
