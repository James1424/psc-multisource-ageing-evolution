from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Tuple, Iterable
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .adaptive_granularity import factor_matrix, _device_keys, _group_rmse, _cv_folds

# factor_matrix columns: log_time, B, progress, log_stress, H, C, Cs


def _rbf(a,b,cols,ell=1.0):
    aa=a[:,list(cols)]/np.asarray(ell if np.ndim(ell) else [ell]*len(cols),float)
    bb=b[:,list(cols)]/np.asarray(ell if np.ndim(ell) else [ell]*len(cols),float)
    d2=np.sum((aa[:,None,:]-bb[None,:,:])**2,axis=-1)
    return np.exp(-0.5*d2)


def shared_private_features(x: np.ndarray):
    """Build explicit shared and private source features without using target labels.

    Source columns H,C,Cs are standardized source-derived factors.  We use their mean as a
    simple shared latent and source residuals as private components.  This is intentionally
    transparent; a learned linear subspace can replace it later without changing the API.
    """
    s=x[:,4:7]
    shared=np.mean(s,axis=1,keepdims=True)
    private=s-shared
    # [log_time,B,progress,log_stress, shared, Hpriv,Cpriv,Cspriv]
    return np.c_[x[:,:4],shared,private]


def stage_membership(u: np.ndarray,b1: float,b2: float,width: float=0.07):
    """Three smooth stage gates summing to one."""
    u=np.asarray(u,float)
    sig=lambda z:1.0/(1.0+np.exp(-np.clip(z,-40,40)))
    s1=sig((b1-u)/width)
    s3=sig((u-b2)/width)
    s2=np.clip(1.0-s1-s3,0.0,1.0)
    z=np.c_[s1,s2,s3]
    z=z/np.clip(z.sum(axis=1,keepdims=True),1e-12,None)
    return z


def kernels(x,y,bounds=(0.30,0.70),width=0.07):
    """Shared + stage-private kernels.

    The shared branch may transfer across all stages. Private source residuals are visible only
    through a stage gate, so stage-specific information cannot contaminate unrelated periods.
    """
    xp=shared_private_features(x); yp=shared_private_features(y)
    # base physical kernel + shared source consensus
    Kbase=_rbf(xp,yp,(0,1),(1.0,1.0))
    Kshared=_rbf(xp,yp,(4,),(1.0,)) * _rbf(xp,yp,(2,),(1.0,))
    gx=stage_membership(x[:,2],*bounds,width=width)
    gy=stage_membership(y[:,2],*bounds,width=width)
    out={'base':Kbase,'shared':Kshared}
    # stage-private expert sees all private residuals + stress; stage gate localizes usage
    for k in range(3):
        gate=gx[:,k,None]*gy[None,:,k]
        kpriv=_rbf(xp,yp,(5,6,7),(1.0,1.0,1.0))
        kphys=_rbf(xp,yp,(1,3),(1.2,0.9))
        out[f'private_stage{k+1}']=gate*kpriv*kphys
        # stage-local shared refinement permits same common feature to have different response
        out[f'shared_stage{k+1}']=gate*_rbf(xp,yp,(4,1),(1.0,1.0))
    return out

PATHS=('base','shared','private_stage1','private_stage2','private_stage3','shared_stage1','shared_stage2','shared_stage3')
COMPLEX=np.asarray([0.0,0.001,0.004,0.004,0.004,0.002,0.002,0.002])


def weighted_kernel(K,w):
    return sum(float(a)*K[p] for a,p in zip(w,PATHS))


def fit_kernel(K,y,ridge):
    mu=float(np.mean(y)); alpha=np.linalg.solve(K+ridge*np.eye(len(y)),y-mu); return mu,alpha


def transfer_score(y,pred,keys,temps):
    vals=[]
    for t in np.unique(temps):
        m=temps==t; vals.append(_group_rmse(y[m],pred[m],keys[m]))
    return float(np.mean(vals))


def cv_predict(train,x,bounds,w,ridge,mode='directional_lower'):
    y=train.retention.to_numpy(float); keys=_device_keys(train); K=kernels(x,x,bounds)
    P=[];Y=[];G=[];T=[]
    for tr,va,tv in _cv_folds(train,mode):
        ktr=weighted_kernel({p:v[np.ix_(tr,tr)] for p,v in K.items()},w)
        kva=weighted_kernel({p:v[np.ix_(va,tr)] for p,v in K.items()},w)
        mu,a=fit_kernel(ktr,y[tr],ridge); P.append(mu+kva@a);Y.append(y[va]);G.append(keys[va]);T.append(np.repeat(tv,len(va)))
    return np.concatenate(Y),np.concatenate(P),np.concatenate(G),np.concatenate(T)


@dataclass
class StageFit:
    bounds: Tuple[float,float]
    weights: np.ndarray
    ridge: float
    baseline_ridge: float
    cv_rmse: float
    baseline_cv_rmse: float
    activated: bool
    gamma: float
    stats: Tuple[np.ndarray,np.ndarray]
    def weight_dict(self): return {p:float(v) for p,v in zip(PATHS,self.weights)}


def fit_stage_shared_specific(train,hp,cshape,cstress,ea_ev=0.45,
                              boundary_grid=((0.25,0.60),(0.25,0.70),(0.30,0.65),(0.30,0.70),(0.35,0.70),(0.35,0.75)),
                              ridge_grid=(0.01,0.03,0.08),cv_mode='directional_lower',maxiter=22,
                              min_gain=0.002,min_relative_gain=0.03):
    x,stats=factor_matrix(train,hp,cshape,cstress,ea_ev,None); y=train.retention.to_numpy(float)
    base=np.zeros(len(PATHS));base[0]=1.0
    # baseline independently optimized
    base_candidates=[]
    for r in ridge_grid:
        yy,pp,gg,tt=cv_predict(train,x,(0.3,0.7),base,float(r),cv_mode)
        base_candidates.append((transfer_score(yy,pp,gg,tt),float(r),yy,pp,gg,tt))
    bscore,bridge,*_=min(base_candidates,key=lambda z:z[0])

    best=None
    for bounds in boundary_grid:
      for r in ridge_grid:
        starts=[]
        z=np.zeros(len(PATHS));z[0]=0.45;z[1]=0.25;z[2:5]=0.06;z[5:]=0.04;z/=z.sum();starts.append(z)
        z=np.repeat(1/len(PATHS),len(PATHS));starts.append(z)
        starts.append(base.copy())
        cons={'type':'eq','fun':lambda w:float(np.sum(w)-1)}
        def obj(w):
            yy,pp,gg,tt=cv_predict(train,x,bounds,w,float(r),cv_mode)
            risk=transfer_score(yy,pp,gg,tt)
            return risk+float(np.sum(COMPLEX*np.sqrt(np.clip(w,0,None))))
        for x0 in starts:
            res=minimize(obj,x0,bounds=[(0,1)]*len(PATHS),constraints=cons,method='SLSQP',options={'maxiter':maxiter,'ftol':2e-4,'disp':False})
            yy,pp,gg,tt=cv_predict(train,x,bounds,res.x,float(r),cv_mode)
            score=transfer_score(yy,pp,gg,tt)
            record=(score,float(obj(res.x)),bounds,float(r),np.asarray(res.x,float))
            if best is None or record[1]<best[1]: best=record
    score,_,bounds,ridge,w=best
    # safety blend relative to independently tuned target-only predictor using same folds
    yy,pf,gg,tt=cv_predict(train,x,bounds,w,ridge,cv_mode)
    _,p0,_,_=cv_predict(train,x,bounds,base,bridge,cv_mode)
    gammas=np.linspace(0,1,21); risks=[transfer_score(yy,p0+g*(pf-p0),gg,tt) for g in gammas]
    j=int(np.argmin(risks));gamma=float(gammas[j]);final=float(risks[j]);gain=float(bscore-final)
    threshold=max(float(min_gain),float(min_relative_gain)*float(bscore));activated=gain>=threshold
    if not activated: gamma=0.;final=float(bscore)
    return StageFit(tuple(bounds),w,ridge,bridge,final,float(bscore),bool(activated),gamma,stats)


def predict_stage_shared_specific(train,test,fit,hp,cshape,cstress,ea_ev=0.45):
    xtr,_=factor_matrix(train,hp,cshape,cstress,ea_ev,fit.stats); xte,_=factor_matrix(test,hp,cshape,cstress,ea_ev,fit.stats)
    y=train.retention.to_numpy(float); base=np.zeros(len(PATHS));base[0]=1.0
    def pred(w,r):
        kt=weighted_kernel(kernels(xtr,xtr,fit.bounds),w);ks=weighted_kernel(kernels(xte,xtr,fit.bounds),w)
        mu,a=fit_kernel(kt,y,r);return mu+ks@a
    p0=pred(base,fit.baseline_ridge);pf=pred(fit.weights,fit.ridge)
    return p0+fit.gamma*(pf-p0),p0,pf
