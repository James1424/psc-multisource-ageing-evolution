# v0.8 Results — Shared General Features + Stage-Specific Features

## Hypothesis
Heterogeneous sources should not be forced to transfer all information globally. A source-derived representation is decomposed into (i) a shared component that can act throughout ageing and (ii) source-private residuals that can act only through smooth early/mid/late stage experts. Stage boundaries are selected using directional lower-temperature transfer CV; 25 C remains external audit only.

## 3-seed prototype audit

| N devices | model | overall RMSE | stage 1 | stage 2 | stage 3 |
|---:|---|---:|---:|---:|---:|
| 6 | target-only | 0.1713 | 0.1509 | 0.1308 | 0.2161 |
| 6 | v0.6 adaptive granularity | **0.1043** | 0.0653 | **0.0914** | **0.1394** |
| 6 | v0.8 shared-specific stages | 0.1327 | **0.0610** | 0.1128 | 0.1895 |
| 12 | target-only | 0.1479 | 0.1688 | 0.1025 | 0.1615 |
| 12 | v0.6 adaptive granularity | **0.1077** | **0.0852** | 0.1065 | **0.1243** |
| 12 | v0.8 shared-specific stages | 0.1097 | 0.0872 | **0.0965** | 0.1366 |
| 24 | target-only | 0.1708 | 0.1491 | 0.1274 | 0.2212 |
| 24 | v0.6 adaptive granularity | **0.1240** | **0.1193** | **0.0926** | **0.1518** |
| 24 | v0.8 shared-specific stages | 0.1387 | 0.1296 | 0.1090 | 0.1700 |

The learned boundaries cluster near b1 ~ 0.32–0.33 and b2 ~ 0.68–0.70 of within-device normalized ageing progress. Private-stage-1 was consistently suppressed; the model mainly used a globally shared latent plus stage-local shared refinements, with private-stage-2 becoming relevant at larger label budgets.

## Interpretation
The hypothesis is only partially supported. Stage specialization can improve a particular period (notably stage 1 at N=6 and stage 2 at N=12), but replacing the v0.6 global/context-adaptive model by a stage-expert model causes late-stage negative transfer. Therefore the next safe design should keep v0.6 as the shared backbone and add stage-specific experts only as residual corrections, with stage-wise activation/defer decisions. Hard segmentation should not replace cross-stage knowledge.

This is a model-design result, not evidence that degradation truly has exactly three physical stages. The current stage boundaries are predictive regime boundaries selected from training data, not mechanistic phase-transition labels.
