# Project status — first real-data smoke test

This repository was validated against the three uploaded datasets on 2026-10-15.

## Audited data

- Hartono: 2,245 MPPT trajectories; first curve has 900 time points.
- Accelerated SAM archive: 144 pixel trajectories across 39 `(temperature, sample_id)` device groups at 25, 35, 45, 55 and 65 °C.
- Chakar: three outdoor MPP channels (~1.596 million rows each), 9,954 indoor J–V rows, 35 outdoor J–V rows, and ~1.594 million irradiance/cell-temperature rows.

## Hartono trajectory prior

FPCA explained variance ratios for the first four components:

- PC1: 0.97693
- PC2: 0.01241
- PC3: 0.00628
- PC4: 0.00243

This supports a low-dimensional trajectory representation, but does **not** prove that the Hartono morphology transfers across protocols.

## Accelerated target summaries

Median effective log-linear degradation rates (`k_eff`, descriptive only):

| T (°C) | devices | median duration (h) | median k_eff (1/h) |
|---:|---:|---:|---:|
| 25 | 8 | 2291 | 0.000614 |
| 35 | 7 | 1201 | 0.000929 |
| 45 | 8 | 452 | 0.002770 |
| 55 | 8 | 315 | 0.002942 |
| 65 | 8 | 167 | 0.004488 |

The monotone trend is broadly compatible with thermal acceleration, but 45→55 °C changes only weakly; a single Arrhenius law should therefore be treated as a soft prior, not a hard constraint.

## MVP benchmark

Whole-temperature extrapolation: hold out all 25 °C devices. Randomly reveal 8 device-temperature groups from the other temperatures. Five seeds.

- Target-only GP: mean RMSE ≈ 0.1393
- Frozen Hartono+weak-Arrhenius prior + GP residual: mean RMSE ≈ 0.1322

The gain is **small** and should only be considered feasibility evidence. It is not a publishable conclusion.

## First active-learning smoke test

Using 6 initial device groups and prior-aware acquisition, 25 °C RMSE evolved:

`0.1577 → 0.1253 → 0.1155 → 0.1240 → ...`

The improvement is not monotone and later degrades. This is scientifically useful: the first acquisition rule is not yet robust. Required next work:

1. compare against random and uncertainty-only AL with many seeds;
2. add diversity / cost / temperature-balancing terms;
3. learn or calibrate prior strength instead of fixing it;
4. loosen/re-estimate GP noise bounds;
5. use device-level latent trajectory coefficients rather than only sparse pointwise GP when scaling up;
6. stress-test intentionally wrong priors and measure negative transfer.

## Important limitation

Accelerated v1 was **not** supplied. Therefore v0.1 does not claim a source-learned thermal prior. The Arrhenius term is only a weak structural prior with a configurable activation-energy hyperparameter. For the intended final thesis experiment, adding v1 would enable a cleaner `v1 -> frozen thermal prior -> v2 target` separation.
