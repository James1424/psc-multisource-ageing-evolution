from psc_prior_al.priors import arrhenius_acceleration

def test_acceleration_increases_with_temperature():
    assert arrhenius_acceleration(65)>arrhenius_acceleration(45)>arrhenius_acceleration(25)
