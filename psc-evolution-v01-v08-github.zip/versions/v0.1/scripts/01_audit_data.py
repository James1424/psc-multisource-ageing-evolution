import argparse,json
from pathlib import Path
import pandas as pd
from psc_prior_al.config import load_config,resolve
from psc_prior_al.data import load_hartono,accelerated_inventory,load_chakar_tables

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); a=ap.parse_args()
    root=Path('.'); c=load_config(a.config); out=resolve(root,c['paths']['processed']); out.mkdir(parents=True,exist_ok=True)
    h=load_hartono(resolve(root,c['paths']['hartono']))
    inv=accelerated_inventory(resolve(root,c['paths']['accelerated_v2'])); inv.to_csv(out/'accelerated_inventory.csv',index=False)
    ch=load_chakar_tables(resolve(root,c['paths']['chakar']))
    audit={
      'hartono_n_curves':len(h),
      'hartono_first_shape':list(h.iloc[0].shape),
      'accelerated_temperatures_c':sorted(inv['T'].unique().tolist()),
      'accelerated_n_pixels':int(len(inv)),
      'accelerated_n_device_temperature_groups':int(inv.groupby(['T','sample']).ngroups),
      'chakar_tables':{k:list(v.shape) for k,v in ch.items()}
    }
    (out/'audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8'); print(json.dumps(audit,indent=2))
if __name__=='__main__': main()
