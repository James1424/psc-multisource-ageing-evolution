"""Pool-based retrospective AL at device level.
The oracle is Accelerated-v2 itself; a whole device-temperature group is revealed per round.
"""
import argparse
from pathlib import Path
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.priors import trajectory_prior
from psc_prior_al.models import ResidualGP
from psc_prior_al.active_learning import acquisition,select_group
from psc_prior_al.metrics import rmse

def feat(df): return np.c_[np.log1p(df.time_h.to_numpy())/np.log1p(2500.),(df.temperature_c.to_numpy()-45.)/20.]
def thin(df,maxn=30):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h')
        if len(g)>maxn:
            idx=np.unique(np.linspace(0,len(g)-1,maxn).round().astype(int)); g=g.iloc[idx]
        out.append(g)
    return pd.concat(out,ignore_index=True)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); a=ap.parse_args(); c=load_config(a.config); root=Path('.')
    proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); hold=c['benchmark']['holdout_temperature_c']
    test=thin(d[d.temperature_c==hold].copy(),c['preprocessing']['max_points_per_device_gp']); pool=d[d.temperature_c!=hold].copy(); groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rng=np.random.default_rng(c['model']['random_state']); init=min(c['active_learning']['initial_devices'],len(groups)); labeled=set(map(tuple,groups.iloc[rng.choice(len(groups),size=init,replace=False)].to_numpy()))
    history=[]
    for rnd in range(c['active_learning']['rounds']+1):
        train=thin(pool[pool.apply(lambda r:(r.temperature_c,r.sample_id) in labeled,axis=1)].copy(),c['preprocessing']['max_points_per_device_gp'])
        pm_tr=trajectory_prior(train.time_h,train.temperature_c,hp['grid_h'],hp['mean_curve'],c['model']['arrhenius_ea_ev_prior']); pm_te=trajectory_prior(test.time_h,test.temperature_c,hp['grid_h'],hp['mean_curve'],c['model']['arrhenius_ea_ev_prior'])
        m=ResidualGP(c['model']['gp_alpha'],c['model']['random_state']).fit(feat(train),train.retention,pm_tr); mu,std=m.predict(feat(test),pm_te)
        history.append({'round':rnd,'n_devices':len(labeled),'rmse_25c':rmse(test.retention,mu)})
        if rnd==c['active_learning']['rounds']: break
        cand=thin(pool[~pool.apply(lambda r:(r.temperature_c,r.sample_id) in labeled,axis=1)].copy(),c['preprocessing']['max_points_per_device_gp'])
        if len(cand)==0: break
        pm=trajectory_prior(cand.time_h,cand.temperature_c,hp['grid_h'],hp['mean_curve'],c['model']['arrhenius_ea_ev_prior']); cmu,cstd=m.predict(feat(cand),pm)
        score=acquisition(cstd,cmu,pm,lam=c['active_learning']['lambda_disagreement']); g=select_group(cand,score); labeled.add((float(g[0]),float(g[1])))
    pd.DataFrame(history).to_csv(res/'active_learning_history.csv',index=False); print(pd.DataFrame(history))
if __name__=='__main__': main()
