"""MVP benchmark on real Accelerated-v2 trajectories.
Compares target-only GP vs frozen Hartono+Arrhenius prior + GP residual.
Evaluation holds out an entire temperature and uses grouped device sampling.
"""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.priors import trajectory_prior
from psc_prior_al.models import ResidualGP
from psc_prior_al.metrics import rmse,mae,coverage,nlpd

def feature(df):
    return np.c_[np.log1p(df['time_h'].to_numpy())/np.log1p(2500.), (df['temperature_c'].to_numpy()-45.)/20.]

def thin(df, max_per_device=30):
    parts=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h')
        if len(g)>max_per_device:
            idx=np.unique(np.linspace(0,len(g)-1,max_per_device).round().astype(int)); g=g.iloc[idx]
        parts.append(g)
    return pd.concat(parts,ignore_index=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); ap.add_argument('--train-devices',type=int,default=12); a=ap.parse_args()
    c=load_config(a.config); root=Path('.'); proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(parents=True,exist_ok=True)
    curves=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib')
    hold=float(c['benchmark']['holdout_temperature_c']); test=curves[curves.temperature_c==hold].copy(); pool=curves[curves.temperature_c!=hold].copy()
    groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rows=[]
    for seed in c['benchmark']['seeds']:
        rng=np.random.default_rng(seed); n=min(a.train_devices,len(groups)); chosen=groups.iloc[rng.choice(len(groups),size=n,replace=False)]
        train=thin(pool.merge(chosen,on=['temperature_c','sample_id']), c['preprocessing']['max_points_per_device_gp'])
        test_thin=thin(test, c['preprocessing']['max_points_per_device_gp'])
        Xtr=feature(train); Xte=feature(test_thin); ytr=train.retention.to_numpy(); yte=test_thin.retention.to_numpy()
        pm_tr=trajectory_prior(train.time_h,train.temperature_c,hp['grid_h'],hp['mean_curve'],c['model']['arrhenius_ea_ev_prior'])
        pm_te=trajectory_prior(test_thin.time_h,test_thin.temperature_c,hp['grid_h'],hp['mean_curve'],c['model']['arrhenius_ea_ev_prior'])
        for name,prior_tr,prior_te in [('target_only',None,None),('source_prior',pm_tr,pm_te)]:
            m=ResidualGP(c['model']['gp_alpha'],seed).fit(Xtr,ytr,prior_tr)
            mu,std=m.predict(Xte,prior_te)
            rows.append({'seed':seed,'model':name,'train_devices':n,'holdout_temperature_c':hold,'rmse':rmse(yte,mu),'mae':mae(yte,mu),'coverage95':coverage(yte,mu,std),'nlpd':nlpd(yte,mu,std)})
    out=pd.DataFrame(rows); out.to_csv(res/'mvp_benchmark.csv',index=False)
    summary=out.groupby('model')[['rmse','mae','coverage95','nlpd']].agg(['mean','std']); print(summary)
if __name__=='__main__': main()
