# Multi-source Prior Active Learning for PSC Degradation

Research prototype for **explicit scientific-prior distillation from heterogeneous perovskite ageing data** and **prior-aware active learning**.

## Scientific separation of roles

- **Hartono 2023** (`20230303_mySeriesDrop.pkl`): source-only trajectory-shape prior (2,245 MPPT traces).
- **Chakar 2025** (`chakar_2025.zip`): source-only mechanism / cross-protocol evidence. It is *not* row-concatenated with the target dataset.
- **Accelerated ageing v2** (`dataset_SAM.zip`): the only target domain in this v0.1 implementation. The uploaded archive contains 25, 35, 45, 55 and 65 °C measurements and 144 pixel traces; pixels are aggregated within a `sample_id` before model evaluation.

This version deliberately **does not use target labels to construct the Hartono/Chakar prior**. The Arrhenius term is a weak structural prior with a configurable activation-energy hyperparameter, not a fitted source result. If Accelerated v1 is later added, thermal-prior parameters can be learned from v1 and frozen before opening v2 labels.

## Core model

The target trajectory is modeled as

`retention(t,T) = m_source(t,T) + GP_residual(t,T)`

where `m_source` uses the Hartono mean trajectory with a weak Arrhenius time warp. The GP is allowed to correct a wrong prior. Active learning scores candidates by posterior uncertainty plus normalized prior–posterior disagreement, and reveals whole device-temperature groups rather than individual pixels.

## Codespaces quick start

1. Create/open this repository in GitHub Codespaces.
2. Put the three user-supplied files in `data/raw/` with these names:
   - `20230303_mySeriesDrop.pkl`
   - `dataset_SAM.zip`
   - `chakar_2025.zip`
3. Run:

```bash
python scripts/01_audit_data.py
python scripts/02_build_priors.py
python scripts/03_run_benchmark.py --train-devices 12
python scripts/04_run_active_learning.py
```

Outputs are written to `data/processed/` and `results/`.

## Leakage controls

- No pixel from the same `sample_id` is treated as an independent train/test device.
- Source priors are frozen before target-label fitting.
- The MVP benchmark holds out **all 25 °C devices** and trains on grouped devices from the other temperatures.
- Report sample efficiency and uncertainty calibration, not only R².

## Important limitation of v0.1

The Hartono upload contains time series but no companion device metadata table, so it currently supplies **trajectory morphology only**, not architecture-specific priors. Chakar is kept modular because its protocol/labels differ strongly from the accelerated target. These are intentional safeguards against false pooling.

## Real-data smoke-test status

See [`PROJECT_STATUS.md`](PROJECT_STATUS.md) for the first run on the uploaded data. The first benchmark shows only a modest prior benefit, and the first AL trajectory is non-monotone; both are intentionally documented rather than hidden.
