from __future__ import annotations
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF, WhiteKernel
from sklearn.preprocessing import StandardScaler

class ResidualGP:
    def __init__(self, alpha=0.0025, random_state=42):
        self.scaler=StandardScaler()
        kernel=ConstantKernel(1.0,(1e-3,1e3))*RBF([1.0,1.0],(1e-2,1e3))+WhiteKernel(1e-3,(1e-6,1e-1))
        self.gp=GaussianProcessRegressor(kernel=kernel,alpha=alpha,normalize_y=True,n_restarts_optimizer=1,random_state=random_state)
    def fit(self,X,y,prior=None):
        Xs=self.scaler.fit_transform(X)
        target=np.asarray(y)- (0. if prior is None else np.asarray(prior))
        self.gp.fit(Xs,target); return self
    def predict(self,X,prior=None,return_std=True):
        Xs=self.scaler.transform(X)
        mu,std=self.gp.predict(Xs,return_std=True)
        mu=mu+(0. if prior is None else np.asarray(prior))
        return (mu,std) if return_std else mu
