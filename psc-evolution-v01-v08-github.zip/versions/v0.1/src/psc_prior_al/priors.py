from __future__ import annotations
import numpy as np

KB_EV_K = 8.617333262145e-5

def arrhenius_acceleration(temperature_c, ref_c=25.0, ea_ev=0.45):
    T=np.asarray(temperature_c,dtype=float)+273.15; Tr=ref_c+273.15
    # ratio k(T)/k(Tr)
    return np.exp((-ea_ev/KB_EV_K)*(1.0/T-1.0/Tr))

def trajectory_prior(time_h, temperature_c, hartono_grid_h, hartono_mean_curve, ea_ev=0.45, ref_c=25.0):
    """Source-only prior: Hartono mean shape with a weak Arrhenius time warp.
    Ea is a structural hyperparameter here, not fitted on target labels.
    """
    a=arrhenius_acceleration(temperature_c,ref_c,ea_ev)
    te=np.asarray(time_h,float)*a
    return np.interp(te, hartono_grid_h, hartono_mean_curve, left=hartono_mean_curve[0], right=hartono_mean_curve[-1])

def chakar_prior_strength(chakar_tables: dict) -> dict:
    """Extract only source-side qualitative/weak quantitative evidence.
    This intentionally does not force Chakar data into the target feature table.
    """
    result={"available":False}
    jv=chakar_tables.get('outdoor_jvs')
    if jv is None or len(jv)==0: return result
    result.update({"available":True,"n_outdoor_jv_rows":int(len(jv)),"n_cells":int(jv['cell_id'].nunique()) if 'cell_id' in jv else None})
    return result
