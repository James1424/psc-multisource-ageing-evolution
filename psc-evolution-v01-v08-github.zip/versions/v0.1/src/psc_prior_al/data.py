from __future__ import annotations
import io, re, zipfile
from pathlib import Path
import numpy as np
import pandas as pd

ACC_RE = re.compile(r"MPPT_filtered_(?P<T>\d+)C/MPPT_sample_(?P<sample>\d+)_pixel_(?P<pixel>\d+)\.csv$")

def load_hartono(path: str | Path) -> pd.Series:
    s = pd.read_pickle(path)
    if not isinstance(s, pd.Series) or len(s) == 0:
        raise ValueError("Hartono file must be a non-empty pandas Series of DataFrames")
    return s

def iter_accelerated(path: str | Path):
    with zipfile.ZipFile(path) as zf:
        for name in zf.namelist():
            m = ACC_RE.search(name)
            if not m:
                continue
            df = pd.read_csv(zf.open(name))
            meta = {k: int(v) for k, v in m.groupdict().items()}
            meta["member"] = name
            yield meta, df

def accelerated_inventory(path: str | Path) -> pd.DataFrame:
    rows=[]
    for meta, df in iter_accelerated(path):
        rows.append({**meta, "n_rows":len(df), "duration_h":float(pd.to_numeric(df["Duration_h"], errors="coerce").max())})
    return pd.DataFrame(rows).sort_values(["T","sample","pixel"]).reset_index(drop=True)

def load_chakar_tables(path: str | Path) -> dict[str,pd.DataFrame]:
    out={}
    with zipfile.ZipFile(path) as zf:
        for name in zf.namelist():
            if name.lower().endswith('.csv'):
                key=Path(name).name.replace('.csv','')
                out[key]=pd.read_csv(zf.open(name))
    return out
