from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from .data import iter_accelerated

def _robust_initial_scale(t_h, y, window_h=12.0):
    t=np.asarray(t_h,float); y=np.asarray(y,float)
    mask=np.isfinite(t)&np.isfinite(y)&(t<=window_h)&(y>0)
    if mask.sum()<5:
        mask=np.isfinite(y)&(y>0)
    vals=y[mask]
    if len(vals)==0: return np.nan
    return float(np.nanpercentile(vals, 90))

def resample_curve(t_h, y, grid, baseline_window_h=12.0):
    t=np.asarray(t_h,float); y=np.asarray(y,float)
    mask=np.isfinite(t)&np.isfinite(y)
    t=t[mask]; y=y[mask]
    if len(t)<3: return None
    order=np.argsort(t); t=t[order]; y=y[order]
    base=_robust_initial_scale(t,y,baseline_window_h)
    if not np.isfinite(base) or base<=0: return None
    yn=y/base
    uniq, idx=np.unique(t, return_index=True); yn=yn[idx]
    valid=grid<=uniq.max()
    out=np.full(len(grid),np.nan)
    out[valid]=np.interp(grid[valid], uniq, yn)
    return out

def build_hartono_pca(series: pd.Series, horizon_h=150., n_grid=151, n_components=4):
    grid=np.linspace(0,horizon_h,n_grid)
    curves=[]
    for df in series:
        if not isinstance(df,pd.DataFrame) or 'MPPT_EFF' not in df: continue
        idx=pd.to_datetime(df.index)
        t=(idx-idx[0]).total_seconds()/3600
        c=resample_curve(t, df['MPPT_EFF'].to_numpy(), grid, baseline_window_h=1.0)
        if c is not None and np.isfinite(c).mean()>0.95:
            if np.isnan(c).any():
                good=np.isfinite(c); c=np.interp(grid,grid[good],c[good])
            curves.append(c)
    X=np.vstack(curves)
    pca=PCA(n_components=min(n_components, X.shape[0], X.shape[1]), random_state=0)
    Z=pca.fit_transform(X)
    return {"grid_h":grid,"mean_curve":pca.mean_,"components":pca.components_,"scores":Z,"explained":pca.explained_variance_ratio_,"n_curves":len(X)}

def build_accelerated_device_curves(zip_path, grid_step_h=1.0, baseline_window_h=12.0, aggregation='median'):
    pixel=[]
    for meta,df in iter_accelerated(zip_path):
        t=pd.to_numeric(df['Duration_h'],errors='coerce').to_numpy()
        y=pd.to_numeric(df['MPPT_EFF'],errors='coerce').to_numpy()
        max_h=float(np.nanmax(t)); grid=np.arange(0,np.floor(max_h)+1e-9,grid_step_h)
        c=resample_curve(t,y,grid,baseline_window_h)
        if c is None: continue
        pixel.append((meta['T'],meta['sample'],meta['pixel'],grid,c))
    rows=[]
    for (T,sample) in sorted(set((x[0],x[1]) for x in pixel)):
        subset=[x for x in pixel if x[0]==T and x[1]==sample]
        max_common=min(x[3][-1] for x in subset)
        grid=np.arange(0,max_common+1e-9,grid_step_h)
        arr=np.vstack([np.interp(grid,x[3],x[4]) for x in subset])
        agg=np.nanmedian(arr,axis=0) if aggregation=='median' else np.nanmean(arr,axis=0)
        for t,y in zip(grid,agg): rows.append({'temperature_c':T,'sample_id':sample,'time_h':t,'retention':y,'n_pixels':len(subset)})
    return pd.DataFrame(rows)

def summarize_devices(curves: pd.DataFrame) -> pd.DataFrame:
    out=[]
    for (T,s),g in curves.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); t=g.time_h.to_numpy(); y=g.retention.to_numpy()
        mask=np.isfinite(y)&(y>0)&(t>=max(5,0.02*t.max()))
        # log-linear effective degradation rate; descriptive, not claimed mechanistic
        slope=np.polyfit(t[mask], np.log(np.clip(y[mask],1e-4,None)), 1)[0] if mask.sum()>=5 else np.nan
        # empirical threshold times without forced monotonicity: first crossing after 5h
        vals={}
        for q in (0.95,0.90,0.80):
            idx=np.where((t>=5)&(y<=q))[0]
            vals[f't{int(q*100)}_h']=float(t[idx[0]]) if len(idx) else np.nan
        out.append({'temperature_c':T,'sample_id':s,'n_pixels':int(g.n_pixels.max()),'duration_h':float(t.max()),'k_eff_per_h':float(max(-slope,1e-10)),**vals})
    return pd.DataFrame(out)
