import numpy as np

def rmse(y,p): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))
def mae(y,p): return float(np.mean(np.abs(np.asarray(y)-np.asarray(p))))
def coverage(y,mu,std,z=1.96):
    y=np.asarray(y); mu=np.asarray(mu); std=np.asarray(std)
    return float(np.mean((y>=mu-z*std)&(y<=mu+z*std)))
def nlpd(y,mu,std,eps=1e-6):
    y=np.asarray(y); mu=np.asarray(mu); s=np.maximum(np.asarray(std),eps)
    return float(np.mean(0.5*np.log(2*np.pi*s*s)+0.5*((y-mu)/s)**2))
