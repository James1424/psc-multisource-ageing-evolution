from __future__ import annotations
import numpy as np

def acquisition(std, posterior_mean=None, prior_mean=None, prior_std=0.05, lam=0.7):
    std=np.asarray(std,float)
    if posterior_mean is None or prior_mean is None:
        return std
    d=np.abs(np.asarray(posterior_mean)-np.asarray(prior_mean))/np.sqrt(std**2+prior_std**2)
    return std+lam*d

def select_group(candidate_df, scores, group_cols=('temperature_c','sample_id')):
    tmp=candidate_df.copy(); tmp['_score']=scores
    ranked=tmp.groupby(list(group_cols))['_score'].mean().sort_values(ascending=False)
    return ranked.index[0]
