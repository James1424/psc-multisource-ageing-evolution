import numpy as np
from psc_prior_al.adaptive_fusion import pathway_kernels, PATH_NAMES

def test_pathway_kernel_shapes_and_psd_diagonal():
    x=np.random.default_rng(0).normal(size=(8,5))
    k=pathway_kernels(x,x)
    assert tuple(k.keys()) == PATH_NAMES
    for v in k.values():
        assert v.shape==(8,8)
        assert np.allclose(v,v.T)
        assert np.allclose(np.diag(v),1.0)
