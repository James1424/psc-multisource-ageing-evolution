# v0.5 Research Note — Safe Adaptive Multi-Source Fusion

## Scientific correction to the original hypothesis

The project does **not** assume that pooling more databases must improve unseen-domain error. That statement is not generally true and cannot be made rigorous without assumptions on domain relatedness. Instead, v0.5 implements a stronger and defensible design principle:

> Adding a database must enlarge the model library without deleting the previous best model. The learner should discover whether the new database contributes directly, conditionally through target physics, through cross-source interaction, or should remain dormant at the current label budget.

Thus the model does not permanently label a database as useless. A pathway can be **deferred** when current transfer evidence is insufficient and can reactivate when more target labels become available.

## A/B/C interpretation

- **B**: target-domain time/temperature physics from Accelerated v2.
- **A/C**: heterogeneous external source signals derived from Hartono and Chakar.
- The roles of A and C are not assumed to be intrinsically good or bad.

## Layer 1: path-level multiple-kernel learning

The model constructs seven positive-semidefinite kernels:

- `base`: target time + B;
- `H`: Hartono direct pathway;
- `C`: Chakar direct pathway;
- `H_B`: Hartono-dependent modulation of B;
- `C_B`: Chakar-dependent modulation of B;
- `H_C`: Hartono–Chakar complementarity;
- `H_C_B`: higher-order conditional fusion.

The composite kernel is

\[
K = \sum_j w_j K_j, \qquad w_j\ge 0,\quad \sum_j w_j=1.
\]

Weights are learned by **directional lower-temperature transfer CV**, not ordinary random CV. For example, 45/55/65 °C data are used to validate extrapolation toward 35 °C, which is aligned with the final 25 °C extrapolation task.

This design directly addresses the user's hypothesis: a source can have nearly zero direct weight while retaining non-zero `C_B`, `H_C`, or `H_C_B` weight.

## Layer 2: defer-not-discard safety rule

The target-only baseline is always retained. Source pathways activate only if the directional transfer-CV improvement exceeds

\[
\max(0.002,\; 0.05\times R_{\mathrm{baseline,CV}}).
\]

If evidence is weaker, `gamma=0` and the current iteration returns to the baseline. This is **not** interpreted as proof that the database is harmful or useless; it means only that the current label budget cannot justify activating those source paths.

The threshold is expressed as a relative transfer-risk reduction rather than being tuned against the held-out 25 °C labels.

## Layer 3: Monotone Source Expansion

Four expert families are retained simultaneously:

1. target-only;
2. Hartono-only adaptive paths;
3. Chakar-only adaptive paths;
4. full Hartono + Chakar interaction model.

The expert with the lowest directional transfer-CV risk is selected before the 25 °C test is opened.

Because target-only remains in the candidate library, expanding the source set cannot worsen the **best attainable model-selection risk on the same validation criterion**. This monotonicity is about the optimization/model-selection objective; it is not a universal theorem about arbitrary unseen-domain generalization.

## How v0.5 distinguishes "not learned" from "harmful"

A negative direct ablation is no longer enough to call a source harmful. The diagnostic hierarchy is:

1. direct path;
2. B-modulation path;
3. cross-source path;
4. higher-order path;
5. source-specific expert;
6. full multisource expert;
7. reversed/smooth-null controls;
8. repeated evaluation at larger target label budgets.

A source is regarded as **under-identified** when direct use fails but a mediated or cross-source route improves transfer. A source is **deferred** when no pathway achieves sufficient transfer evidence at the current budget. Only if all tested pathways fail across budgets and fail against matched null controls is there evidence of non-transferability under the tested representation family.
