#!/usr/bin/env bash
set -euo pipefail
export PYTHONPATH="${PYTHONPATH:-}:src"
python scripts/01_audit_data.py
python scripts/02_build_priors.py
python scripts/12_safe_adaptive_multisource_fusion.py --seeds 10
python scripts/13_source_rescue_ablation.py --seeds 5
python scripts/14_monotone_source_selector.py
