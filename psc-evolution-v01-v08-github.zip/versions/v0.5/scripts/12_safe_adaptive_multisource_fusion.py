"""v0.5 Safe Adaptive Multi-Source Kernel Fusion (SAMKF).

Purpose:
1) do not hard-reject a whole source database;
2) let each source act through direct, B-modulation, cross-source, and higher-order paths;
3) learn nonnegative pathway weights from leave-one-temperature-out transfer CV;
4) include a baseline fallback via convex safe blending;
5) diagnose whether previous negative transfer was caused by a bad direct path or by source-identification failure.

25 C is never used for source/path selection. It is external evaluation only.
"""
from pathlib import Path
import argparse, json, warnings
import numpy as np
import pandas as pd
import joblib

from psc_prior_al.config import load_config, resolve
from psc_prior_al.adaptive_fusion import (
    PATH_NAMES, fit_safe_adaptive_fusion, predict_safe_adaptive_fusion,
    source_utility_summary,
)

warnings.filterwarnings("ignore")


def thin(df, maxn=6):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h')
        idx=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int))
        out.append(g.iloc[idx])
    return pd.concat(out,ignore_index=True)


def rmse(y,p):
    return float(np.sqrt(np.mean((np.asarray(y,float)-np.asarray(p,float))**2)))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--config',default='configs/default.yaml')
    ap.add_argument('--seeds',type=int,default=10)
    ap.add_argument('--quick',action='store_true')
    ap.add_argument('--points-per-device',type=int,default=6)
    args=ap.parse_args()

    c=load_config(args.config); root=Path('.')
    proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz')
    hp=joblib.load(proc/'hartono_pca.joblib')
    cs=pd.read_csv(proc/'chakar_daily_shape.csv')
    ea=float(c['model']['arrhenius_ea_ev_prior']); hold=float(c['benchmark']['holdout_temperature_c'])

    test=thin(d[d.temperature_c==hold],args.points_per_device)
    pool=d[d.temperature_c!=hold]
    groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    budgets=[6,12,24]
    nseeds=3 if args.quick else args.seeds

    rows=[]; weights=[]
    for n in budgets:
        for seed in range(nseeds):
            rng=np.random.default_rng(seed)
            chosen=groups.iloc[rng.choice(len(groups),min(n,len(groups)),replace=False)]
            train=thin(pool.merge(chosen,on=['temperature_c','sample_id']),args.points_per_device)
            fit=fit_safe_adaptive_fusion(train,hp,cs,ea_ev=ea,seed=seed,maxiter=25 if args.quick else 40)
            pred,p0,pf=predict_safe_adaptive_fusion(train,test,fit,hp,cs,ea_ev=ea,seed=seed)
            u=source_utility_summary(fit)
            rows.append({
                'train_devices':n,'seed':seed,
                'baseline_rmse_25C':rmse(test.retention,p0),
                'adaptive_fusion_rmse_25C':rmse(test.retention,pred),
                'raw_fusion_rmse_25C':rmse(test.retention,pf),
                'gain_vs_baseline':rmse(test.retention,p0)-rmse(test.retention,pred),
                **u,
            })
            for _,r in fit.pathway_table.iterrows():
                weights.append({'train_devices':n,'seed':seed,**r.to_dict(),'gamma':fit.gamma})

    out=pd.DataFrame(rows); wdf=pd.DataFrame(weights)
    out.to_csv(res/'safe_adaptive_fusion_v05.csv',index=False)
    wdf.to_csv(res/'safe_adaptive_path_weights_v05.csv',index=False)

    summary=out.groupby('train_devices').agg(
        baseline_rmse=('baseline_rmse_25C','mean'),
        fusion_rmse=('adaptive_fusion_rmse_25C','mean'),
        gain=('gain_vs_baseline','mean'),
        gain_sd=('gain_vs_baseline','std'),
        P_fusion_better=('gain_vs_baseline',lambda x:float(np.mean(np.asarray(x)>0))),
        gamma=('gamma','mean'),
        conditional_mass=('conditional_path_mass','mean'),
        hartono_mass=('hartono_total_path_mass','mean'),
        chakar_mass=('chakar_total_path_mass','mean'),
    ).reset_index()
    summary.to_csv(res/'safe_adaptive_fusion_v05_summary.csv',index=False)

    ws=(wdf.groupby(['train_devices','path']).weight.mean().reset_index())
    ws.to_csv(res/'safe_adaptive_path_weights_v05_summary.csv',index=False)

    # Source-specific stress at N=12: real Chakar vs same-capacity reversed/null Chakar.
    stress=[]
    n=12
    for variant in ['real','reversed','smooth_null']:
        for seed in range(min(nseeds,5)):
            rng=np.random.default_rng(seed)
            chosen=groups.iloc[rng.choice(len(groups),n,replace=False)]
            train=thin(pool.merge(chosen,on=['temperature_c','sample_id']),args.points_per_device)
            fit=fit_safe_adaptive_fusion(
                train,hp,cs,ea_ev=ea,candidate_variant='Chakar',variant=variant,seed=seed,
                maxiter=20 if args.quick else 35,
            )
            pred,p0,_=predict_safe_adaptive_fusion(
                train,test,fit,hp,cs,ea_ev=ea,candidate_variant='Chakar',variant=variant,seed=seed,
            )
            stress.append({
                'variant':variant,'seed':seed,'rmse':rmse(test.retention,pred),
                'baseline_rmse':rmse(test.retention,p0),'gain':rmse(test.retention,p0)-rmse(test.retention,pred),
                **source_utility_summary(fit),
            })
    st=pd.DataFrame(stress); st.to_csv(res/'safe_adaptive_chakar_stress_v05.csv',index=False)
    stsum=st.groupby('variant').agg(rmse=('rmse','mean'),gain=('gain','mean'),P_better=('gain',lambda x:float(np.mean(np.asarray(x)>0))),chakar_mass=('chakar_total_path_mass','mean'),CB=('chakar_B_modulation','mean')).reset_index()
    stsum.to_csv(res/'safe_adaptive_chakar_stress_v05_summary.csv',index=False)

    print('\n=== v0.5 external 25 C summary ===')
    print(summary.round(4).to_string(index=False))
    print('\n=== mean pathway weights ===')
    print(ws.pivot(index='path',columns='train_devices',values='weight').round(3).to_string())
    print('\n=== Chakar source-specific stress (N=12) ===')
    print(stsum.round(4).to_string(index=False))

if __name__=='__main__':
    main()
