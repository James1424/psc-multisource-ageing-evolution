"""v0.5 source-rescue ablation.

Compares target-only, Hartono-only adaptive pathways, Chakar-only adaptive pathways,
and full Hartono+Chakar fusion under the same directional transfer-CV selector.
This tests whether the full model gains from true cross-source complementarity rather than
merely from one useful source while ignoring the other.
"""
from pathlib import Path
import argparse, warnings
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.adaptive_fusion import fit_safe_adaptive_fusion,predict_safe_adaptive_fusion,source_utility_summary
warnings.filterwarnings('ignore')

def thin(df,maxn=6):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); i=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int)); out.append(g.iloc[i])
    return pd.concat(out,ignore_index=True)
def rmse(y,p): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,default=5);ap.add_argument('--quick',action='store_true');a=ap.parse_args()
    c=load_config('configs/default.yaml');root=Path('.');proc=resolve(root,c['paths']['processed']);res=resolve(root,c['paths']['results']);res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz');hp=joblib.load(proc/'hartono_pca.joblib');cs=pd.read_csv(proc/'chakar_daily_shape.csv');ea=float(c['model']['arrhenius_ea_ev_prior']);hold=float(c['benchmark']['holdout_temperature_c'])
    test=thin(d[d.temperature_c==hold]);pool=d[d.temperature_c!=hold];groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    families={
      'target_only':['base'],
      'Hartono_only':['base','H','H_B'],
      'Chakar_only':['base','C','C_B'],
      'full_multisource':['base','H','C','H_B','C_B','H_C','H_C_B'],
    }
    rows=[]
    seeds=range(3 if a.quick else a.seeds)
    for n in [6,12,24]:
      for seed in seeds:
        rng=np.random.default_rng(seed);ch=groups.iloc[rng.choice(len(groups),n,replace=False)];tr=thin(pool.merge(ch,on=['temperature_c','sample_id']))
        for fam,paths in families.items():
          fit=fit_safe_adaptive_fusion(tr,hp,cs,ea_ev=ea,seed=seed,allowed_paths=paths,maxiter=20 if a.quick else 35)
          p,p0,_=predict_safe_adaptive_fusion(tr,test,fit,hp,cs,ea_ev=ea,seed=seed)
          rows.append({'train_devices':n,'seed':seed,'family':fam,'rmse':rmse(test.retention,p),**source_utility_summary(fit)})
    out=pd.DataFrame(rows);out.to_csv(res/'source_rescue_ablation_v05.csv',index=False)
    summ=out.groupby(['train_devices','family']).agg(rmse=('rmse','mean'),activated=('activated','mean'),gamma=('gamma','mean')).reset_index()
    summ.to_csv(res/'source_rescue_ablation_v05_summary.csv',index=False)
    wide=out.pivot_table(index=['train_devices','seed'],columns='family',values='rmse').reset_index()
    wide['full_gain_vs_H']=wide['Hartono_only']-wide['full_multisource'];wide['full_gain_vs_C']=wide['Chakar_only']-wide['full_multisource'];wide['full_gain_vs_target']=wide['target_only']-wide['full_multisource']
    wide.to_csv(res/'source_rescue_ablation_v05_paired.csv',index=False)
    paired=wide.groupby('train_devices').agg(gain_vs_H=('full_gain_vs_H','mean'),gain_vs_C=('full_gain_vs_C','mean'),gain_vs_target=('full_gain_vs_target','mean'),P_full_beats_H=('full_gain_vs_H',lambda x:float(np.mean(np.asarray(x)>=-1e-12))),P_full_beats_C=('full_gain_vs_C',lambda x:float(np.mean(np.asarray(x)>=-1e-12))),P_full_beats_target=('full_gain_vs_target',lambda x:float(np.mean(np.asarray(x)>=-1e-12)))).reset_index()
    paired.to_csv(res/'source_rescue_ablation_v05_paired_summary.csv',index=False)
    print('\nFamily RMSE');print(summ.round(4).to_string(index=False));print('\nPaired full-fusion gains');print(paired.round(4).to_string(index=False))
if __name__=='__main__':main()
