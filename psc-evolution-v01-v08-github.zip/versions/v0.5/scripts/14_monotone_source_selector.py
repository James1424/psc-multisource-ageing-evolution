"""Monotone Source Expansion meta-selector (v0.5).

Select among target-only, source-specific, and full-interaction experts using ONLY the
precomputed directional transfer-CV risk. Because target-only remains in the library,
adding a new database expands the candidate model family instead of deleting the old one.
Therefore the *selected transfer-CV risk* cannot worsen by construction. External 25 C
performance is reported only after selection and is not used to choose the family.
"""
from pathlib import Path
import pandas as pd, numpy as np

p=Path('results/source_rescue_ablation_v05.csv')
if not p.exists():
    raise SystemExit('Run scripts/13_source_rescue_ablation.py first.')
d=pd.read_csv(p)
rows=[]
for (n,seed),g in d.groupby(['train_devices','seed']):
    r=g.sort_values(['transfer_cv_rmse','family']).iloc[0]
    target=float(g.loc[g.family=='target_only','rmse'].iloc[0])
    rows.append({
        'train_devices':n,'seed':seed,'selected_family':r.family,
        'selected_transfer_cv_rmse':r.transfer_cv_rmse,
        'external_rmse_25C':r.rmse,
        'target_only_rmse_25C':target,
        'external_gain_vs_target':target-r.rmse,
    })
out=pd.DataFrame(rows);out.to_csv('results/monotone_source_selector_v05.csv',index=False)
s=out.groupby('train_devices').agg(
    selected_rmse=('external_rmse_25C','mean'),target_rmse=('target_only_rmse_25C','mean'),
    gain=('external_gain_vs_target','mean'),
    P_external_nonworse=('external_gain_vs_target',lambda x:float(np.mean(np.asarray(x)>=-1e-12))),
).reset_index()
s.to_csv('results/monotone_source_selector_v05_summary.csv',index=False)
f=(out.groupby(['train_devices','selected_family']).size()/out.groupby('train_devices').size()).rename('selection_frequency').reset_index()
f.to_csv('results/monotone_source_selector_v05_frequency.csv',index=False)
print('\nMonotone source selector external audit')
print(s.round(4).to_string(index=False))
print('\nSelected expert frequencies')
print(f.round(3).to_string(index=False))
