# v0.5 Real-Data Results

These are exploratory results on the uploaded Hartono, Accelerated-v2, and Chakar datasets. The held-out 25 °C Accelerated-v2 trajectories are never used to fit pathway weights, source activation, regularization, or expert selection.

## 1. Path-MKL + defer rule — 10 random device splits

| Revealed target devices | Target-only RMSE | Adaptive multisource RMSE | Relative RMSE reduction | Strictly better splits | Non-worse splits |
|---:|---:|---:|---:|---:|---:|
| 6 | 0.1608 | 0.1226 | 23.8% | 10/10 | 10/10 |
| 12 | 0.1496 | 0.1291 | 13.7% | 7/10 | 10/10 |
| 24 | 0.1555 | 0.1489 | 4.3% | 4/10 | 10/10 |

The decrease in source activation at larger N is expected: once target data become informative, the marginal value of external priors becomes smaller. The algorithm therefore defers weak source paths instead of forcing them.

### Mean pathway weights

| Path | N=6 | N=12 | N=24 |
|---|---:|---:|---:|
| base | 0.068 | 0.551 | 0.769 |
| Hartono direct | 0.088 | 0.057 | 0.000 |
| Chakar direct | 0.246 | 0.180 | 0.076 |
| Hartono × B | 0.135 | 0.040 | 0.023 |
| Chakar × B | 0.020 | 0.030 | 0.047 |
| Hartono × Chakar | 0.435 | 0.139 | 0.077 |
| higher-order | 0.008 | 0.004 | 0.008 |

The low-data regime is dominated by conditional/cross-source kernels rather than by a single direct source term. As N increases, weight moves toward the target baseline while `C_B` can remain non-zero, which is compatible with the hypothesis that an external source may refine the target physics factor without being a strong direct predictor.

## 2. Chakar stress controls at N=12

Across the five stress-test seeds used by the script:

- real Chakar: mean RMSE ≈ 0.1236;
- reversed Chakar: mean RMSE ≈ 0.1376;
- smooth-null Chakar: mean RMSE ≈ 0.1430.

The controls are informative but not perfect: a corrupted source can occasionally coexist with useful Hartono pathways, so improvement of the *whole multisource system* does not by itself prove the corrupted source contributed. Source-specific utility must therefore be assessed against source-specific expert ablations and pathway weights, not only against target-only.

## 3. Source-rescue ablation — 5 random device splits

| N | Target-only | Hartono-only | Chakar-only | Full multisource |
|---:|---:|---:|---:|---:|
| 6 | 0.1556 | 0.1371 | 0.1126 | 0.1116 |
| 12 | 0.1510 | 0.1510 | 0.1333 | 0.1232 |
| 24 | 0.1570 | 0.1570 | 0.1448 | 0.1516 |

At N=6 and N=12, full fusion improves over both single-source families on average. At N=24, Chakar-only is better than the forced full-interaction expert. This is exactly why the final layer keeps all experts rather than forcing the full model.

## 4. Monotone Source Expansion selector — 5 random device splits

The meta-selector chooses the expert family using only directional transfer-CV risk.

| N | Target-only RMSE | Selected source-system RMSE | Relative reduction | External non-worse splits |
|---:|---:|---:|---:|---:|
| 6 | 0.1556 | 0.1116 | 28.3% | 5/5 |
| 12 | 0.1510 | 0.1164 | 22.9% | 5/5 |
| 24 | 0.1570 | 0.1437 | 8.5% | 5/5 |

Selected expert frequencies:

- N=6: full multisource 100%;
- N=12: Chakar-only 60%, full multisource 40%;
- N=24: Chakar-only 80%, full multisource 20%.

This does **not** prove that more databases universally improve unseen data. It shows that, for these exploratory splits, a model library that has access to all databases and can choose conditional usage avoids the negative-transfer behavior seen in v0.4 and improves the held-out 25 °C task.

## 5. What can and cannot be claimed

Supported by the current experiment:

1. hard source rejection was too crude;
2. source utility is pathway-dependent;
3. direct utility and conditional utility are different quantities;
4. directional transfer validation is more appropriate than random grouped CV for lower-temperature extrapolation;
5. retaining old experts while adding new source-specific/interacting experts substantially reduces observed negative transfer;
6. on the current exploratory splits, the adaptive source system is non-worse than target-only on the 25 °C external test and improves mean RMSE.

Not yet supported:

- a theorem that adding arbitrary databases always lowers unseen-domain error;
- a causal claim that Hartono or Chakar changes a physical degradation mechanism;
- publication-level significance from only five source-rescue splits;
- generalization to another laboratory without external replication.

The next publication-grade step is nested directional CV with an independent accelerated-ageing source (e.g. Accelerated v1), followed by a completely untouched external laboratory dataset.
