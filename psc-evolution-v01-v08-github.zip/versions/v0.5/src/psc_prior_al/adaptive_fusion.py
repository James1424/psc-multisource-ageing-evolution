from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Tuple
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .source_diagnostics import source_factor_frame
from .source_auditor import make_factor_variant


PATH_NAMES = ("base", "H", "C", "H_B", "C_B", "H_C", "H_C_B")


def _device_keys(df: pd.DataFrame) -> np.ndarray:
    return np.asarray([f"{t}|{s}" for t, s in zip(df.temperature_c, df.sample_id)])


def _group_rmse(y: np.ndarray, pred: np.ndarray, keys: np.ndarray) -> float:
    vals = []
    for g in np.unique(keys):
        m = keys == g
        vals.append(float(np.sqrt(np.mean((y[m] - pred[m]) ** 2))))
    return float(np.mean(vals))


def _standardized_factor_matrix(
    df: pd.DataFrame,
    hp: dict,
    chakar_shape: pd.DataFrame,
    ea_ev: float,
    stats: Tuple[np.ndarray, np.ndarray] | None = None,
    candidate_variant: str | None = None,
    variant: str = "real",
    seed: int = 0,
):
    """Return [time, B, H, C, progress] without using target labels.

    `candidate_variant` can be Hartono or Chakar for reversed/smooth-null stress tests.
    """
    if candidate_variant is None or variant == "real":
        f = source_factor_frame(df, hp, chakar_shape, ea_ev)
    else:
        f = make_factor_variant(df, hp, chakar_shape, ea_ev, candidate_variant, variant, seed)

    z = np.c_[
        np.log1p(df.time_h.to_numpy(float)) / np.log1p(2500.0),
        f["B"].to_numpy(float),
        f["H"].to_numpy(float),
        f["C"].to_numpy(float),
        f["progress"].to_numpy(float),
    ]
    if stats is None:
        mean = np.nanmean(z, axis=0)
        std = np.nanstd(z, axis=0)
        std[std < 1e-6] = 1.0
        stats = (mean, std)
    z = (z - stats[0]) / stats[1]
    return z, stats


def _rbf(x: np.ndarray, y: np.ndarray, cols: Iterable[int]) -> np.ndarray:
    a = x[:, list(cols)]
    b = y[:, list(cols)]
    d2 = np.sum((a[:, None, :] - b[None, :, :]) ** 2, axis=-1)
    return np.exp(-0.5 * d2)


def pathway_kernels(x: np.ndarray, y: np.ndarray) -> Dict[str, np.ndarray]:
    """Path-level kernels.

    base: target time + temperature/Arrhenius coordinate B
    H/C: direct source pathways
    H_B/C_B: source-dependent modulation of B
    H_C: cross-source complementarity
    H_C_B: higher-order conditional source interaction
    """
    specs = {
        "base": (0, 1),
        "H": (2,),
        "C": (3,),
        "H_B": (2, 1),
        "C_B": (3, 1),
        "H_C": (2, 3),
        "H_C_B": (2, 3, 1),
    }
    return {name: _rbf(x, y, cols) for name, cols in specs.items()}


def _posterior_coefficients(k: np.ndarray, y: np.ndarray, ridge: float):
    mu = float(np.mean(y))
    alpha = np.linalg.solve(k + ridge * np.eye(len(y)), y - mu)
    return mu, alpha


def _weighted_kernel(kernels: Dict[str, np.ndarray], weights: np.ndarray) -> np.ndarray:
    return sum(float(weights[i]) * kernels[name] for i, name in enumerate(PATH_NAMES))


@dataclass
class AdaptiveFusionFit:
    weights: np.ndarray
    gamma: float
    ridge: float
    baseline_ridge: float
    transfer_cv_rmse: float
    baseline_transfer_cv_rmse: float
    stats: Tuple[np.ndarray, np.ndarray]
    pathway_table: pd.DataFrame
    activated: bool
    validation_gain: float
    cv_mode: str
    activation_threshold: float

    def weight_dict(self) -> Dict[str, float]:
        return {name: float(v) for name, v in zip(PATH_NAMES, self.weights)}


def _cv_folds(train: pd.DataFrame, mode: str = "directional_lower"):
    temp=train.temperature_c.to_numpy(float)
    uniq=np.sort(np.unique(temp))
    folds=[]
    if mode=="loto":
        for tv in uniq:
            tr=np.where(temp!=tv)[0]; va=np.where(temp==tv)[0]
            if len(tr) and len(va): folds.append((tr,va,float(tv)))
    elif mode=="directional_lower":
        # Mimic the real task: predict a lower-temperature domain from higher-temperature data.
        # A fold is valid only if at least two distinct higher temperatures remain for training.
        for tv in uniq:
            tr=np.where(temp>tv)[0]; va=np.where(temp==tv)[0]
            if len(va) and len(np.unique(temp[tr]))>=2:
                folds.append((tr,va,float(tv)))
    else:
        raise ValueError(f"Unknown cv mode: {mode}")
    if not folds:
        # Conservative fallback when a tiny random subset lacks enough temperature support.
        for tv in uniq:
            tr=np.where(temp!=tv)[0]; va=np.where(temp==tv)[0]
            if len(tr) and len(va): folds.append((tr,va,float(tv)))
    return folds


def _cv_predictions(
    train: pd.DataFrame,
    kernels: Dict[str, np.ndarray],
    weights: np.ndarray,
    ridge: float,
    mode: str = "directional_lower",
):
    y=train.retention.to_numpy(float)
    keys=_device_keys(train)
    preds=[]; ys=[]; gkeys=[]; fold_t=[]
    for tr,va,tv in _cv_folds(train,mode):
        ktr=_weighted_kernel({n:k[np.ix_(tr,tr)] for n,k in kernels.items()},weights)
        kva=_weighted_kernel({n:k[np.ix_(va,tr)] for n,k in kernels.items()},weights)
        mu,alpha=_posterior_coefficients(ktr,y[tr],ridge)
        preds.append(mu+kva@alpha); ys.append(y[va]); gkeys.append(keys[va]); fold_t.append(np.repeat(tv,len(va)))
    return np.concatenate(preds),np.concatenate(ys),np.concatenate(gkeys),np.concatenate(fold_t)


def _transfer_score_from_arrays(y: np.ndarray,pred: np.ndarray,keys: np.ndarray,fold_t: np.ndarray) -> float:
    per=[]
    for tv in np.unique(fold_t):
        m=fold_t==tv
        per.append(_group_rmse(y[m],pred[m],keys[m]))
    return float(np.mean(per))


def _cv_score(train,kernels,weights,ridge,mode):
    p,y,k,t=_cv_predictions(train,kernels,weights,ridge,mode)
    return _transfer_score_from_arrays(y,p,k,t)


def fit_safe_adaptive_fusion(
    train: pd.DataFrame,
    hp: dict,
    chakar_shape: pd.DataFrame,
    ea_ev: float = 0.45,
    candidate_variant: str | None = None,
    variant: str = "real",
    seed: int = 0,
    ridge_grid=(0.01, 0.03, 0.08),
    source_penalty: float = 0.002,
    maxiter: int = 35,
    cv_mode: str = "directional_lower",
    min_transfer_gain: float = 0.002,
    min_relative_transfer_gain: float = 0.05,
    allowed_paths: Iterable[str] | None = None,
) -> AdaptiveFusionFit:
    """Learn source/path utility with leave-one-temperature-out CV.

    Crucially, no source is accepted/rejected as a whole. The optimizer allocates nonnegative
    kernel mass across direct and conditional pathways. A baseline-only kernel is always present.
    A final convex safety blend gamma is chosen from transfer-CV predictions; gamma=0 exactly
    recovers the target-only baseline on the *selection criterion*.

    This is a validation-risk safeguard, not a theorem that unseen-domain test error cannot rise.
    """
    x, stats = _standardized_factor_matrix(
        train, hp, chakar_shape, ea_ev, None, candidate_variant, variant, seed
    )
    kernels = pathway_kernels(x, x)
    y = train.retention.to_numpy(float)

    n = len(PATH_NAMES)
    baseline = np.zeros(n, float)
    baseline[0] = 1.0
    allowed=set(PATH_NAMES if allowed_paths is None else allowed_paths)
    allowed.add("base")
    allowed_mask=np.asarray([name in allowed for name in PATH_NAMES],bool)

    starts = [
        baseline * 0.85 + np.r_[0.0, np.repeat(0.15 / (n - 1), n - 1)],
        np.repeat(1.0 / n, n),
        np.array([0.35, 0.05, 0.05, 0.15, 0.15, 0.15, 0.10]),
        np.array([0.50, 0.00, 0.00, 0.20, 0.20, 0.05, 0.05]),
    ]
    # Project starts onto the allowed pathway family and renormalize.
    projected=[]
    for x0 in starts:
        z=np.asarray(x0,float)*allowed_mask
        if z.sum()<=0: z=baseline.copy()
        else: z=z/z.sum()
        projected.append(z)
    starts=projected

    # Tune the target-only baseline independently; otherwise fusion could look better simply
    # because its ridge/noise setting was reused for the baseline.
    baseline_candidates=[]
    for r0 in ridge_grid:
        p0,y0,k0,t0=_cv_predictions(train,kernels,baseline,float(r0),cv_mode)
        baseline_candidates.append((_transfer_score_from_arrays(y0,p0,k0,t0),float(r0),p0,y0,k0,t0))
    baseline_score, baseline_ridge, base_oof, cv_y, cv_keys, cv_t = min(baseline_candidates,key=lambda z:z[0])

    best = None
    best_ridge = None
    best_raw_score = np.inf
    constraints = {"type": "eq", "fun": lambda w: float(np.sum(w) - 1.0)}
    bounds = [(0.0,1.0) if ok else (0.0,0.0) for ok in allowed_mask]

    for ridge in ridge_grid:
        def objective(w):
            cv = _cv_score(train,kernels,w,float(ridge),cv_mode)
            # Mild sparsity/shrinkage on non-baseline pathways; it can shrink a bad direct path
            # while retaining a useful mediated/cross-source path.
            penalty = source_penalty * float(np.sum(np.sqrt(np.clip(w[1:], 0.0, None))))
            return cv + penalty

        for x0 in starts:
            res = minimize(
                objective,
                x0=np.asarray(x0, float),
                bounds=bounds,
                constraints=constraints,
                method="SLSQP",
                options={"maxiter": maxiter, "ftol": 2e-4, "disp": False},
            )
            if res.fun < best_raw_score:
                best_raw_score = float(res.fun)
                best = np.asarray(res.x, float)
                best_ridge = float(ridge)

    if best is None:
        best = baseline.copy()
        best_ridge = float(ridge_grid[0])

    fused_oof,fy,fk,ft = _cv_predictions(train,kernels,best,best_ridge,cv_mode)
    base_score = float(baseline_score)
    # Folds are identical for baseline and fusion under a fixed cv_mode.
    gammas=np.linspace(0.0,1.0,21); scores=[]
    for g in gammas:
        p=base_oof+g*(fused_oof-base_oof)
        scores.append(_transfer_score_from_arrays(cv_y,p,cv_keys,cv_t))
    j=int(np.argmin(scores)); gamma=float(gammas[j]); cv_score=float(scores[j])
    validation_gain=base_score-cv_score
    # 'Defer, do not discard': weak evidence does not label a database harmful.
    # It simply keeps its pathways dormant for this label budget and re-tests them later.
    activation_threshold=max(float(min_transfer_gain),float(min_relative_transfer_gain)*base_score)
    activated=bool(validation_gain>=activation_threshold)
    if not activated:
        gamma=0.0; cv_score=base_score; validation_gain=0.0

    table = pd.DataFrame({"path": PATH_NAMES, "weight": best})
    table["role"] = [
        "target baseline", "Hartono direct", "Chakar direct",
        "Hartono modulates B", "Chakar modulates B",
        "Hartono-Chakar complementarity", "higher-order conditional fusion",
    ]
    return AdaptiveFusionFit(
        weights=best,
        gamma=gamma,
        ridge=best_ridge,
        baseline_ridge=baseline_ridge,
        transfer_cv_rmse=cv_score,
        baseline_transfer_cv_rmse=float(base_score),
        stats=stats,
        pathway_table=table,
        activated=activated,
        validation_gain=float(validation_gain),
        cv_mode=cv_mode,
        activation_threshold=float(activation_threshold),
    )


def predict_safe_adaptive_fusion(
    train: pd.DataFrame,
    test: pd.DataFrame,
    fit: AdaptiveFusionFit,
    hp: dict,
    chakar_shape: pd.DataFrame,
    ea_ev: float = 0.45,
    candidate_variant: str | None = None,
    variant: str = "real",
    seed: int = 0,
):
    xtr, _ = _standardized_factor_matrix(
        train, hp, chakar_shape, ea_ev, fit.stats, candidate_variant, variant, seed
    )
    xte, _ = _standardized_factor_matrix(
        test, hp, chakar_shape, ea_ev, fit.stats, candidate_variant, variant, seed
    )
    ktr = pathway_kernels(xtr, xtr)
    kte = pathway_kernels(xte, xtr)
    y = train.retention.to_numpy(float)

    base_w = np.zeros(len(PATH_NAMES), float)
    base_w[0] = 1.0

    def pred_for(w, ridge):
        k = _weighted_kernel(ktr, w)
        ks = _weighted_kernel(kte, w)
        mu, alpha = _posterior_coefficients(k, y, ridge)
        return mu + ks @ alpha

    p0 = pred_for(base_w, fit.baseline_ridge)
    pf = pred_for(fit.weights, fit.ridge)
    p = p0 + fit.gamma * (pf - p0)

    # GP-like posterior variance from the final blended kernel is not exact after blending.
    # We return predictions plus both component predictions so calibration can be handled separately.
    return p, p0, pf


def source_utility_summary(fit: AdaptiveFusionFit) -> dict:
    w = fit.weight_dict()
    return {
        "baseline_weight": w["base"],
        "hartono_direct_weight": w["H"],
        "chakar_direct_weight": w["C"],
        "hartono_B_modulation": w["H_B"],
        "chakar_B_modulation": w["C_B"],
        "cross_source_weight": w["H_C"],
        "higher_order_weight": w["H_C_B"],
        "hartono_total_path_mass": w["H"] + w["H_B"] + 0.5*w["H_C"] + 0.5*w["H_C_B"],
        "chakar_total_path_mass": w["C"] + w["C_B"] + 0.5*w["H_C"] + 0.5*w["H_C_B"],
        "conditional_path_mass": w["H_B"] + w["C_B"] + w["H_C"] + w["H_C_B"],
        "gamma": fit.gamma,
        "ridge": fit.ridge,
        "baseline_ridge": fit.baseline_ridge,
        "transfer_cv_rmse": fit.transfer_cv_rmse,
        "baseline_transfer_cv_rmse": fit.baseline_transfer_cv_rmse,
        "activated": float(fit.activated),
        "validation_gain": fit.validation_gain,
        "cv_mode": fit.cv_mode,
        "activation_threshold": fit.activation_threshold,
    }
