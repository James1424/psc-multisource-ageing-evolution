# Multi-Source Prior Active Learning for Perovskite Ageing — v0.2

A research prototype for testing whether **frozen, explicit priors distilled from heterogeneous perovskite ageing datasets** can improve small-label degradation learning and retrospective active experiment selection.

The design deliberately avoids row-wise pooling across incompatible datasets.

## Data roles

- **Hartono ageing dataset** → generic trajectory-shape FPCA prior + source uncertainty.
- **Chakar 2025 outdoor/indoor dataset** → independent weak outdoor degradation-shape expert; allowed to receive zero target trust.
- **Accelerated ageing v2** → sole target domain and retrospective AL oracle.

Because Accelerated-v1 is not included, v0.2 does **not** claim to have learned an external thermal Arrhenius prior. Temperature is represented by an Arrhenius-motivated target feature only.

## Core model

The target model is

`retention(t,T) = source_prior(progress) + GP_residual(log time, Arrhenius coordinate)`.

Source prior trust is explicit and falsifiable. The pipeline can learn to attenuate a mismatched source rather than forcing it into the target model.

## Leakage rules

- Split/query unit = `(temperature, parent sample/device)`.
- Pixels from one parent sample are aggregated before modeling.
- 25 °C can be held out as a full external temperature domain.
- Hartono/Chakar source functions are built without Accelerated-v2 labels.
- Target labels may calibrate **trust weights**, but never reconstruct the frozen source function itself.

## Put the three raw files here

```text
data/raw/
├── 20230303_mySeriesDrop.pkl
├── dataset_SAM.zip
└── chakar_2025.zip
```

The uploaded Chakar archive can simply be renamed to `chakar_2025.zip`.

## GitHub Codespaces

Open the repository in Codespaces. The devcontainer installs the dependencies automatically.

Run a fast real-data smoke test:

```bash
python scripts/01_audit_data.py
python scripts/02_build_priors.py
python scripts/03_run_benchmark.py --quick
python scripts/04_run_active_learning.py --quick
python scripts/05_make_report.py
```

Run the configured full experiment:

```bash
python scripts/03_run_benchmark.py
python scripts/04_run_active_learning.py
python scripts/05_make_report.py
```

## Main outputs

```text
results/
├── benchmark_v02.csv
├── benchmark_v02_summary.csv
├── active_learning_v02.csv
├── active_learning_selections_v02.csv
├── active_learning_v02_summary.csv
├── benchmark_learning_curves.png
└── active_learning_curves.png
```

Processed source artifacts include `hartono_pca.joblib`, `chakar_daily_shape.csv`, device-aggregated Accelerated trajectories, and the audit inventory.

## Benchmarks in v0.2

Prediction benchmark:

- target-only GP
- fixed Hartono-shape prior + GP residual
- adaptive multi-source prior + GP residual
- wrong-activation-energy stress tests
- explicitly reversed/wrong source-shape stress test

Retrospective Active Learning:

- random
- posterior uncertainty
- source-prior disagreement
- hybrid = uncertainty + disagreement + temperature balance + metadata diversity

## Scientific interpretation

The intended thesis claim is **not** “more datasets always improve performance”. The testable claim is narrower:

> In the very-low-label regime, can an explicit source trajectory prior reduce target sample requirements, while an adaptive/falsifiable mechanism prevents negative transfer when the source becomes unhelpful?

See `PROJECT_STATUS.md` for the current real-data results and limitations.

## v0.3 — Source Usefulness Diagnosis

v0.3 adds an explicit experiment for a common multi-dataset failure mode: a source can be harmful when injected directly but useful through interactions with a target-domain factor.

We denote:

- **A**: the other external source,
- **B**: the Accelerated-v2 target-domain temperature/time factor,
- **C**: the source currently being audited.

The diagnostic fits the following paths on exactly the same revealed target devices:

1. `B_only` — target-only GP;
2. `A_direct` — A as an explicit mean factor;
3. `C_direct` — C as an explicit mean factor;
4. `A_C_direct` — both sources enter directly;
5. `A_plus_C_mediates_B` — C has **no direct path** to the prediction and can only act through `C × B`;
6. `full_source_graph` — direct, source×temperature, and source×source interactions.

Every external factor is constructed without target labels. Only small calibration coefficients are estimated on the revealed parent devices, using grouped CV. The 25 °C target domain remains fully held out.

Run:

```bash
PYTHONPATH=src python scripts/06_source_usefulness_diagnostics.py --quick
PYTHONPATH=src python scripts/07_bidirectional_source_diagnosis.py
PYTHONPATH=src python scripts/08_source_utility_report.py
```

The resulting automatic diagnosis distinguishes:

- directly useful;
- harmful at the current label budget;
- underlearned at small N (harm changes sign as N grows);
- directly harmful but indirectly useful through the target-domain factor;
- mixed/redundant evidence.

### Current real-data pilot finding

With five random device splits, treating **Hartono as candidate source C** gives a consistent pattern: direct addition to the Chakar-based mean is slightly harmful, while using Hartono only through the `Hartono × temperature-factor` interaction substantially improves 25 °C extrapolation. At 12 revealed devices, mean RMSE changes from about `0.1471` (A-only) to `0.1482` (direct A+C; worse) but to `0.1155` when Hartono is allowed to act only through the mediated interaction. This is a pilot result, not yet a publication-level claim; full seeds, alternative holdout temperatures, and confidence intervals are required.

## v0.4 — Automatic Source Dataset Auditor

v0.4 asks a stricter question than ordinary source ablation: **can the model decide how (or whether) to use a heterogeneous database without looking at the external 25 °C test domain?**

For a candidate source C, the gate compares four paths using only grouped CV on currently revealed target devices:

- `reject_C`: do not use C;
- `direct_C`: C enters the mean predictor directly;
- `mediated_C`: C has no direct path and may only modulate target physics factor B through `C × B`;
- `full_C`: direct + source×B + source×source interactions.

The selected path is frozen and only then evaluated on fully held-out 25 °C trajectories. Two equal-capacity controls (`reversed` source and smooth random source) test whether a mediated gain is truly source-specific rather than merely caused by adding another interaction feature.

A separate grouped bootstrap asks whether C makes the explicit target factor B more identifiable: it compares the dispersion of the learned B coefficient in `B + A` versus `B + A + C×B`.

Run:

```bash
PYTHONPATH=src python scripts/09_automatic_source_auditor.py --quick
# publication-style replication
PYTHONPATH=src python scripts/09_automatic_source_auditor.py
```

Important interpretation rule: the code never claims a source is universally/intrinsically harmful. It can only classify it as harmful, useful, mediated-useful, redundant, or underlearned **under the tested representation/path family and label budget**.

Additional v0.4 diagnostics:

```bash
# automatic source-path auditor + null controls + B-factor bootstrap
PYTHONPATH=src python scripts/09_automatic_source_auditor.py

# transfer-aware gate; default is a 3-seed smoke test because LOTO GP validation is expensive
PYTHONPATH=src python scripts/10_transfer_aware_source_gate.py --seeds 3

# decomposes direct, C×B, and A×C utility at a fixed target-label budget
PYTHONPATH=src python scripts/11_path_decomposition.py --budget 12 --seeds 10
```

See `V04_RESULTS.md` for the current real-data findings and the negative results that constrain the scientific claim.

## v0.5: Safe Adaptive Multi-Source Kernel Fusion

v0.5 replaces the v0.4 hard accept/reject source gate with **path-level multiple-kernel learning**. A source database is never judged only by its direct predictor. The model can allocate evidence to:

- target baseline (`base`),
- Hartono direct (`H`),
- Chakar direct (`C`),
- Hartono-modulated temperature physics (`H_B`),
- Chakar-modulated temperature physics (`C_B`),
- cross-source complementarity (`H_C`),
- higher-order conditional fusion (`H_C_B`).

All pathway weights are nonnegative and learned using leave-one-temperature-out transfer CV. A final convex safety blend contains the target-only baseline as `gamma=0`, so source fusion is not forced when the transfer-validation evidence is weak. This safeguards the **selection criterion**, but it is not a theorem guaranteeing lower error on every unseen external domain.

Run:

```bash
python scripts/12_safe_adaptive_multisource_fusion.py --quick
python scripts/12_safe_adaptive_multisource_fusion.py --seeds 10
```

The external 25 C set is never used to learn source/path weights.

### v0.5 recommended workflow

```bash
./run_v05.sh
```

The main methodological change is **defer, do not discard**: lack of transfer evidence at a small target-label budget keeps a source pathway dormant rather than declaring the source intrinsically harmful. Source pathways are reconsidered at every larger label budget.

The final `Monotone Source Expansion` layer retains target-only, Hartono-only, Chakar-only, and full-interaction experts. New databases therefore expand the expert library instead of replacing the old model. See `V05_RESEARCH_NOTE.md` and `V05_RESULTS.md` for the exact scientific claim and its limitations.
