# v0.6 — Adaptive Granularity and Context Alignment

## Research question
Heterogeneous scientific databases are rarely collected under identical experimental protocols. A source may be useful only under a matching temperature/stress/ageing phase, while overly strict matching can fragment the data and destroy transfer. v0.6 treats **alignment granularity as a learnable structural variable**, not a preprocessing choice.

The claim tested here is therefore not "the finest condition match is best". The falsifiable hypothesis is:

> A hierarchy containing coarse and fine source-context pathways, selected by transfer-oriented validation, can outperform both unconditional pooling and fixed fine-grained matching.

## Available context and hard limitation
The uploaded Accelerated v2 target contains controlled temperature, time, device/pixel identity and MPPT trajectories. Chakar contains outdoor irradiance and cell temperature, allowing a thermo-optical exposure coordinate. The uploaded Hartono object contains ageing trajectories but **does not contain experimental-condition metadata**. No algorithm can recover missing protocol variables from this file without additional assumptions. Hartono is therefore restricted to morphology/progress-level transfer in v0.6.

## Context hierarchy
For each source the model retains several granularities simultaneously:

- **Level 0 — global:** source trajectory information irrespective of target condition.
- **Level 1 — ageing phase:** source information is local in normalized early/mid/late progress.
- **Level 2 — experimental context:** source information is local in temperature/Arrhenius coordinate and ageing progress.
- **Level 3 — fine physical context:** source information is local jointly in temperature, progress, and cumulative stress exposure.

Fine levels receive larger complexity penalties. They are used only when directional low-temperature transfer CV provides enough evidence.

## Chakar thermo-optical stress coordinate
Because Chakar provides irradiance and cell temperature, v0.6 derives a candidate equivalent exposure coordinate

    dS = dt[h] * max(I,0)/1000 * a(T_cell; 25 C, Ea)

where `a` is the Arrhenius acceleration factor. The result has units of equivalent 25 C, 1-sun hours. This is **not claimed to be a universal degradation law**. It is one candidate alignment coordinate that the model may accept or ignore.

For Accelerated v2, the analogous controlled-stress proxy is

    S_target(t,T) = t * a(T;25 C,Ea)

under the simplifying 1-sun-equivalent assumption. The stress-aligned Chakar factor is therefore an explicit test of whether physical context alignment is more useful than chronology/progress alone.

## Hierarchical contextual multiple-kernel model
The kernel library contains:

- target baseline kernel;
- Hartono global / phase / context / fine kernels;
- Chakar chronological global / phase / context kernels;
- Chakar stress-aligned global / context / fine kernels;
- Hartono–Chakar global / context / fine complementarity kernels.

The predictive kernel is

    K = sum_j w_j K_j,  w_j >= 0, sum_j w_j = 1.

The `w_j` are learned only from non-25 C training data. The objective is directional lower-temperature transfer CV plus a hierarchy-dependent complexity penalty. Hence fine context is not selected merely because it has more degrees of freedom.

## Safety and generality
v0.6 preserves v0.5, coarse-global, fixed-fine, adaptive-granularity, and target-only models in the candidate library. Model-family selection uses only directional transfer-CV risk. The 25 C domain is revealed only for external auditing.

This gives a model-class expansion property: adding fine-grained alignment cannot remove the coarser model. It does **not** mathematically guarantee lower error on every unseen domain.

## What would falsify the idea?
The granularity hypothesis would be weakened if:

1. fixed-fine consistently beats adaptive hierarchy;
2. adaptive weights always collapse to one predetermined scale independent of label budget;
3. stress-aligned Chakar paths do not outperform generic/null alignment under repeated splits;
4. transfer-CV granularity choice is uncorrelated with external 25 C performance.

