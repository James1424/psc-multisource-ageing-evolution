# v0.6 preliminary real-data results

These are **preliminary 3-seed prototype results**, not publication-level uncertainty estimates. A longer repeated run should be executed in Codespaces/cluster before formal conclusions.

## Data-derived stress alignment
From the uploaded Chakar environmental record, v0.6 extracted 420 daily stress-aligned source points spanning approximately **1459 equivalent 25 C, 1-sun hours**. The chronological Chakar shape spans about **10272 h**.

## 25 C external audit
25 C is held out from all fitting and granularity selection.

| Target devices | Target-only | v0.5 Path-MKL | Coarse global | Fixed fine | Adaptive granularity |
|---:|---:|---:|---:|---:|---:|
| 6  | 0.1589 | 0.1146 | 0.1139 | 0.1534 | **0.1042** |
| 12 | 0.1480 | 0.1235 | 0.1332 | 0.1480 | **0.1077** |
| 24 | 0.1567 | 0.1548 | **0.1195** | 0.1567 | 0.1240 |

RMSE is on normalized retention trajectories.

### Interpretation
- **Fixed fine matching is not supported.** It mostly collapses to target-only because directional transfer evidence is insufficient.
- **Coarse-only is also not universally optimal.** It helps strongly at N=6 and especially N=24, but is inferior to the adaptive hierarchy at N=6/12.
- **Adaptive granularity is label-budget dependent.** Small target datasets benefit from richer source-conditioned alignment; at N=24 the transfer-CV selector prefers the coarser expert.

The granularity-safe selector chose adaptive granularity for N=6 and N=12, but coarse-global for N=24. In these three preliminary splits the selected model was externally non-worse than target-only in all cases.

## Learned average source granularity
Granularity index: 0 = global, 1 = phase, 2 = contextual, 3 = fine.

| N | Hartono granularity | Chakar chronological | Chakar stress-aligned | H–C interaction |
|---:|---:|---:|---:|---:|
| 6  | ~2.00* | ~1.00 | **~1.52** | ~0.00 |
| 12 | ~0.88 | ~0.07 | **~1.26** | ~0.87 |
| 24 | ~1.89 | ~0.79 | **~1.29** | ~1.17 |

`*` Hartono pathway mass is nearly zero at N=6, so its conditional granularity estimate is numerically unstable and should not be interpreted substantively.

The most robust qualitative observation is that the stress-aligned Chakar family receives substantial mass, while forcing all source information to the finest context is rejected.

## Current conclusion
The present evidence supports the **methodological need for adaptive granularity**, not a universal rule that more detailed condition matching is always better. The useful statement is:

> heterogeneous source information should be aligned at the finest granularity justified by transfer evidence, while coarser representations remain available as shrinkage/back-off paths.


## Stress-alignment specificity control (N=12, 3 seeds)

To check that the Chakar stress path is not merely benefiting from extra model capacity, the same architecture was rerun with the retention-vs-stress relation corrupted while keeping the stress coordinate and model family unchanged.

| Stress relation | External 25 C RMSE |
|---|---:|
| **real** | **0.1077** |
| smooth-permuted | 0.1188 |
| reversed | 0.1344 |

The real stress relation is better than both capacity-matched corruptions in this preliminary audit. However, real and smooth-permuted have nearly identical mean internal transfer-CV risk (~0.0924), so the present selector is **not yet perfectly identifiable** from non-25 C data. This is a limitation, not something to hide: future work should improve context-identifiability rather than treating the external result as a tuning signal.
