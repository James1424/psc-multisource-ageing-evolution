"""Stress-alignment specificity check (v0.6).

Keeps the same adaptive-granularity architecture and context coordinate but corrupts the
Chakar retention-vs-stress relationship.  If real stress alignment does not beat these
capacity-matched nulls, the apparent gain cannot be attributed to condition alignment.
"""
from pathlib import Path
import argparse, warnings
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.adaptive_granularity import fit_adaptive_granularity,predict_adaptive_granularity
warnings.filterwarnings('ignore')

def thin(df,maxn=6):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); i=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int)); out.append(g.iloc[i])
    return pd.concat(out,ignore_index=True)
def rmse(y,p): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))
def variant(g,kind,seed=0):
    z=g.copy().sort_values('stress_h').reset_index(drop=True)
    if kind=='reversed': z['retention']=z['retention'].to_numpy()[::-1]
    elif kind=='permuted':
        rng=np.random.default_rng(seed); vals=z['retention'].to_numpy().copy(); rng.shuffle(vals); z['retention']=pd.Series(vals).rolling(15,center=True,min_periods=1).mean().to_numpy()
    return z

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,default=3);ap.add_argument('--n',type=int,default=12);a=ap.parse_args()
    c=load_config('configs/default.yaml');root=Path('.');proc=resolve(root,c['paths']['processed']);res=resolve(root,c['paths']['results']);res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz');hp=joblib.load(proc/'hartono_pca.joblib');cs=pd.read_csv(proc/'chakar_daily_shape.csv');real=pd.read_csv(proc/'chakar_stress_shape.csv');ea=float(c['model']['arrhenius_ea_ev_prior']);hold=float(c['benchmark']['holdout_temperature_c'])
    test=thin(d[d.temperature_c==hold]);pool=d[d.temperature_c!=hold];groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rows=[]
    for seed in range(a.seeds):
        rng=np.random.default_rng(seed);ch=groups.iloc[rng.choice(len(groups),a.n,replace=False)];tr=thin(pool.merge(ch,on=['temperature_c','sample_id']))
        for kind in ['real','reversed','permuted']:
            cg=real if kind=='real' else variant(real,kind,seed)
            fit=fit_adaptive_granularity(tr,hp,cs,cg,ea_ev=ea,maxiter=16)
            p,_,_=predict_adaptive_granularity(tr,test,fit,hp,cs,cg,ea_ev=ea)
            rows.append({'train_devices':a.n,'seed':seed,'stress_variant':kind,'rmse_25C':rmse(test.retention,p),'transfer_cv_rmse':fit.transfer_cv_rmse,'activated':float(fit.activated)})
    out=pd.DataFrame(rows);out.to_csv(res/'stress_alignment_null_v06.csv',index=False)
    s=out.groupby('stress_variant').agg(rmse=('rmse_25C','mean'),transfer_cv=('transfer_cv_rmse','mean'),activation=('activated','mean')).reset_index();s.to_csv(res/'stress_alignment_null_v06_summary.csv',index=False)
    print(s.round(4).to_string(index=False))
if __name__=='__main__':main()
