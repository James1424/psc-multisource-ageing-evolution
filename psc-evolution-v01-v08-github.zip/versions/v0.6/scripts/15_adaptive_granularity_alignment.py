"""v0.6 adaptive granularity/context alignment experiment.

Question: when heterogeneous source data come from different protocols/conditions, should the
model learn only under tightly matched contexts?  Too-coarse alignment mixes incompatible
conditions; too-fine alignment overfits and destroys transfer.  We retain a hierarchy of source
representations and let directional low-temperature transfer CV choose granularity.

25 C is NEVER used for model selection.  It is external audit only.
"""
from pathlib import Path
import argparse, warnings
import numpy as np, pandas as pd, joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.adaptive_fusion import fit_safe_adaptive_fusion,predict_safe_adaptive_fusion,source_utility_summary
from psc_prior_al.adaptive_granularity import fit_adaptive_granularity,predict_adaptive_granularity,granularity_summary
warnings.filterwarnings('ignore')


def thin(df,maxn=6):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); idx=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int)); out.append(g.iloc[idx])
    return pd.concat(out,ignore_index=True)

def rmse(y,p): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seeds',type=int,default=10); ap.add_argument('--quick',action='store_true'); a=ap.parse_args()
    c=load_config('configs/default.yaml');root=Path('.');proc=resolve(root,c['paths']['processed']);res=resolve(root,c['paths']['results']);res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cs=pd.read_csv(proc/'chakar_daily_shape.csv'); cstress=pd.read_csv(proc/'chakar_stress_shape.csv')
    ea=float(c['model']['arrhenius_ea_ev_prior']); hold=float(c['benchmark']['holdout_temperature_c'])
    test=thin(d[d.temperature_c==hold]); pool=d[d.temperature_c!=hold]; groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)

    # Granularity families.  'coarse' deliberately ignores context matching; 'fine' forces tight
    # context matching; 'adaptive' contains the full hierarchy and pays a complexity penalty.
    granular_families={
      'coarse_global':['base','H_global','C_global','HC_global'],
      'fixed_fine':['base','H_fine','Cs_fine','HC_fine'],
      'adaptive_granularity':None,
    }
    rows=[];weights=[]
    seeds=range(a.seeds)
    for n in [6,12,24]:
      for seed in seeds:
        rng=np.random.default_rng(seed); ch=groups.iloc[rng.choice(len(groups),n,replace=False)]; tr=thin(pool.merge(ch,on=['temperature_c','sample_id']))
        # v0.5 reference expert
        f05=fit_safe_adaptive_fusion(tr,hp,cs,ea_ev=ea,seed=seed,maxiter=18 if a.quick else 22)
        p05,p0,_=predict_safe_adaptive_fusion(tr,test,f05,hp,cs,ea_ev=ea,seed=seed)
        base_rmse=rmse(test.retention,p0)
        rows.append({'train_devices':n,'seed':seed,'family':'target_only','rmse':base_rmse,'transfer_cv_rmse':f05.baseline_transfer_cv_rmse,'activated':0.0})
        rows.append({'train_devices':n,'seed':seed,'family':'v05_path_MKL','rmse':rmse(test.retention,p05),'transfer_cv_rmse':f05.transfer_cv_rmse,'activated':float(f05.activated)})

        for fam,paths in granular_families.items():
          fg=fit_adaptive_granularity(tr,hp,cs,cstress,ea_ev=ea,allowed_paths=paths,maxiter=18 if a.quick else 22)
          pg,_,_=predict_adaptive_granularity(tr,test,fg,hp,cs,cstress,ea_ev=ea)
          rows.append({'train_devices':n,'seed':seed,'family':fam,'rmse':rmse(test.retention,pg),'transfer_cv_rmse':fg.transfer_cv_rmse,'activated':float(fg.activated)})
          if fam=='adaptive_granularity':
            weights.append({'train_devices':n,'seed':seed,**granularity_summary(fg)})

    out=pd.DataFrame(rows); out.to_csv(res/'adaptive_granularity_v06.csv',index=False)
    wt=pd.DataFrame(weights); wt.to_csv(res/'adaptive_granularity_weights_v06.csv',index=False)

    # Safe model-class expansion: select among target, v0.5, coarse, forced-fine, adaptive using
    # directional transfer CV only.  External 25 C is revealed after selection.
    sel=[]
    for (n,seed),g in out.groupby(['train_devices','seed']):
        r=g.sort_values(['transfer_cv_rmse','family']).iloc[0]
        target=float(g.loc[g.family=='target_only','rmse'].iloc[0])
        sel.append({'train_devices':n,'seed':seed,'selected_family':r.family,'selected_transfer_cv_rmse':r.transfer_cv_rmse,'external_rmse_25C':r.rmse,'target_rmse_25C':target,'external_gain_vs_target':target-r.rmse})
    seld=pd.DataFrame(sel); seld.to_csv(res/'granularity_safe_selector_v06.csv',index=False)

    summ=out.groupby(['train_devices','family']).agg(rmse=('rmse','mean'),transfer_cv=('transfer_cv_rmse','mean'),activation=('activated','mean')).reset_index()
    summ.to_csv(res/'adaptive_granularity_v06_summary.csv',index=False)
    ss=seld.groupby('train_devices').agg(selected_rmse=('external_rmse_25C','mean'),target_rmse=('target_rmse_25C','mean'),gain=('external_gain_vs_target','mean'),P_external_nonworse=('external_gain_vs_target',lambda x:float(np.mean(np.asarray(x)>=-1e-12)))).reset_index()
    ss.to_csv(res/'granularity_safe_selector_v06_summary.csv',index=False)
    freq=(seld.groupby(['train_devices','selected_family']).size()/seld.groupby('train_devices').size()).rename('selection_frequency').reset_index(); freq.to_csv(res/'granularity_safe_selector_v06_frequency.csv',index=False)
    if len(wt):
        cols=[c for c in ['H_mass','H_granularity','C_mass','C_granularity','Cs_mass','Cs_granularity','HC_mass','HC_granularity','gamma','activated'] if c in wt]
        ws=wt.groupby('train_devices')[cols].mean().reset_index(); ws.to_csv(res/'adaptive_granularity_weights_v06_summary.csv',index=False)
    print('\nExternal 25 C audit by family')
    print(summ.round(4).to_string(index=False))
    print('\nGranularity-safe selector')
    print(ss.round(4).to_string(index=False))
    print('\nSelection frequencies')
    print(freq.round(3).to_string(index=False))
    if len(wt):
        print('\nLearned source granularity (0 global -> 3 fine)')
        print(ws.round(3).to_string(index=False))

if __name__=='__main__': main()
