#!/usr/bin/env bash
set -euo pipefail
export PYTHONPATH="${PYTHONPATH:-}:src"
python scripts/01_audit_data.py
python scripts/02_build_priors.py
python scripts/15_adaptive_granularity_alignment.py --quick --seeds 3
