import numpy as np
import pandas as pd
from psc_prior_al.adaptive_granularity import pathway_kernels, PATH_NAMES
from psc_prior_al.priors import chakar_stress_prior_stats


def test_pathway_kernel_shapes_and_symmetry():
    rng=np.random.default_rng(0); x=rng.normal(size=(7,7))
    k=pathway_kernels(x,x)
    assert tuple(k.keys())==PATH_NAMES
    for a in k.values():
        assert a.shape==(7,7)
        assert np.allclose(a,a.T,atol=1e-10)
        assert np.allclose(np.diag(a),1.0,atol=1e-10)


def test_stress_prior_interpolation():
    g=pd.DataFrame({'stress_h':[0.,10.,20.],'retention':[1.,0.9,0.8],'std':[0.05,0.06,0.07]})
    mu,sd=chakar_stress_prior_stats(np.array([5.,15.]),g)
    assert np.allclose(mu,[0.95,0.85])
    assert np.all(sd>=0.05)
