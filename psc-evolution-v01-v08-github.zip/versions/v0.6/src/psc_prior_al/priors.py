from __future__ import annotations
import numpy as np
import pandas as pd

KB_EV_K = 8.617333262145e-5


def arrhenius_acceleration(temperature_c, ref_c=25.0, ea_ev=0.45):
    T = np.asarray(temperature_c, dtype=float) + 273.15
    Tr = ref_c + 273.15
    return np.exp((-ea_ev / KB_EV_K) * (1.0 / T - 1.0 / Tr))


def _warp_time(time_h, temperature_c, ea_ev, ref_c=25.0, reverse_temperature=False):
    a = arrhenius_acceleration(temperature_c, ref_c, ea_ev)
    if reverse_temperature:
        a = 1.0 / np.clip(a, 1e-8, None)
    return np.asarray(time_h, float) * a


def hartono_prior_stats(time_h, temperature_c, hartono_artifact: dict,
                        ea_ev=0.45, ref_c=25.0, reverse_temperature=False):
    """Return source-only prior mean and uncertainty from Hartono FPCA.

    Uncertainty is estimated from the empirical FPCA score covariance, projected back
    to trajectory space. No target labels are used here.
    """
    grid = np.asarray(hartono_artifact['grid_h'], float)
    mean_curve = np.asarray(hartono_artifact['mean_curve'], float)
    comps = np.asarray(hartono_artifact.get('components', []), float)
    scores = np.asarray(hartono_artifact.get('scores', []), float)
    if comps.size and scores.size:
        score_var = np.var(scores, axis=0, ddof=1)
        curve_var = np.sum((comps ** 2) * score_var[:, None], axis=0)
        curve_std = np.sqrt(np.maximum(curve_var, 1e-8))
    else:
        curve_std = np.full_like(mean_curve, 0.08)
    te = _warp_time(time_h, temperature_c, ea_ev, ref_c, reverse_temperature)
    mu = np.interp(te, grid, mean_curve, left=mean_curve[0], right=mean_curve[-1])
    sd = np.interp(te, grid, curve_std, left=curve_std[0], right=curve_std[-1])
    return mu, np.maximum(sd, 0.02)


def trajectory_prior(time_h, temperature_c, hartono_grid_h, hartono_mean_curve,
                     ea_ev=0.45, ref_c=25.0):
    """Backwards-compatible Hartono mean prior."""
    te = _warp_time(time_h, temperature_c, ea_ev, ref_c)
    return np.interp(te, hartono_grid_h, hartono_mean_curve,
                     left=hartono_mean_curve[0], right=hartono_mean_curve[-1])


def chakar_daily_shape(chakar_tables: dict, q=0.95, min_irradiance=None) -> pd.DataFrame:
    """Extract a weak outdoor ageing shape from Chakar continuous MPP traces.

    We deliberately use daily high-quantile Pmax instead of raw Pmax because outdoor
    irradiance varies strongly. This remains a *weak* source prior, not a mechanistic
    lifetime estimate. The resulting curve is normalized to the first 14 valid days.
    """
    traces = []
    for key, df in chakar_tables.items():
        if not key.lower().startswith('outdoor_mpp'):
            continue
        if not {'Time', 'Pmax'}.issubset(df.columns):
            continue
        x = df[['Time', 'Pmax']].copy()
        x['Time'] = pd.to_datetime(x['Time'], errors='coerce')
        x['Pmax'] = pd.to_numeric(x['Pmax'], errors='coerce')
        x = x.dropna().sort_values('Time')
        if len(x) == 0:
            continue
        x['date'] = x['Time'].dt.floor('D')
        daily = x.groupby('date')['Pmax'].quantile(q).rename('p').reset_index()
        daily['channel'] = key
        traces.append(daily)
    if not traces:
        return pd.DataFrame(columns=['age_h', 'retention', 'std', 'n_channels'])
    all_daily = pd.concat(traces, ignore_index=True)
    t0 = all_daily['date'].min()
    all_daily['age_h'] = (all_daily['date'] - t0).dt.total_seconds() / 3600.0
    normed = []
    for ch, g in all_daily.groupby('channel'):
        g = g.sort_values('age_h').copy()
        early = g[g.age_h <= 14 * 24]['p']
        base = float(early.median()) if len(early) else float(g['p'].iloc[:min(14, len(g))].median())
        if not np.isfinite(base) or base <= 0:
            continue
        g['retention'] = g['p'] / base
        normed.append(g[['age_h', 'retention', 'channel']])
    if not normed:
        return pd.DataFrame(columns=['age_h', 'retention', 'std', 'n_channels'])
    d = pd.concat(normed, ignore_index=True)
    # align on daily age bins, robust across channels
    d['day'] = np.round(d['age_h'] / 24.0).astype(int)
    s = d.groupby('day')['retention'].agg(['median', 'std', 'count']).reset_index()
    s['age_h'] = s['day'] * 24.0
    s['std'] = s['std'].fillna(0.08).clip(lower=0.03)
    return s.rename(columns={'median': 'retention', 'count': 'n_channels'})[['age_h', 'retention', 'std', 'n_channels']]


def chakar_prior_stats(time_h, chakar_shape: pd.DataFrame):
    if chakar_shape is None or len(chakar_shape) < 2:
        x = np.asarray(time_h, float)
        return np.ones_like(x), np.full_like(x, 0.25)
    g = chakar_shape.sort_values('age_h')
    x = np.asarray(time_h, float)
    mu = np.interp(x, g.age_h, g.retention, left=g.retention.iloc[0], right=g.retention.iloc[-1])
    sd = np.interp(x, g.age_h, g['std'], left=g['std'].iloc[0], right=g['std'].iloc[-1])
    return mu, np.maximum(sd, 0.05)



def chakar_stress_shape(chakar_tables: dict, ea_ev: float = 0.45, q: float = 0.95) -> pd.DataFrame:
    """Build an outdoor degradation curve versus cumulative thermo-optical stress.

    Stress is expressed in *equivalent 25 C, 1-sun hours*:

        dS = dt[h] * max(Irradiance,0)/1000 * a(T_cell; 25 C, Ea)

    where ``a`` is the Arrhenius acceleration factor.  This is deliberately treated as
    a candidate alignment coordinate, not as a validated universal damage law.  The
    target model is free to ignore the resulting pathway.
    """
    env = chakar_tables.get('irradiance_and_cell_temp')
    if env is None or len(env) < 2 or not {'Time','Irradiance','Tcell_back'}.issubset(env.columns):
        return pd.DataFrame(columns=['stress_h','retention','std','n_channels','age_h'])
    e=env[['Time','Irradiance','Tcell_back']].copy()
    e['Time']=pd.to_datetime(e['Time'],errors='coerce')
    e['Irradiance']=pd.to_numeric(e['Irradiance'],errors='coerce')
    e['Tcell_back']=pd.to_numeric(e['Tcell_back'],errors='coerce')
    e=e.dropna().sort_values('Time')
    if len(e)<2:
        return pd.DataFrame(columns=['stress_h','retention','std','n_channels','age_h'])
    dt=e['Time'].diff().dt.total_seconds().div(3600.0).fillna(0.0).clip(lower=0.0,upper=0.25).to_numpy(float)
    irr=np.clip(e['Irradiance'].to_numpy(float),0.0,None)/1000.0
    acc=arrhenius_acceleration(e['Tcell_back'].to_numpy(float),25.0,ea_ev)
    inc=dt*irr*acc
    e['stress_h']=np.cumsum(np.nan_to_num(inc,nan=0.0,posinf=0.0,neginf=0.0))
    e['date']=e['Time'].dt.floor('D')
    daily_stress=e.groupby('date')['stress_h'].max().rename('stress_h').reset_index()

    traces=[]
    for key,df in chakar_tables.items():
        if not key.lower().startswith('outdoor_mpp') or not {'Time','Pmax'}.issubset(df.columns):
            continue
        x=df[['Time','Pmax']].copy(); x['Time']=pd.to_datetime(x['Time'],errors='coerce'); x['Pmax']=pd.to_numeric(x['Pmax'],errors='coerce')
        x=x.dropna().sort_values('Time')
        if len(x)==0: continue
        x['date']=x['Time'].dt.floor('D')
        d=x.groupby('date')['Pmax'].quantile(q).rename('p').reset_index().merge(daily_stress,on='date',how='inner')
        d['channel']=key; traces.append(d)
    if not traces:
        return pd.DataFrame(columns=['stress_h','retention','std','n_channels','age_h'])
    all_daily=pd.concat(traces,ignore_index=True)
    t0=all_daily['date'].min(); all_daily['age_h']=(all_daily['date']-t0).dt.total_seconds()/3600.0
    norm=[]
    for ch,g in all_daily.groupby('channel'):
        g=g.sort_values('age_h').copy(); early=g[g.age_h<=14*24]['p']
        base=float(early.median()) if len(early) else float(g['p'].iloc[:min(14,len(g))].median())
        if not np.isfinite(base) or base<=0: continue
        g['retention']=g['p']/base; norm.append(g[['date','age_h','stress_h','retention','channel']])
    if not norm:
        return pd.DataFrame(columns=['stress_h','retention','std','n_channels','age_h'])
    d=pd.concat(norm,ignore_index=True); d['day']=np.round(d['age_h']/24.0).astype(int)
    s=d.groupby('day').agg(stress_h=('stress_h','median'),age_h=('age_h','median'),retention=('retention','median'),std=('retention','std'),n_channels=('retention','count')).reset_index(drop=True)
    s['std']=s['std'].fillna(0.08).clip(lower=0.03)
    s=s.sort_values('stress_h').drop_duplicates('stress_h')
    return s[['stress_h','retention','std','n_channels','age_h']]


def chakar_stress_prior_stats(stress_h, chakar_stress: pd.DataFrame):
    if chakar_stress is None or len(chakar_stress)<2:
        x=np.asarray(stress_h,float); return np.ones_like(x),np.full_like(x,0.25)
    g=chakar_stress.sort_values('stress_h'); x=np.asarray(stress_h,float)
    mu=np.interp(x,g.stress_h,g.retention,left=g.retention.iloc[0],right=g.retention.iloc[-1])
    sd=np.interp(x,g.stress_h,g['std'],left=g['std'].iloc[0],right=g['std'].iloc[-1])
    return mu,np.maximum(sd,0.05)

def combine_source_priors(h_mu, c_mu=None, w_h=1.0, w_c=0.0, neutral=1.0):
    """Convex prior mixture with an explicit neutral component.

    weights satisfy w_h >= 0, w_c >= 0, w_h + w_c <= 1.
    Neutral=1 means 'no expected retention loss'.
    """
    h_mu = np.asarray(h_mu, float)
    if c_mu is None:
        c_mu = np.full_like(h_mu, neutral)
    c_mu = np.asarray(c_mu, float)
    w_h = float(np.clip(w_h, 0, 1)); w_c = float(np.clip(w_c, 0, 1 - w_h))
    w_0 = 1.0 - w_h - w_c
    return w_0 * neutral + w_h * h_mu + w_c * c_mu


def combine_prior_std(h_sd, c_sd=None, w_h=1.0, w_c=0.0, neutral_sd=0.20):
    h_sd = np.asarray(h_sd, float)
    if c_sd is None:
        c_sd = np.full_like(h_sd, neutral_sd)
    c_sd = np.asarray(c_sd, float)
    w_h = float(np.clip(w_h, 0, 1)); w_c = float(np.clip(w_c, 0, 1 - w_h)); w_0 = 1-w_h-w_c
    return np.sqrt((w_h*h_sd)**2 + (w_c*c_sd)**2 + (w_0*neutral_sd)**2)


def chakar_prior_strength(chakar_tables: dict) -> dict:
    result = {'available': False}
    jv = chakar_tables.get('outdoor_jvs')
    if jv is not None and len(jv):
        result.update({'available': True, 'n_outdoor_jv_rows': int(len(jv)),
                       'n_cells': int(jv['cell_id'].nunique()) if 'cell_id' in jv else None})
    shape = chakar_daily_shape(chakar_tables)
    result['n_shape_days'] = int(len(shape))
    if len(shape):
        result['shape_duration_h'] = float(shape.age_h.max())
        result['shape_final_retention'] = float(shape.retention.iloc[-1])
    return result
