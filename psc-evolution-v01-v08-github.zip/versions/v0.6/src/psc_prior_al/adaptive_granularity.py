from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Tuple
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .priors import (
    hartono_prior_stats,
    chakar_prior_stats,
    chakar_stress_prior_stats,
    arrhenius_acceleration,
)

# Hierarchy: 0 global -> 1 phase -> 2 context -> 3 fine physical alignment.
# Fine paths carry a stronger complexity penalty and are activated only if directional
# low-temperature transfer CV supports them.
PATH_SPECS = {
    'base':            {'source':'target','level':0,'complexity':0.0},
    'H_global':        {'source':'H','level':0,'complexity':0.0010},
    'H_phase':         {'source':'H','level':1,'complexity':0.0020},
    'H_context':       {'source':'H','level':2,'complexity':0.0040},
    'H_fine':          {'source':'H','level':3,'complexity':0.0080},
    'C_global':        {'source':'C','level':0,'complexity':0.0010},
    'C_phase':         {'source':'C','level':1,'complexity':0.0020},
    'C_context':       {'source':'C','level':2,'complexity':0.0040},
    'Cs_global':       {'source':'Cs','level':1,'complexity':0.0025},
    'Cs_context':      {'source':'Cs','level':2,'complexity':0.0050},
    'Cs_fine':         {'source':'Cs','level':3,'complexity':0.0100},
    'HC_global':       {'source':'HC','level':0,'complexity':0.0015},
    'HC_context':      {'source':'HC','level':2,'complexity':0.0050},
    'HC_fine':         {'source':'HC','level':3,'complexity':0.0100},
}
PATH_NAMES = tuple(PATH_SPECS)


def _device_keys(df: pd.DataFrame) -> np.ndarray:
    return np.asarray([f"{t}|{s}" for t,s in zip(df.temperature_c,df.sample_id)])


def _progress(df: pd.DataFrame) -> np.ndarray:
    u=np.zeros(len(df),float)
    for _,idx in df.groupby(['temperature_c','sample_id']).indices.items():
        ii=np.asarray(idx,dtype=int); t=df.iloc[ii].time_h.to_numpy(float)
        u[ii]=t/max(float(np.nanmax(t)),1.0)
    return np.clip(u,0,1)


def _group_rmse(y,pred,keys):
    vals=[]
    for g in np.unique(keys):
        m=keys==g; vals.append(float(np.sqrt(np.mean((y[m]-pred[m])**2))))
    return float(np.mean(vals))


def _transfer_score(y,pred,keys,fold_t):
    vals=[]
    for t in np.unique(fold_t):
        m=fold_t==t; vals.append(_group_rmse(y[m],pred[m],keys[m]))
    return float(np.mean(vals))


def _cv_folds(train: pd.DataFrame, mode='directional_lower'):
    temp=train.temperature_c.to_numpy(float); uniq=np.sort(np.unique(temp)); folds=[]
    if mode=='directional_lower':
        for tv in uniq:
            tr=np.where(temp>tv)[0]; va=np.where(temp==tv)[0]
            if len(va) and len(np.unique(temp[tr]))>=2: folds.append((tr,va,float(tv)))
    elif mode=='loto':
        for tv in uniq:
            tr=np.where(temp!=tv)[0]; va=np.where(temp==tv)[0]
            if len(tr) and len(va): folds.append((tr,va,float(tv)))
    else:
        raise ValueError(mode)
    if not folds:
        for tv in uniq:
            tr=np.where(temp!=tv)[0]; va=np.where(temp==tv)[0]
            if len(tr) and len(va): folds.append((tr,va,float(tv)))
    return folds


def _standardize(z, stats=None):
    if stats is None:
        mean=np.nanmean(z,axis=0); std=np.nanstd(z,axis=0); std[std<1e-6]=1.0; stats=(mean,std)
    return (z-stats[0])/stats[1],stats


def factor_matrix(df: pd.DataFrame, hp: dict, cshape: pd.DataFrame, cstress: pd.DataFrame,
                  ea_ev: float=0.45, stats=None):
    """Return standardized [log_time, B, progress, log_stress, H, C, Cs].

    H  : generic Hartono normalized-progress shape.
    C  : generic Chakar normalized-progress shape.
    Cs : Chakar shape aligned by cumulative thermo-optical stress.

    Only source data and experimental-condition covariates are used. Target retention labels
    are never used to construct these factors.
    """
    t=df.time_h.to_numpy(float); T=df.temperature_c.to_numpy(float); u=_progress(df)
    acc=arrhenius_acceleration(T,25.0,ea_ev)
    stress=np.maximum(t*acc,0.0)  # target proxy: controlled 1-sun equivalent stress hours
    B=np.log(np.clip(acc,1e-12,None))
    B=B/max(float(np.nanstd(B)),1e-6)

    hgrid=np.asarray(hp['grid_h'],float)
    hm,_=hartono_prior_stats(u*float(hgrid.max()),np.full(len(df),25.),hp,ea_ev=0.0)
    cmax=max(float(cshape.age_h.max()),1.0) if cshape is not None and len(cshape) else 1.0
    cm,_=chakar_prior_stats(u*cmax,cshape)
    csm,_=chakar_stress_prior_stats(stress,cstress)
    z=np.c_[
        np.log1p(t)/np.log1p(2500.0),
        B,
        u,
        np.log1p(stress)/np.log1p(max(float(np.nanmax(stress)),1.0)),
        hm-1.0,
        cm-1.0,
        csm-1.0,
    ]
    return _standardize(z,stats)


def _rbf(x,y,cols,ells=None):
    a=x[:,list(cols)]; b=y[:,list(cols)]
    if ells is None: ells=np.ones(len(cols))
    e=np.asarray(ells,float).reshape(1,-1)
    a=a/e; b=b/e
    d2=np.sum((a[:,None,:]-b[None,:,:])**2,axis=-1)
    return np.exp(-0.5*d2)


def pathway_kernels(x,y) -> Dict[str,np.ndarray]:
    # columns: 0 log_time,1 B,2 progress,3 log_stress,4 H,5 C,6 Cs
    base=_rbf(x,y,(0,1),(1.0,1.0))
    kh=_rbf(x,y,(4,),(1.0,)); kc=_rbf(x,y,(5,),(1.0,)); kcs=_rbf(x,y,(6,),(1.0,)); khc=_rbf(x,y,(4,5),(1.0,1.0))
    phase=_rbf(x,y,(2,),(0.9,))
    ctx_coarse=_rbf(x,y,(1,2),(1.6,0.9))
    ctx_fine=_rbf(x,y,(1,2,3),(0.60,0.35,0.65))
    stress_ctx=_rbf(x,y,(1,3),(1.2,0.8))
    stress_fine=_rbf(x,y,(1,2,3),(0.55,0.30,0.50))
    return {
        'base': base,
        'H_global': kh,
        'H_phase': kh*phase,
        'H_context': kh*ctx_coarse,
        'H_fine': kh*ctx_fine,
        'C_global': kc,
        'C_phase': kc*phase,
        'C_context': kc*ctx_coarse,
        'Cs_global': kcs,
        'Cs_context': kcs*stress_ctx,
        'Cs_fine': kcs*stress_fine,
        'HC_global': khc,
        'HC_context': khc*ctx_coarse,
        'HC_fine': khc*ctx_fine,
    }


def _weighted_kernel(kernels,weights):
    return sum(float(weights[i])*kernels[n] for i,n in enumerate(PATH_NAMES))


def _fit_kernel(k,y,ridge):
    mu=float(np.mean(y)); alpha=np.linalg.solve(k+ridge*np.eye(len(y)),y-mu); return mu,alpha


def _cv_predictions(train,kernels,weights,ridge,mode):
    y=train.retention.to_numpy(float); keys=_device_keys(train)
    ps=[]; ys=[]; gs=[]; ts=[]
    for tr,va,tv in _cv_folds(train,mode):
        ktr=_weighted_kernel({n:k[np.ix_(tr,tr)] for n,k in kernels.items()},weights)
        kva=_weighted_kernel({n:k[np.ix_(va,tr)] for n,k in kernels.items()},weights)
        mu,a=_fit_kernel(ktr,y[tr],ridge); ps.append(mu+kva@a); ys.append(y[va]); gs.append(keys[va]); ts.append(np.repeat(tv,len(va)))
    return np.concatenate(ps),np.concatenate(ys),np.concatenate(gs),np.concatenate(ts)


@dataclass
class GranularityFit:
    weights: np.ndarray
    ridge: float
    baseline_ridge: float
    gamma: float
    transfer_cv_rmse: float
    baseline_transfer_cv_rmse: float
    validation_gain: float
    activated: bool
    activation_threshold: float
    stats: Tuple[np.ndarray,np.ndarray]
    cv_mode: str

    def weight_dict(self): return {n:float(v) for n,v in zip(PATH_NAMES,self.weights)}


def fit_adaptive_granularity(train: pd.DataFrame, hp: dict, cshape: pd.DataFrame, cstress: pd.DataFrame,
                             ea_ev: float=0.45, ridge_grid=(0.01,0.03,0.08), cv_mode='directional_lower',
                             maxiter: int=32, min_transfer_gain: float=0.002,
                             min_relative_transfer_gain: float=0.04, allowed_paths: Iterable[str]|None=None):
    x,stats=factor_matrix(train,hp,cshape,cstress,ea_ev,None); K=pathway_kernels(x,x)
    n=len(PATH_NAMES); base=np.zeros(n); base[0]=1.0
    allowed=set(PATH_NAMES if allowed_paths is None else allowed_paths); allowed.add('base')
    mask=np.asarray([p in allowed for p in PATH_NAMES],bool)

    # independently tune target-only baseline
    base_cands=[]
    for r in ridge_grid:
        p,y,g,t=_cv_predictions(train,K,base,float(r),cv_mode)
        base_cands.append((_transfer_score(y,p,g,t),float(r),p,y,g,t))
    base_score,base_ridge,base_oof,cv_y,cv_g,cv_t=min(base_cands,key=lambda z:z[0])

    starts=[]
    z=np.zeros(n); z[0]=0.55; z[1:]=0.45/(n-1); starts.append(z)
    z=np.zeros(n); z[0]=0.70; z[[3,7,9,12]]=0.075; starts.append(z)
    z=np.repeat(1/n,n); starts.append(z)
    z=base.copy(); starts.append(z)
    proj=[]
    for z in starts:
        z=z*mask
        z=base.copy() if z.sum()<=0 else z/z.sum(); proj.append(z)

    bounds=[(0,1) if ok else (0,0) for ok in mask]
    constraint={'type':'eq','fun':lambda w:float(np.sum(w)-1.0)}
    complexities=np.asarray([PATH_SPECS[n]['complexity'] for n in PATH_NAMES],float)
    best=None;best_r=None;best_obj=np.inf
    for r in ridge_grid:
        def obj(w):
            p,y,g,t=_cv_predictions(train,K,w,float(r),cv_mode)
            risk=_transfer_score(y,p,g,t)
            # hierarchical shrinkage: finer/more specific contexts need stronger evidence
            penalty=float(np.sum(complexities*np.sqrt(np.clip(w,0,None))))
            return risk+penalty
        for x0 in proj:
            res=minimize(obj,x0=x0,bounds=bounds,constraints=constraint,method='SLSQP',options={'maxiter':maxiter,'ftol':2e-4,'disp':False})
            if res.fun<best_obj:
                best_obj=float(res.fun);best=np.asarray(res.x,float);best_r=float(r)
    if best is None: best=base.copy(); best_r=float(ridge_grid[0])

    po,y,g,t=_cv_predictions(train,K,best,best_r,cv_mode)
    gammas=np.linspace(0,1,21); scores=[]
    for gg in gammas:
        pp=base_oof+gg*(po-base_oof); scores.append(_transfer_score(cv_y,pp,cv_g,cv_t))
    j=int(np.argmin(scores)); gamma=float(gammas[j]); score=float(scores[j]); gain=float(base_score-score)
    threshold=max(float(min_transfer_gain),float(min_relative_transfer_gain)*float(base_score))
    activated=bool(gain>=threshold)
    if not activated: gamma=0.0; score=float(base_score); gain=0.0
    return GranularityFit(best,best_r,base_ridge,gamma,score,float(base_score),gain,activated,threshold,stats,cv_mode)


def predict_adaptive_granularity(train,test,fit,hp,cshape,cstress,ea_ev=0.45):
    xtr,_=factor_matrix(train,hp,cshape,cstress,ea_ev,fit.stats); xte,_=factor_matrix(test,hp,cshape,cstress,ea_ev,fit.stats)
    Ktr=pathway_kernels(xtr,xtr); Kte=pathway_kernels(xte,xtr); y=train.retention.to_numpy(float)
    base=np.zeros(len(PATH_NAMES)); base[0]=1.0
    def pred(w,r):
        kt=_weighted_kernel(Ktr,w); ks=_weighted_kernel(Kte,w); mu,a=_fit_kernel(kt,y,r); return mu+ks@a
    p0=pred(base,fit.baseline_ridge); pf=pred(fit.weights,fit.ridge); return p0+fit.gamma*(pf-p0),p0,pf


def granularity_summary(fit: GranularityFit) -> dict:
    w=fit.weight_dict()
    out={f'w_{k}':v for k,v in w.items()}
    for src in ['H','C','Cs','HC']:
        vals=[]; masses=[]
        for name,val in w.items():
            if PATH_SPECS[name]['source']==src:
                vals.append(PATH_SPECS[name]['level']*val); masses.append(val)
        mass=float(np.sum(masses)); out[f'{src}_mass']=mass; out[f'{src}_granularity']=float(np.sum(vals)/mass) if mass>1e-10 else np.nan
    out.update({
        'gamma':fit.gamma,'activated':float(fit.activated),'transfer_cv_rmse':fit.transfer_cv_rmse,
        'baseline_transfer_cv_rmse':fit.baseline_transfer_cv_rmse,'validation_gain':fit.validation_gain,
        'activation_threshold':fit.activation_threshold,
    })
    return out
