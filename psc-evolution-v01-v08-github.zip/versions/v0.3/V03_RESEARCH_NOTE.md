# v0.3 Research Note — Learning Whether a Dataset Is Useful

## Question
Researchers often pool every accessible dataset and only discover after training that a source causes negative transfer. v0.3 asks a stricter question: **can the model diagnose how a source is useful before deciding whether to keep or discard it?**

A source may be:
1. directly useful;
2. directly harmful;
3. apparently harmful only because the target calibration set is too small (underlearned);
4. directly harmful but indirectly useful because its factor modifies another target-domain factor;
5. redundant.

## Factor graph
For the current data we set Accelerated-v2 as target domain B. Hartono and Chakar are alternately audited as candidate source C, so the result is not an artifact of naming.

For source C, v0.3 compares the direct path `C -> y` with the mediated path `C -> (C x B) -> y`. A residual GP is used in all models, so improvements cannot be attributed merely to giving one architecture a more flexible final learner.

## Pilot result (5 random splits)
When Hartono is audited as C, the direct A+C model is slightly worse than A-only for N=6,12,24 target devices, but the mediated model is better at every budget. Mean 25 C RMSE:

| N target devices | A-only | direct A+C | A + CxB mediated | full graph |
|---:|---:|---:|---:|---:|
| 6 | 0.1337 | 0.1353 | 0.1203 | 0.1063 |
| 12 | 0.1471 | 0.1482 | 0.1155 | 0.1152 |
| 24 | 0.1522 | 0.1532 | 0.1143 | 0.1058 |

Thus simply concluding “Hartono is harmful because direct pooling worsens RMSE” would be wrong. Its shape signal appears useful when coupled to the target temperature factor.

Chakar is more budget-dependent: it helps directly at N=6 and N=24, is mildly harmful at N=12 in direct form, and the full interaction graph remains substantially better than A-only in all three pilot budgets.

## What this does NOT prove
This is not causal identification. The interaction is predictive mediation under a predefined factor graph. Publication-level evidence requires more seeds, alternative holdout temperatures/protocols, source corruption controls, permutation controls, and an independent external target dataset.
