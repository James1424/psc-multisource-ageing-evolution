from psc_prior_al.source_auditor import candidate_specs

def test_full_path_attribution_safe_hartono():
    s=candidate_specs('Hartono')
    assert 'C_x_B' not in s['full_C']  # A x B must not be credited to candidate Hartono
    assert 'H_x_B' in s['full_C']
    assert 'H_x_C' in s['full_C']

def test_full_path_attribution_safe_chakar():
    s=candidate_specs('Chakar')
    assert 'H_x_B' not in s['full_C']  # A x B must not be credited to candidate Chakar
    assert 'C_x_B' in s['full_C']
    assert 'H_x_C' in s['full_C']
