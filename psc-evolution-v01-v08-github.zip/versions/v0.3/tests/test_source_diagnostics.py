import numpy as np, pandas as pd
from psc_prior_al.source_diagnostics import _ridge_fit,_ridge_predict,diagnose_source_c

def test_weighted_ridge_recovers_linear_signal():
    x=np.arange(10.)[:,None]; y=2+3*x[:,0]
    b=_ridge_fit(x,y,np.ones(10),1e-8); p=_ridge_predict(x,b)
    assert np.max(np.abs(p-y))<1e-5

def test_diagnosis_indirect_use():
    s=pd.DataFrame({'train_devices':[6,6,6], 'model':['A_direct','A_C_direct','A_plus_C_mediates_B'], 'rmse_mean':[.15,.17,.13]})
    d=diagnose_source_c(s)
    assert d.C_status.iloc[0]=='directly_harmful_indirectly_useful'
