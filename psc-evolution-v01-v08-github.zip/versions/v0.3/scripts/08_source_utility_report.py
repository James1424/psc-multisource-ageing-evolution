"""Aggregate paired source diagnostics into an automatic source-utility report."""
from pathlib import Path
import pandas as pd, numpy as np

R=Path('results')
d=pd.read_csv(R/'bidirectional_source_diagnosis_v03.csv')
rows=[]
for (cand,n,seed),g in d.groupby(['candidate_C','train_devices','seed']):
    m=g.set_index('model').rmse.to_dict()
    rows.append({
        'candidate_C':cand,'train_devices':n,'seed':seed,
        'direct_delta':m['A_C_direct']-m['A_direct'],
        'mediated_delta':m['A_plus_C_mediates_B']-m['A_direct'],
        'full_delta':m['full_source_graph']-m['A_direct'],
    })
p=pd.DataFrame(rows); p.to_csv(R/'source_utility_paired_deltas_v03.csv',index=False)
summary=[]
for (cand,n),g in p.groupby(['candidate_C','train_devices']):
    dd=g.direct_delta.to_numpy(); md=g.mediated_delta.to_numpy(); fd=g.full_delta.to_numpy()
    # Utility score is positive when predictive error is reduced. Direct and mediated are reported separately.
    direct_u=-dd.mean(); med_u=-md.mean(); full_u=-fd.mean()
    prob_direct_harm=float(np.mean(dd>0)); prob_mediated_help=float(np.mean(md<0)); prob_full_help=float(np.mean(fd<0))
    if prob_direct_harm>=0.6 and prob_mediated_help>=0.6:
        cls='directly_harmful_but_mediated_useful'
    elif prob_direct_harm>=0.6 and prob_mediated_help<0.4:
        cls='likely_harmful_at_this_budget'
    elif prob_direct_harm<0.4 and prob_mediated_help>=0.6:
        cls='direct_and_or_mediated_useful'
    else:
        cls='uncertain_or_redundant'
    summary.append({
        'candidate_C':cand,'train_devices':n,
        'direct_utility':direct_u,'mediated_utility':med_u,'full_graph_utility':full_u,
        'P_direct_harm':prob_direct_harm,'P_mediated_help':prob_mediated_help,'P_full_help':prob_full_help,
        'classification':cls,
    })
s=pd.DataFrame(summary); s.to_csv(R/'source_utility_score_v03.csv',index=False)
# Cross-budget classification separates underlearned from intrinsically harmful.
cross=[]
for cand,g in s.groupby('candidate_C'):
    g=g.sort_values('train_devices')
    small=g.iloc[0]; large=g.iloc[-1]
    if small.P_direct_harm>=0.6 and large.P_direct_harm<0.4:
        state='underlearned_at_small_N'
    elif (g.P_direct_harm>=0.6).all() and (g.P_mediated_help>=0.6).all():
        state='directly_harmful_but_consistently_mediated_useful'
    elif (g.P_direct_harm>=0.6).all() and (g.P_mediated_help<0.4).all():
        state='consistently_harmful_under_tested_paths'
    else:
        state='budget_dependent_or_mixed'
    cross.append({'candidate_C':cand,'cross_budget_state':state})
pd.DataFrame(cross).to_csv(R/'source_utility_cross_budget_v03.csv',index=False)
print(s.round(4).to_string(index=False)); print('\n',pd.DataFrame(cross).to_string(index=False))
