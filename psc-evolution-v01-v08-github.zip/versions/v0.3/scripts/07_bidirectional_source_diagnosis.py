"""Bidirectional source utility diagnosis.
Each source is alternately treated as candidate C while the other source is A.
This avoids conclusions that depend on arbitrary A/B/C naming.
"""
from pathlib import Path
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.models import ResidualGP
from psc_prior_al.metrics import rmse
from psc_prior_al.transfer import default_feature
from psc_prior_al.source_diagnostics import source_factor_frame,fit_grouped_ridge_mean,predict_grouped_ridge_mean


def thin(df,maxn=12):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); idx=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int)); out.append(g.iloc[idx])
    return pd.concat(out,ignore_index=True)


def specs(candidate):
    if candidate=='Chakar':
        A='H'; C='C'; CxB='C_x_B'; AxB='H_x_B'
    else:
        A='C'; C='H'; CxB='H_x_B'; AxB='C_x_B'
    return {
      'B_only':[],
      'A_direct':[A],
      'C_direct':[C],
      'A_C_direct':[A,C],
      'A_plus_C_mediates_B':[A,CxB],
      'full_source_graph':[A,C,AxB,CxB,'H_x_C'],
    }


def eval_one(train,test,hp,cshape,c,features):
    ea=float(c['model']['arrhenius_ea_ev_prior']); ftr=source_factor_frame(train,hp,cshape,ea); fte=source_factor_frame(test,hp,cshape,ea)
    fit=fit_grouped_ridge_mean(train,ftr,features,max_folds=4)
    ptr=predict_grouped_ridge_mean(fit,ftr) if features else None; pte=predict_grouped_ridge_mean(fit,fte) if features else None
    m=ResidualGP(c['model']['gp_alpha'],c['model']['random_state'],n_restarts_optimizer=0).fit(default_feature(train,ea),train.retention.to_numpy(),ptr)
    mu,_=m.predict(default_feature(test,ea),pte)
    return rmse(test.retention.to_numpy(),mu),fit


def main():
    c=load_config('configs/default.yaml'); root=Path('.'); proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cs=pd.read_csv(proc/'chakar_daily_shape.csv')
    hold=float(c['benchmark']['holdout_temperature_c']); test=thin(d[d.temperature_c==hold]); pool=d[d.temperature_c!=hold]
    groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rows=[]
    for candidate in ['Chakar','Hartono']:
      sp=specs(candidate)
      for n in [6,12,24]:
       for seed in [0,1,2,3,4]:
        rng=np.random.default_rng(seed); chosen=groups.iloc[rng.choice(len(groups),min(n,len(groups)),replace=False)]; train=thin(pool.merge(chosen,on=['temperature_c','sample_id']))
        for model,feats in sp.items():
          e,fit=eval_one(train,test,hp,cs,c,feats)
          row={'candidate_C':candidate,'train_devices':n,'seed':seed,'model':model,'rmse':e}
          for k,v in fit.get('coef',{}).items(): row['coef_'+k]=v
          rows.append(row)
    out=pd.DataFrame(rows); out.to_csv(res/'bidirectional_source_diagnosis_v03.csv',index=False)
    summ=out.groupby(['candidate_C','train_devices','model']).rmse.mean().reset_index(name='rmse_mean'); summ.to_csv(res/'bidirectional_source_diagnosis_v03_summary.csv',index=False)
    diag=[]
    for (cand,n),g in summ.groupby(['candidate_C','train_devices']):
        m=g.set_index('model').rmse_mean.to_dict(); dd=m['A_C_direct']-m['A_direct']; md=m['A_plus_C_mediates_B']-m['A_direct']; fd=m['full_source_graph']-m['A_direct']
        if dd>0 and md<0: status='directly_harmful_indirectly_useful'
        elif dd>0 and md>=0: status='harmful_at_this_budget'
        elif dd<=0 and md<0: status='direct_and_mediated_useful'
        else: status='direct_useful_but_mediation_not_helpful'
        diag.append({'candidate_C':cand,'train_devices':n,'direct_delta':dd,'mediated_delta':md,'full_delta':fd,'status':status})
    diag=pd.DataFrame(diag); diag.to_csv(res/'bidirectional_source_status_v03.csv',index=False)
    print(diag.to_string(index=False))
    print('\nRMSE means\n',summ.pivot_table(index=['candidate_C','train_devices'],columns='model',values='rmse_mean').round(4).to_string())
if __name__=='__main__':main()
