"""Diagnose whether a heterogeneous source is useful, harmful, underlearned, or indirectly useful.

A = Hartono trajectory source
B = Accelerated-v2 target-domain temperature/time factor
C = Chakar outdoor source

The key experiment separates C->y (direct) from C->B-factor->y (mediated) effects.
All factor functions are label-free; only their small calibration coefficients use revealed target devices.
"""
import argparse
from pathlib import Path
import numpy as np, pandas as pd, joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.models import ResidualGP
from psc_prior_al.metrics import rmse,mae,coverage,nlpd
from psc_prior_al.transfer import default_feature
from psc_prior_al.source_diagnostics import source_factor_frame,fit_grouped_ridge_mean,predict_grouped_ridge_mean,MODEL_FEATURES,diagnose_source_c


def thin(df,maxn=18):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h')
        if len(g)>maxn:
            idx=np.unique(np.linspace(0,len(g)-1,maxn).round().astype(int)); g=g.iloc[idx]
        out.append(g)
    return pd.concat(out,ignore_index=True)


def eval_arch(train,test,hp,cshape,c,name):
    ea=float(c['model']['arrhenius_ea_ev_prior'])
    ftr=source_factor_frame(train,hp,cshape,ea); fte=source_factor_frame(test,hp,cshape,ea)
    feats=MODEL_FEATURES[name]
    fit=fit_grouped_ridge_mean(train,ftr,feats,max_folds=4)
    ptr=predict_grouped_ridge_mean(fit,ftr) if feats else None
    pte=predict_grouped_ridge_mean(fit,fte) if feats else None
    Xtr=default_feature(train,ea); Xte=default_feature(test,ea)
    ytr=train.retention.to_numpy(float); yte=test.retention.to_numpy(float)
    m=ResidualGP(c['model']['gp_alpha'],c['model']['random_state'],n_restarts_optimizer=0).fit(Xtr,ytr,ptr)
    mu,std=m.predict(Xte,pte)
    row=dict(model=name,rmse=rmse(yte,mu),mae=mae(yte,mu),coverage95=coverage(yte,mu,std),nlpd=nlpd(yte,mu,std),ridge_alpha=fit.get('alpha'),factor_cv_rmse=fit.get('cv_rmse'))
    for k,v in fit.get('coef',{}).items(): row[f'coef_{k}']=v
    return row


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); ap.add_argument('--quick',action='store_true'); a=ap.parse_args()
    c=load_config(a.config); root=Path('.'); proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cshape=pd.read_csv(proc/'chakar_daily_shape.csv')
    hold=float(c['benchmark']['holdout_temperature_c'])
    maxp=12 if a.quick else int(c['preprocessing']['max_points_per_device_gp'])
    test=thin(d[d.temperature_c==hold],maxp); pool=d[d.temperature_c!=hold]
    groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    sizes=[6,12,24] if a.quick else c['benchmark']['train_devices_grid']
    seeds=[0,1,2] if a.quick else c['benchmark']['seeds']
    rows=[]
    for nreq in sizes:
      for seed in seeds:
        rng=np.random.default_rng(seed); n=min(int(nreq),len(groups)); chosen=groups.iloc[rng.choice(len(groups),n,replace=False)]
        train=thin(pool.merge(chosen,on=['temperature_c','sample_id']),maxp)
        for name in MODEL_FEATURES:
            r=eval_arch(train,test,hp,cshape,c,name); rows.append(dict(seed=seed,train_devices=n,**r))
    out=pd.DataFrame(rows); out.to_csv(res/'source_usefulness_v03.csv',index=False)
    agg={col:['mean','std'] for col in ['rmse','mae','coverage95','nlpd']}
    summary=out.groupby(['train_devices','model']).agg(agg)
    summary.columns=['_'.join(x) for x in summary.columns]; summary=summary.reset_index()
    summary.to_csv(res/'source_usefulness_v03_summary.csv',index=False)
    diag=diagnose_source_c(summary[['train_devices','model','rmse_mean']]); diag.to_csv(res/'source_C_diagnosis_v03.csv',index=False)
    # coefficient means expose the learned paths
    coef_cols=[x for x in out.columns if x.startswith('coef_')]
    if coef_cols:
        coef=out.groupby(['train_devices','model'])[coef_cols].mean().reset_index(); coef.to_csv(res/'source_factor_coefficients_v03.csv',index=False)
    print('\nRMSE by model:')
    print(summary.pivot(index='train_devices',columns='model',values='rmse_mean').round(4).to_string())
    print('\nC diagnosis:')
    print(diag.to_string(index=False))

if __name__=='__main__': main()
