# v0.3 reconstruction note
No standalone v0.3 archive was retained. This folder is reconstructed from the v0.4 archive by retaining the v0.3-era scripts (01–08), source diagnostics code, and corresponding v0.3 result files. No v0.4 audit scripts are used in the v0.3 run.
