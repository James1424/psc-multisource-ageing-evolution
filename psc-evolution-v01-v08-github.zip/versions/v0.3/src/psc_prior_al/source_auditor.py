from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF, WhiteKernel
from sklearn.preprocessing import StandardScaler

from .source_diagnostics import (
    source_factor_frame, fit_grouped_ridge_mean, predict_grouped_ridge_mean,
)
from .transfer import default_feature
from .priors import arrhenius_acceleration


def _group_keys(df: pd.DataFrame):
    return np.array([f"{t}|{s}" for t, s in zip(df.temperature_c, df.sample_id)])


def reverse_within_devices(df: pd.DataFrame, values: np.ndarray) -> np.ndarray:
    """Reverse a source factor along protocol progress within each parent device."""
    out=np.empty(len(df), float)
    values=np.asarray(values,float)
    for _, idx in df.groupby(['temperature_c','sample_id']).indices.items():
        ii=np.asarray(idx,dtype=int)
        order=np.argsort(df.iloc[ii].time_h.to_numpy(float))
        jj=ii[order]
        out[jj]=values[jj][::-1]
    return out


def smooth_null(progress: np.ndarray, scale: float, seed: int=0) -> np.ndarray:
    """Frozen smooth null factor with source-matched scale but no source information."""
    u=np.asarray(progress,float)
    rng=np.random.default_rng(seed)
    p1,p2=rng.uniform(0,2*np.pi,2)
    z=np.sin(2*np.pi*u+p1)+0.5*np.cos(4*np.pi*u+p2)
    z=z-np.mean(z)
    sd=np.std(z)
    if sd<1e-8: return np.zeros_like(z)
    return z/sd*max(float(scale),1e-6)


def candidate_specs(candidate: str):
    """Architectures for auditing candidate source C conditionally on the other source A."""
    if candidate=='Hartono':
        A,C,CxB,AxC='C','H','H_x_B','H_x_C'
    elif candidate=='Chakar':
        A,C,CxB,AxC='H','C','C_x_B','H_x_C'
    else:
        raise ValueError(candidate)
    return {
        'reject_C':[A],
        'direct_C':[A,C],
        'mediated_C':[A,CxB],
        # attribution-safe full path: relative to A baseline, add only C-related terms.
        # Do NOT add A_x_B here, otherwise an apparent C gain could actually come from A.
        'full_C':[A,C,CxB,AxC],
    }


def _b_scale(df, ea_ev):
    acc=arrhenius_acceleration(df.temperature_c.to_numpy(float),25.,ea_ev)
    return max(float(np.nanstd(np.log(np.clip(acc,1e-12,None)))),1e-6)

def make_factor_variant(df, hp, chakar_shape, ea_ev, candidate, variant='real', seed=0, b_scale=None):
    f=source_factor_frame(df,hp,chakar_shape,ea_ev,b_scale=b_scale).copy()
    base='H' if candidate=='Hartono' else 'C'
    if variant=='real':
        return f
    if variant=='reversed':
        v=reverse_within_devices(df,f[base].to_numpy(float))
    elif variant=='smooth_null':
        v=smooth_null(f['progress'].to_numpy(float),np.std(f[base].to_numpy(float)),seed)
    else:
        raise ValueError(variant)
    f[base]=v
    if base=='H':
        f['H_x_B']=f['H']*f['B']; f['H_x_C']=f['H']*f['C']
    else:
        f['C_x_B']=f['C']*f['B']; f['H_x_C']=f['H']*f['C']
    return f


def select_path_by_group_cv(train, factors, candidate, complexity_penalty=0.001):
    """Choose reject/direct/mediated/full using training groups only; no external test labels."""
    specs=candidate_specs(candidate)
    rows=[]
    fits={}
    for name,features in specs.items():
        fit=fit_grouped_ridge_mean(train,factors,features,max_folds=4)
        score=float(fit['cv_rmse'])+complexity_penalty*len(features)
        rows.append({'path':name,'features':features,'cv_rmse':float(fit['cv_rmse']),
                     'penalized_score':score,'n_features':len(features)})
        fits[name]=fit
    table=pd.DataFrame(rows).sort_values(['penalized_score','n_features'])
    chosen=str(table.iloc[0]['path'])
    return chosen,fits[chosen],table


class FixedResidualGP:
    """Fast, identical residual learner for source-path diagnostics.

    Kernel hyperparameters are fixed so differences are due to factor paths rather than
    repeated hyperparameter optimization on tiny target subsets.
    """
    def __init__(self, alpha=0.0025):
        self.scaler=StandardScaler()
        kernel=ConstantKernel(1.0)*RBF([1.0,1.0])+WhiteKernel(0.03)
        self.gp=GaussianProcessRegressor(kernel=kernel,alpha=alpha,normalize_y=True,optimizer=None)
    def fit(self,X,y,prior=None):
        Xs=self.scaler.fit_transform(np.asarray(X,float))
        r=np.asarray(y,float)-(0. if prior is None else np.asarray(prior,float))
        self.gp.fit(Xs,r); return self
    def predict(self,X,prior=None):
        mu,sd=self.gp.predict(self.scaler.transform(np.asarray(X,float)),return_std=True)
        mu=mu+(0. if prior is None else np.asarray(prior,float))
        return mu,sd


def fit_eval_path(train,test,hp,chakar_shape,ea_ev,candidate,path,variant='real',null_seed=0,alpha=0.0025):
    bs=_b_scale(train,ea_ev)
    ftr=make_factor_variant(train,hp,chakar_shape,ea_ev,candidate,variant,null_seed,b_scale=bs)
    fte=make_factor_variant(test,hp,chakar_shape,ea_ev,candidate,variant,null_seed,b_scale=bs)
    feats=candidate_specs(candidate)[path]
    fit=fit_grouped_ridge_mean(train,ftr,feats,max_folds=4)
    ptr=predict_grouped_ridge_mean(fit,ftr) if feats else None
    pte=predict_grouped_ridge_mean(fit,fte) if feats else None
    gp=FixedResidualGP(alpha).fit(default_feature(train,ea_ev),train.retention.to_numpy(float),ptr)
    mu,sd=gp.predict(default_feature(test,ea_ev),pte)
    err=float(np.sqrt(np.mean((test.retention.to_numpy(float)-mu)**2)))
    return err,fit


def bootstrap_b_precision(train,hp,chakar_shape,ea_ev,candidate,n_boot=100,seed=0,alpha=0.1):
    """Does candidate C stabilize the explicit B coefficient through CxB modulation?

    Fits group-balanced ridge y-1 ~ B + A versus y-1 ~ B + A + CxB on bootstrap
    resamples of parent devices. Lower beta_B dispersion plus lower grouped-CV error is
    evidence that C helps identify the target-domain B factor.
    """
    f=source_factor_frame(train,hp,chakar_shape,ea_ev)
    if candidate=='Hartono': A='C'; CxB='H_x_B'
    else: A='H'; CxB='C_x_B'
    groups=train[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rng=np.random.default_rng(seed)
    rows=[]
    for b in range(n_boot):
        take=groups.iloc[rng.integers(0,len(groups),len(groups))].copy()
        parts=[]
        # duplicate sampled groups safely by adding bootstrap suffix to sample id
        for j,row in take.reset_index(drop=True).iterrows():
            m=(train.temperature_c==row.temperature_c)&(train.sample_id==row.sample_id)
            z=train.loc[m].copy(); z['sample_id']=z['sample_id'].astype(str)+f'__boot{j}'
            # factors must follow corresponding original rows
            ff=f.loc[m].copy(); ff.index=z.index
            z['_orig_index']=ff.index
            parts.append(z)
        db=pd.concat(parts,ignore_index=True)
        # rebuild factor rows from original factor values using repeated group order
        vals=[]
        for j,row in take.reset_index(drop=True).iterrows():
            m=(train.temperature_c==row.temperature_c)&(train.sample_id==row.sample_id)
            vals.append(f.loc[m].reset_index(drop=True))
        fb=pd.concat(vals,ignore_index=True)
        for name,features in [('base',['B',A]),('modulated',['B',A,CxB])]:
            fit=fit_grouped_ridge_mean(db,fb,features,alphas=(alpha,),max_folds=4)
            rows.append({'boot':b,'model':name,'beta_B':fit['coef'].get('B',np.nan),'cv_rmse':fit['cv_rmse']})
    return pd.DataFrame(rows)


def transfer_cv_score(train, hp, chakar_shape, ea_ev, candidate, path, variant='real', null_seed=0, alpha=0.0025):
    """Leave-one-temperature-out score for source transfer, using identical fixed GP residuals."""
    temps=np.sort(train.temperature_c.unique())
    errs=[]
    for tv in temps:
        tr=train[train.temperature_c!=tv].copy(); va=train[train.temperature_c==tv].copy()
        if tr[['temperature_c','sample_id']].drop_duplicates().shape[0] < 3 or va.empty:
            continue
        bs=_b_scale(tr,ea_ev)
        ftr=make_factor_variant(tr,hp,chakar_shape,ea_ev,candidate,variant,null_seed,b_scale=bs)
        fva=make_factor_variant(va,hp,chakar_shape,ea_ev,candidate,variant,null_seed,b_scale=bs)
        feats=candidate_specs(candidate)[path]
        fit=fit_grouped_ridge_mean(tr,ftr,feats,max_folds=3)
        ptr=predict_grouped_ridge_mean(fit,ftr) if feats else None
        pva=predict_grouped_ridge_mean(fit,fva) if feats else None
        gp=FixedResidualGP(alpha).fit(default_feature(tr,ea_ev),tr.retention.to_numpy(float),ptr)
        mu,_=gp.predict(default_feature(va,ea_ev),pva)
        # one score per held-out temperature, group-balanced inside that temperature
        ge=[]
        for _,g in va.assign(_pred=mu).groupby(['temperature_c','sample_id']):
            ge.append(float(np.sqrt(np.mean((g.retention.to_numpy(float)-g._pred.to_numpy(float))**2))))
        errs.append(float(np.mean(ge)))
    return float(np.mean(errs)) if errs else np.inf


def select_path_transfer_aware(train,hp,chakar_shape,ea_ev,candidate,alpha=0.0025,null_seed=0,
                               complexity_penalty=0.001,min_gain=0.002,null_margin=0.001):
    """Source gate aligned with domain transfer rather than interpolation.

    A source is accepted only when a real-C path beats reject_C in leave-one-temperature-out
    CV and also beats an equal-capacity smooth-null C. Otherwise the source is rejected.
    """
    specs=candidate_specs(candidate)
    rows=[]
    for path,features in specs.items():
        real=transfer_cv_score(train,hp,chakar_shape,ea_ev,candidate,path,'real',null_seed,alpha)
        if path=='reject_C':
            null=real
        else:
            null=transfer_cv_score(train,hp,chakar_shape,ea_ev,candidate,path,'smooth_null',null_seed,alpha)
        score=real+complexity_penalty*len(features)
        rows.append({'path':path,'transfer_cv_rmse':real,'null_transfer_cv_rmse':null,
                     'score':score,'n_features':len(features)})
    tab=pd.DataFrame(rows).sort_values('score')
    base=float(tab.loc[tab.path=='reject_C','transfer_cv_rmse'].iloc[0])
    cand=tab[tab.path!='reject_C'].copy()
    cand['gain_vs_reject']=base-cand.transfer_cv_rmse
    cand['gain_vs_null']=cand.null_transfer_cv_rmse-cand.transfer_cv_rmse
    eligible=cand[(cand.gain_vs_reject>=min_gain)&(cand.gain_vs_null>=null_margin)]
    if eligible.empty:
        chosen='reject_C'
    else:
        chosen=str(eligible.sort_values(['score','n_features']).iloc[0].path)
    return chosen,tab
