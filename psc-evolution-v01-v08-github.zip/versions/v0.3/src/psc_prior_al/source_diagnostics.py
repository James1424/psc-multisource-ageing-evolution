from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass
from .priors import hartono_prior_stats, chakar_prior_stats, arrhenius_acceleration


def _progress(df: pd.DataFrame) -> np.ndarray:
    u=np.zeros(len(df),float)
    for _, idx in df.groupby(['temperature_c','sample_id']).indices.items():
        ii=np.asarray(idx,dtype=int)
        t=df.iloc[ii].time_h.to_numpy(float)
        h=max(float(np.nanmax(t)),1.0)
        u[ii]=t/h
    return np.clip(u,0,1)


def source_factor_frame(df: pd.DataFrame, hp: dict, chakar_shape: pd.DataFrame,
                        ea_ev: float=0.45, b_scale: float|None=None) -> pd.DataFrame:
    """Construct explicit source/target factors without using target labels.

    A = Hartono source shape deviation H
    B = Accelerated target-domain physics coordinate B (Arrhenius log acceleration)
    C = Chakar source shape deviation C

    Interaction terms test mediated usefulness, especially C x B.
    """
    u=_progress(df)
    hgrid=np.asarray(hp['grid_h'],float)
    hm,_=hartono_prior_stats(u*float(hgrid.max()), np.full(len(df),25.), hp, ea_ev=0.0)
    if chakar_shape is not None and len(chakar_shape)>=2:
        cmax=max(float(chakar_shape.age_h.max()),1.0)
        cm,_=chakar_prior_stats(u*cmax,chakar_shape)
    else:
        cm=np.ones(len(df))
    acc=arrhenius_acceleration(df.temperature_c.to_numpy(float),25.,ea_ev)
    b=np.log(np.clip(acc,1e-12,None))
    # robust scale B so interaction coefficients are comparable
    scale=max(float(np.nanstd(b)),1e-6) if b_scale is None else max(float(b_scale),1e-6); b=b/scale
    H=hm-1.0; C=cm-1.0
    return pd.DataFrame({
        'H':H, 'B':b, 'C':C,
        'H_x_B':H*b,
        'C_x_B':C*b,
        'H_x_C':H*C,
        'progress':u,
    }, index=df.index)


def _balanced_weights(groups) -> np.ndarray:
    groups=np.asarray(groups)
    _,inv,cnt=np.unique(groups,return_inverse=True,return_counts=True)
    return 1.0/cnt[inv]


def _ridge_fit(X,y,w,alpha):
    X=np.asarray(X,float); y=np.asarray(y,float); w=np.asarray(w,float)
    sw=np.sqrt(w)[:,None]
    Xa=np.c_[np.ones(len(X)),X]
    A=(Xa*sw).T@(Xa*sw)
    pen=np.eye(A.shape[0])*alpha; pen[0,0]=0.0
    beta=np.linalg.solve(A+pen,(Xa*sw).T@(y*np.sqrt(w)))
    return beta


def _ridge_predict(X,beta):
    X=np.asarray(X,float); return np.c_[np.ones(len(X)),X]@beta


def fit_grouped_ridge_mean(df: pd.DataFrame, features: pd.DataFrame, feature_names,
                           alphas=(1e-4,1e-3,1e-2,1e-1,1.0,10.0), max_folds=5):
    """Fit interpretable factor mean 1 + g(features) with group-CV alpha selection.

    Rows from the same parent device are kept together. The target is retention-1,
    so beta=0 corresponds to a neutral prior and is easy to interpret.
    """
    names=list(feature_names)
    if not names:
        return {'beta0':0.,'coef':{},'alpha':None,'cv_rmse':np.nan,'predict':lambda f: np.ones(len(f))}
    X=features[names].to_numpy(float); y=df.retention.to_numpy(float)-1.0
    group_keys=np.array([f'{t}|{s}' for t,s in zip(df.temperature_c,df.sample_id)])
    uniq=np.unique(group_keys)
    folds=np.array_split(uniq, min(max_folds,len(uniq)))
    scores=[]
    for a in alphas:
        errs=[]
        for vg in folds:
            va=np.isin(group_keys,vg); tr=~va
            if tr.sum()<3 or va.sum()<1: continue
            w=_balanced_weights(group_keys[tr])
            beta=_ridge_fit(X[tr],y[tr],w,float(a))
            pred=_ridge_predict(X[va],beta)
            # group-balanced RMSE
            for g in np.unique(group_keys[va]):
                m=(group_keys[va]==g); errs.append(float(np.sqrt(np.mean((y[va][m]-pred[m])**2))))
        scores.append((np.mean(errs) if errs else np.inf,float(a)))
    cv,alpha=min(scores,key=lambda z:z[0])
    beta=_ridge_fit(X,y,_balanced_weights(group_keys),alpha)
    return {
        'beta0':float(beta[0]),
        'coef':{n:float(v) for n,v in zip(names,beta[1:])},
        'alpha':alpha,
        'cv_rmse':float(cv),
        'feature_names':names,
        'beta':beta,
    }


def predict_grouped_ridge_mean(fit, features: pd.DataFrame):
    names=fit.get('feature_names',[])
    if not names: return np.ones(len(features),float)
    delta=_ridge_predict(features[names].to_numpy(float),fit['beta'])
    return 1.0+delta


MODEL_FEATURES = {
    # target-only GP supplies B implicitly through its kernel; no explicit source mean
    'B_only': [],
    'A_direct': ['H'],
    'C_direct': ['C'],
    'A_C_direct': ['H','C'],
    # C has no direct path to y; it may only modify the target-domain B factor
    'A_plus_C_mediates_B': ['H','C_x_B'],
    # full graph allows direct, mediated, and source-source interaction
    'full_source_graph': ['H','C','H_x_B','C_x_B','H_x_C'],
}


def diagnose_source_c(summary: pd.DataFrame) -> pd.DataFrame:
    """Classify C at each train size from predictive deltas.

    direct_delta > 0 means adding C directly hurts vs A-only.
    mediated_delta < 0 means C improves via CxB despite no direct path.
    """
    rows=[]
    for n,g in summary.groupby('train_devices'):
        m=g.set_index('model')['rmse_mean'].to_dict()
        if 'A_direct' not in m: continue
        dd=m.get('A_C_direct',np.nan)-m['A_direct']
        md=m.get('A_plus_C_mediates_B',np.nan)-m['A_direct']
        fd=m.get('full_source_graph',np.nan)-m['A_direct']
        if np.isfinite(dd) and dd>0 and np.isfinite(md) and md<0:
            status='directly_harmful_indirectly_useful'
        elif np.isfinite(dd) and dd>0 and (not np.isfinite(md) or md>=0):
            status='harmful_at_this_label_budget'
        elif np.isfinite(dd) and dd<=0:
            status='directly_useful_or_redundant'
        else:
            status='undetermined'
        rows.append(dict(train_devices=int(n),direct_delta_C=float(dd),mediated_delta_C=float(md),full_delta_C=float(fd),C_status=status))
    out=pd.DataFrame(rows)
    # cross-budget diagnostic: if sign flips from harmful to helpful, C was underlearned rather than intrinsically harmful
    if len(out)>=2 and (out.direct_delta_C.iloc[0]>0) and (out.direct_delta_C.iloc[-1]<0):
        out['cross_budget_interpretation']='evidence_for_underlearned_C_at_small_N'
    elif len(out) and np.all(out.direct_delta_C>0) and np.all(out.mediated_delta_C>=0):
        out['cross_budget_interpretation']='evidence_for_consistently_harmful_C'
    elif len(out) and np.any((out.direct_delta_C>0)&(out.mediated_delta_C<0)):
        out['cross_budget_interpretation']='evidence_for_mediated_C_value'
    else:
        out['cross_budget_interpretation']='mixed_or_inconclusive'
    return out
