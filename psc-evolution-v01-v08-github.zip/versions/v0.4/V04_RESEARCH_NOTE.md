# v0.4 Research Note — Automatic Source Dataset Validity and Conditional Utility

## Motivation
A researcher rarely knows ex ante whether every accessible external database is transferable to a small labelled target problem. Ordinary pooling can produce negative transfer, but a negative direct ablation does not prove that a source contains no useful information: its signal may be useful only conditionally, for example by modifying a target-domain thermal factor.

## A/B/C mapping in this prototype
- **B**: Accelerated-v2 target physics coordinate (time + Arrhenius-inspired temperature factor). B is a target covariate, not a source label.
- **A**: the other external source retained as context.
- **C**: the source currently being audited; Hartono and Chakar are audited in both directions.

## Tested paths
The source auditor distinguishes `C -> y` from `C -> (C×B) -> y`. The second path is a predictive modulation/mediation hypothesis: C changes how B should be interpreted. This is not causal identification.

## How “underlearned” is separated from “harmful”
1. Repeat at N=6,12,24 target parent devices.
2. Gate selection is based only on grouped CV inside revealed target data.
3. If C is rejected/harmful at small N but selected/helpful at larger N, classify as evidence of underlearning at small N.
4. If all tested C paths remain worse at the largest N and do not beat matched null factors, classify only as “harmful under tested paths”, never universally harmful.

## Source-specificity controls
A real mediated improvement must beat:
- reversed source trajectory;
- smooth random source of matched scale and the same interaction complexity.

## B-factor precision
Grouped device bootstrap compares beta_B stability for `B + A` and `B + A + C×B`. A smaller beta_B bootstrap SD together with better grouped-CV/prediction error is evidence that C helps identify B rather than merely adding an extra predictor.

## Transfer-aware gate correction
A first stress test showed that ordinary grouped CV can accept a reversed source because it validates interpolation among observed devices rather than the intended cross-temperature transfer. v0.4 therefore adds a leave-one-temperature-out (LOTO) source gate. A candidate C path is accepted only if it improves LOTO error over rejecting C and beats an equal-capacity smooth-null source. This distinction is essential: a source can fit observed domains yet be harmful for transfer.
