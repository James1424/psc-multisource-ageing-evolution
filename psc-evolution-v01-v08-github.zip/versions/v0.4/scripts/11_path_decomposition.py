"""Decompose source C utility into direct, CxB, and AxC paths at a fixed label budget."""
from pathlib import Path
import argparse,warnings
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.source_auditor import make_factor_variant,FixedResidualGP,_b_scale
from psc_prior_al.source_diagnostics import fit_grouped_ridge_mean,predict_grouped_ridge_mean
from psc_prior_al.transfer import default_feature
warnings.filterwarnings('ignore')

def thin(df,maxn=8):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); idx=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int)); out.append(g.iloc[idx])
    return pd.concat(out,ignore_index=True)

def eval_feats(train,test,hp,cs,ea,cand,feats,alpha):
    bs=_b_scale(train,ea); ftr=make_factor_variant(train,hp,cs,ea,cand,'real',0,b_scale=bs); fte=make_factor_variant(test,hp,cs,ea,cand,'real',0,b_scale=bs)
    fit=fit_grouped_ridge_mean(train,ftr,feats,max_folds=4)
    ptr=predict_grouped_ridge_mean(fit,ftr) if feats else None; pte=predict_grouped_ridge_mean(fit,fte) if feats else None
    gp=FixedResidualGP(alpha).fit(default_feature(train,ea),train.retention.to_numpy(),ptr); mu,_=gp.predict(default_feature(test,ea),pte)
    return float(np.sqrt(np.mean((test.retention.to_numpy()-mu)**2)))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--budget',type=int,default=12); ap.add_argument('--seeds',type=int,default=10); a=ap.parse_args()
    c=load_config('configs/default.yaml'); proc=resolve(Path('.'),c['paths']['processed']); ea=float(c['model']['arrhenius_ea_ev_prior']); alpha=float(c['model']['gp_alpha'])
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cs=pd.read_csv(proc/'chakar_daily_shape.csv'); test=thin(d[d.temperature_c==25]); pool=d[d.temperature_c!=25]; groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rows=[]
    for cand in ['Hartono','Chakar']:
      if cand=='Hartono': A,C,CxB,AxC='C','H','H_x_B','H_x_C'
      else: A,C,CxB,AxC='H','C','C_x_B','H_x_C'
      specs={'A_only':[A],'A_plus_C_direct':[A,C],'A_plus_CxB':[A,CxB],'A_plus_AxC':[A,AxC],
             'A_plus_C_and_CxB':[A,C,CxB],'A_plus_C_and_AxC':[A,C,AxC],'full_C':[A,C,CxB,AxC]}
      for seed in range(a.seeds):
        rng=np.random.default_rng(seed); chosen=groups.iloc[rng.choice(len(groups),min(a.budget,len(groups)),replace=False)]; train=thin(pool.merge(chosen,on=['temperature_c','sample_id']))
        for name,feats in specs.items(): rows.append({'candidate_C':cand,'seed':seed,'path':name,'rmse':eval_feats(train,test,hp,cs,ea,cand,feats,alpha)})
    out=pd.DataFrame(rows); out.to_csv(f'results/path_decomposition_N{a.budget}_v04.csv',index=False)
    s=out.groupby(['candidate_C','path']).rmse.agg(['mean','std']).reset_index(); s.to_csv(f'results/path_decomposition_N{a.budget}_v04_summary.csv',index=False)
    print(s.pivot(index='path',columns='candidate_C',values='mean').round(4).to_string())
if __name__=='__main__':main()
