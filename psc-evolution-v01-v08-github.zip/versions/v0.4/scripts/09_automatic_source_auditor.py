"""Automatic source-dataset auditor (v0.4).

The auditor must decide from revealed target groups only whether candidate source C is:
- rejected,
- useful directly,
- useful only by modulating target factor B (C x B), or
- useful through the full interaction graph.

The chosen path is then evaluated on fully held-out 25 C data. Reversed and smooth-null
source controls test whether mediated gains are source-specific rather than extra-feature capacity.
"""
from pathlib import Path
import argparse, warnings
import numpy as np, pandas as pd, joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.source_auditor import (
    make_factor_variant,select_path_by_group_cv,fit_eval_path,bootstrap_b_precision
)

warnings.filterwarnings('ignore')

def thin(df,maxn=8):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h')
        idx=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int))
        out.append(g.iloc[idx])
    return pd.concat(out,ignore_index=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); ap.add_argument('--quick',action='store_true'); a=ap.parse_args()
    c=load_config(a.config); root=Path('.'); proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cs=pd.read_csv(proc/'chakar_daily_shape.csv')
    ea=float(c['model']['arrhenius_ea_ev_prior']); hold=float(c['benchmark']['holdout_temperature_c'])
    test=thin(d[d.temperature_c==hold]); pool=d[d.temperature_c!=hold]
    groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    budgets=[6,12,24]; seeds=range(3 if a.quick else 10)
    rows=[]; nullrows=[]; pre=[]
    for candidate in ['Hartono','Chakar']:
      for n in budgets:
       for seed in seeds:
        rng=np.random.default_rng(seed); chosen=groups.iloc[rng.choice(len(groups),min(n,len(groups)),replace=False)]
        train=thin(pool.merge(chosen,on=['temperature_c','sample_id']))
        ftr=make_factor_variant(train,hp,cs,ea,candidate,'real',seed)
        selected,fit,table=select_path_by_group_cv(train,ftr,candidate,complexity_penalty=0.001)
        # external evaluation of self-selected path
        err,_=fit_eval_path(train,test,hp,cs,ea,candidate,selected,'real',seed,c['model']['gp_alpha'])
        reject_err,_=fit_eval_path(train,test,hp,cs,ea,candidate,'reject_C','real',seed,c['model']['gp_alpha'])
        mediated_err,_=fit_eval_path(train,test,hp,cs,ea,candidate,'mediated_C','real',seed,c['model']['gp_alpha'])
        direct_err,_=fit_eval_path(train,test,hp,cs,ea,candidate,'direct_C','real',seed,c['model']['gp_alpha'])
        rows.append({'candidate_C':candidate,'train_devices':n,'seed':seed,'selected_path':selected,
                     'selected_rmse':err,'reject_rmse':reject_err,'direct_rmse':direct_err,'mediated_rmse':mediated_err,
                     'selected_gain_vs_reject':reject_err-err})
        for _,r in table.iterrows():
            pre.append({'candidate_C':candidate,'train_devices':n,'seed':seed,**r.to_dict()})
        # source-specific null controls for mediated path
        for variant in ['real','reversed','smooth_null']:
            e,_=fit_eval_path(train,test,hp,cs,ea,candidate,'mediated_C',variant,seed,c['model']['gp_alpha'])
            nullrows.append({'candidate_C':candidate,'train_devices':n,'seed':seed,'variant':variant,'rmse':e})
    out=pd.DataFrame(rows); out.to_csv(res/'automatic_source_auditor_v04.csv',index=False)
    pd.DataFrame(pre).to_csv(res/'automatic_source_gate_cv_v04.csv',index=False)
    nul=pd.DataFrame(nullrows); nul.to_csv(res/'source_specificity_null_controls_v04.csv',index=False)
    # B precision analysis at N=12 across three target selections; keep fast in quick mode
    pr=[]
    nboot=20 if a.quick else 100
    for candidate in ['Hartono','Chakar']:
      for seed in range(2 if a.quick else 5):
        rng=np.random.default_rng(seed); chosen=groups.iloc[rng.choice(len(groups),12,replace=False)]
        train=thin(pool.merge(chosen,on=['temperature_c','sample_id']))
        q=bootstrap_b_precision(train,hp,cs,ea,candidate,n_boot=nboot,seed=seed)
        q['candidate_C']=candidate; q['seed']=seed; pr.append(q)
    prec=pd.concat(pr,ignore_index=True); prec.to_csv(res/'B_factor_precision_v04.csv',index=False)

    summary=out.groupby(['candidate_C','train_devices']).agg(
        selected_rmse=('selected_rmse','mean'),reject_rmse=('reject_rmse','mean'),
        direct_rmse=('direct_rmse','mean'),mediated_rmse=('mediated_rmse','mean'),
        gain=('selected_gain_vs_reject','mean'),P_gate_improves=('selected_gain_vs_reject',lambda x: float(np.mean(np.asarray(x)>0)))
    ).reset_index()
    freq=(out.groupby(['candidate_C','train_devices','selected_path']).size()/out.groupby(['candidate_C','train_devices']).size()).rename('selection_frequency').reset_index()
    nullsum=nul.groupby(['candidate_C','train_devices','variant']).rmse.mean().reset_index()
    ps=prec.groupby(['candidate_C','model']).agg(beta_B_mean=('beta_B','mean'),beta_B_sd=('beta_B','std'),cv_rmse=('cv_rmse','mean')).reset_index()
    summary.to_csv(res/'automatic_source_auditor_v04_summary.csv',index=False); freq.to_csv(res/'source_gate_selection_frequency_v04.csv',index=False); nullsum.to_csv(res/'source_specificity_null_controls_v04_summary.csv',index=False); ps.to_csv(res/'B_factor_precision_v04_summary.csv',index=False)
    print('\nAutomatic gate external RMSE:'); print(summary.round(4).to_string(index=False))
    print('\nGate path frequency:'); print(freq.round(3).to_string(index=False))
    print('\nMediated source specificity controls:'); print(nullsum.round(4).to_string(index=False))
    print('\nB-factor bootstrap precision (N=12):'); print(ps.round(5).to_string(index=False))

if __name__=='__main__': main()
