"""Transfer-aware automatic source gate using leave-one-temperature-out CV."""
from pathlib import Path
import argparse
import warnings, numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.source_auditor import select_path_transfer_aware,fit_eval_path
warnings.filterwarnings('ignore')

def thin(df,maxn=8):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); idx=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int)); out.append(g.iloc[idx])
    return pd.concat(out,ignore_index=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seeds',type=int,default=3); a=ap.parse_args()
    c=load_config('configs/default.yaml'); root=Path('.'); proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cs=pd.read_csv(proc/'chakar_daily_shape.csv')
    ea=float(c['model']['arrhenius_ea_ev_prior']); hold=float(c['benchmark']['holdout_temperature_c']); alpha=float(c['model']['gp_alpha'])
    test=thin(d[d.temperature_c==hold]); pool=d[d.temperature_c!=hold]; groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rows=[]; cvrows=[]
    for candidate in ['Hartono','Chakar']:
      for variant_for_stress in ['real','reversed','smooth_null']:
       for n in [6,12,24]:
        for seed in range(a.seeds):
          rng=np.random.default_rng(seed); chosen=groups.iloc[rng.choice(len(groups),min(n,len(groups)),replace=False)]; train=thin(pool.merge(chosen,on=['temperature_c','sample_id']))
          # Gate logic is evaluated on whichever candidate is presented as the database under audit.
          # For stress variants, temporarily emulate that candidate by swapping variant labels in score/eval.
          if variant_for_stress=='real':
              chosen_path,tab=select_path_transfer_aware(train,hp,cs,ea,candidate,alpha,seed)
          else:
              # For bad-source stress, calculate transfer-aware scores directly for the presented variant.
              from psc_prior_al.source_auditor import candidate_specs,transfer_cv_score
              rr=[]
              specs=candidate_specs(candidate)
              for path,feats in specs.items():
                  sc=transfer_cv_score(train,hp,cs,ea,candidate,path,variant_for_stress,seed,alpha)
                  rr.append({'path':path,'transfer_cv_rmse':sc,'score':sc+.001*len(feats),'n_features':len(feats)})
              tab=pd.DataFrame(rr).sort_values('score'); base=float(tab.loc[tab.path=='reject_C','transfer_cv_rmse'].iloc[0]); best=tab[tab.path!='reject_C'].iloc[0]
              chosen_path=str(best.path) if base-float(best.transfer_cv_rmse)>=.002 else 'reject_C'
          e,_=fit_eval_path(train,test,hp,cs,ea,candidate,chosen_path,variant_for_stress,seed,alpha)
          reject,_=fit_eval_path(train,test,hp,cs,ea,candidate,'reject_C',variant_for_stress,seed,alpha)
          rows.append({'candidate_C':candidate,'presented_source':variant_for_stress,'train_devices':n,'seed':seed,'selected_path':chosen_path,'rmse':e,'reject_rmse':reject,'gain':reject-e})
          if variant_for_stress=='real':
              for _,r in tab.iterrows(): cvrows.append({'candidate_C':candidate,'train_devices':n,'seed':seed,**r.to_dict()})
    out=pd.DataFrame(rows); out.to_csv(res/'transfer_aware_source_gate_v04.csv',index=False); pd.DataFrame(cvrows).to_csv(res/'transfer_aware_gate_cv_v04.csv',index=False)
    freq=(out.groupby(['candidate_C','presented_source','train_devices','selected_path']).size()/out.groupby(['candidate_C','presented_source','train_devices']).size()).rename('freq').reset_index()
    summ=out.groupby(['candidate_C','presented_source','train_devices']).agg(rmse=('rmse','mean'),reject=('reject_rmse','mean'),gain=('gain','mean'),P_improve=('gain',lambda x:float(np.mean(np.asarray(x)>0)))).reset_index()
    freq.to_csv(res/'transfer_aware_gate_frequency_v04.csv',index=False); summ.to_csv(res/'transfer_aware_source_gate_v04_summary.csv',index=False)
    print('\nTransfer-aware gate path frequency'); print(freq.to_string(index=False))
    print('\nExternal 25C results'); print(summ.round(4).to_string(index=False))
if __name__=='__main__':main()
