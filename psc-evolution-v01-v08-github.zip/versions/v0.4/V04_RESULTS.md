# v0.4 Pilot Results — Automatic Source Validity and Conditional Utility

## What v0.4 tests
The target is Accelerated-v2 with 25 °C fully held out. Hartono and Chakar are alternately treated as candidate source **C**, while the other source is **A**. The target-domain temperature/time coordinate is **B**.

A source is not judged from a single ablation. v0.4 separates:
1. direct path `C -> y`;
2. target-factor modulation `C -> C×B -> y`;
3. cross-source synergy `A×C`;
4. full candidate-specific graph;
5. source-specificity controls (reversed C and smooth random C);
6. cross-label-budget behavior;
7. a transfer-aware gate using leave-one-temperature-out CV.

All source factors are constructed without Accelerated-v2 labels. Parent devices, not pixels, are the split/query unit.

## 10-seed path decomposition at N=12 revealed devices
Mean 25 °C RMSE:

| path | Chakar audited as C | Hartono audited as C |
|---|---:|---:|
| A only | 0.1637 | 0.1597 |
| A + C direct | 0.1592 | 0.1592 |
| A + C×B | 0.1480 | 0.1477 |
| A + A×C | 0.1628 | 0.1483 |
| A + C + C×B | 0.1447 | 0.1238 |
| A + C + A×C | 0.1563 | 0.1563 |
| full candidate-specific graph | 0.1478 | 0.1153 |

Paired improvement versus A-only:
- Chakar `C×B`: +0.0157 RMSE reduction, 95% CI [0.0085, 0.0230], improvement in 9/10 splits.
- Hartono `H×B`: +0.0120, 95% CI [0.0085, 0.0155], improvement in 10/10 splits.
- Hartono `A×H`: +0.0114, 95% CI [0.0084, 0.0144], improvement in 10/10 splits.
- Hartono full graph: +0.0444, 95% CI [0.0354, 0.0533], improvement in 10/10 splits.

Interpretation: direct addition is weak, while conditional paths are much stronger. This supports the user's hypothesis that a source can be unhelpful as a direct predictor yet useful by changing how another factor is interpreted.

## Source-specificity controls
For the full candidate-specific graph (10 seeds), real source factors were compared with reversed and smooth-null factors of the same model complexity.

Mean RMSE (real / reversed / smooth-null):
- Hartono, N=6: 0.1424 / 0.1583 / 0.1768
- Hartono, N=12: 0.1153 / 0.1385 / 0.1631
- Hartono, N=24: 0.1261 / 0.1522 / 0.1875
- Chakar, N=6: 0.1624 / 0.1854 / 0.1819
- Chakar, N=12: 0.1478 / 0.1790 / 0.1729
- Chakar, N=24: 0.1644 / 0.2114 / 0.2031

At N=12 and N=24 both real sources clearly beat equal-capacity nulls. Therefore the gain is not adequately explained by merely adding interaction terms.

For the isolated `C×B` path, Chakar is particularly source-specific: real C×B beats reversed/null at N=6,12,24. Hartono H×B alone is less source-specific at larger budgets (reversed H can be as good or better), implying that Hartono's strongest value likely includes cross-source synergy rather than pure thermal modulation alone.

## Does C make B “more precise”?
Two meanings must be separated.

At N=12 grouped bootstrap:
- With Chakar modulation, factor-model CV RMSE improves from 0.1727 to 0.1360, but beta_B SD changes only 0.02910 -> 0.02897. Chakar improves the **accuracy of the B relation**, not meaningfully the coefficient precision.
- With Hartono modulation, beta_B SD decreases 0.02948 -> 0.02755 (~6.5%), but CV RMSE is essentially unchanged/slightly worse (0.1193 -> 0.1200). Hartono modestly stabilizes B but does not by itself improve in-domain fit.

Thus the current data support conditional utility, but not a blanket claim that every source makes B statistically more precise.

## Can the model automatically reject harmful data?
A naive group-CV gate failed this stress test: it could accept a reversed source that later harmed 25 °C extrapolation. This is an important negative result.

v0.4 therefore adds leave-one-temperature-out (LOTO) transfer CV. In the 3-seed smoke test:
- reversed/smooth-null Chakar is rejected at N=12 and N=24;
- real Hartono is rejected at N=6 but accepted at N=12/24, where it improves external RMSE. This is a concrete example of **underlearned at small N rather than intrinsically harmful**;
- real Chakar is conservatively rejected at N=12/24 even though the post-hoc isolated C×B path can improve the external target. Therefore the current gate can miss hidden conditional utility.

Conclusion: automatic source validity estimation is feasible, but ordinary CV is not enough and even LOTO CV is not a solved problem. A publication-level method should model source-path uncertainty explicitly rather than make a hard one-shot selection.

## Scientifically defensible claim at this stage
The pilot supports: **source utility is path-dependent and label-budget-dependent**. Direct ablation alone can misclassify a source. Interaction-aware and transfer-aware source auditing can reveal useful conditional information and reduce negative transfer, but the present hard gate is still imperfect.

It does **not** support: “database C is fundamentally harmful” or “the auditor can always identify useful databases.” Those stronger claims require independent target datasets, more seeds, and a probabilistic source-gating model.
