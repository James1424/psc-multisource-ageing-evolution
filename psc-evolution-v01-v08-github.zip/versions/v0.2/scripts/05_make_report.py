"""Create concise benchmark figures/tables from v0.2 outputs."""
from pathlib import Path
import pandas as pd, numpy as np
import matplotlib.pyplot as plt

R=Path('results'); R.mkdir(exist_ok=True)
if (R/'benchmark_v02.csv').exists():
    b=pd.read_csv(R/'benchmark_v02.csv')
    fig,ax=plt.subplots(figsize=(8,5))
    for name,g in b.groupby('model'):
        q=g.groupby('train_devices').rmse.agg(['mean','std']).reset_index()
        ax.plot(q.train_devices,q['mean'],marker='o',label=name)
        ax.fill_between(q.train_devices,q['mean']-q['std'],q['mean']+q['std'],alpha=.12)
    ax.set_xlabel('Revealed target devices'); ax.set_ylabel('25°C trajectory RMSE'); ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(R/'benchmark_learning_curves.png',dpi=180); plt.close(fig)
if (R/'active_learning_v02.csv').exists():
    a=pd.read_csv(R/'active_learning_v02.csv')
    fig,ax=plt.subplots(figsize=(8,5))
    for name,g in a.groupby('strategy'):
        q=g.groupby('n_devices').rmse_25c.agg(['mean','std']).reset_index()
        ax.plot(q.n_devices,q['mean'],marker='o',label=name)
        ax.fill_between(q.n_devices,q['mean']-q['std'],q['mean']+q['std'],alpha=.12)
    ax.set_xlabel('Revealed target devices'); ax.set_ylabel('25°C trajectory RMSE'); ax.legend(); fig.tight_layout(); fig.savefig(R/'active_learning_curves.png',dpi=180); plt.close(fig)
print('Wrote figures to',R)
