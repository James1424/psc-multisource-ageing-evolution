import argparse,json
from pathlib import Path
import pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.data import load_hartono,load_chakar_tables
from psc_prior_al.preprocessing import build_hartono_pca,build_accelerated_device_curves,summarize_devices
from psc_prior_al.priors import chakar_prior_strength,chakar_daily_shape

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); a=ap.parse_args()
    c=load_config(a.config); root=Path('.'); out=resolve(root,c['paths']['processed']); out.mkdir(parents=True,exist_ok=True)
    h=load_hartono(resolve(root,c['paths']['hartono'])); pc=c['preprocessing']
    hp=build_hartono_pca(h,pc['hartono_horizon_h'],pc['hartono_grid_points'],pc['hartono_pca_components'])
    joblib.dump(hp,out/'hartono_pca.joblib')
    curves=build_accelerated_device_curves(resolve(root,c['paths']['accelerated_v2']),pc['accelerated_grid_step_h'],pc['accelerated_baseline_window_h'],pc['device_aggregation'])
    curves.to_csv(out/'accelerated_device_curves.csv.gz',index=False,compression='gzip')
    summ=summarize_devices(curves); summ.to_csv(out/'accelerated_device_summary.csv',index=False)
    ch=load_chakar_tables(resolve(root,c['paths']['chakar']))
    cshape=chakar_daily_shape(ch); cshape.to_csv(out/'chakar_daily_shape.csv',index=False)
    (out/'chakar_prior.json').write_text(json.dumps(chakar_prior_strength(ch),indent=2))
    print('Hartono PCA explained variance:',hp['explained'])
    print('Chakar weak-prior days:',len(cshape),'duration_h=',float(cshape.age_h.max()) if len(cshape) else None)
    print(summ.groupby('temperature_c').agg(n=('sample_id','nunique'),duration_h=('duration_h','median'),k_eff=('k_eff_per_h','median')))
if __name__=='__main__': main()
