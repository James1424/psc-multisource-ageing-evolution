"""Paper-style low-data benchmark.

Compares target-only GP, fixed Hartono prior, adaptive multi-source prior, and wrong-prior
stress tests. 25 C is held out completely. Source functions are frozen; only source trust
weights are calibrated by grouped CV on the revealed target devices.
"""
import argparse
from pathlib import Path
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.models import ResidualGP
from psc_prior_al.metrics import rmse,mae,coverage,nlpd
from psc_prior_al.transfer import default_feature,source_prior,learn_source_weights


def thin(df,maxn=24):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h')
        if len(g)>maxn:
            idx=np.unique(np.linspace(0,len(g)-1,maxn).round().astype(int)); g=g.iloc[idx]
        out.append(g)
    return pd.concat(out,ignore_index=True)


def eval_model(train,test,hp,cshape,c,kind,ea_mult=1.0,reverse=False):
    ea=float(c['model']['arrhenius_ea_ev_prior'])*ea_mult
    Xtr=default_feature(train,ea); Xte=default_feature(test,ea); ytr=train.retention.to_numpy(); yte=test.retention.to_numpy()
    wh=wc=0.0; cv=np.nan
    if kind=='target_only':
        ptr=pte=None
    elif kind=='hartono_fixed':
        wh,wc=1.,0.; ptr,*_=source_prior(train,hp,cshape,ea,wh,wc,reverse); pte,*_=source_prior(test,hp,cshape,ea,wh,wc,reverse)
    else:
        fit=learn_source_weights(train,hp,cshape,ea,c['model']['gp_alpha'],c['model']['random_state'])
        wh,wc,cv=fit['w_h'],fit['w_c'],fit['cv_rmse']
        ptr,*_=source_prior(train,hp,cshape,ea,wh,wc,reverse); pte,*_=source_prior(test,hp,cshape,ea,wh,wc,reverse)
    m=ResidualGP(c['model']['gp_alpha'],c['model']['random_state']).fit(Xtr,ytr,ptr)
    mu,std=m.predict(Xte,pte)
    return dict(rmse=rmse(yte,mu),mae=mae(yte,mu),coverage95=coverage(yte,mu,std),nlpd=nlpd(yte,mu,std),w_h=wh,w_c=wc,weight_cv_rmse=cv)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); ap.add_argument('--quick',action='store_true'); a=ap.parse_args()
    c=load_config(a.config); root=Path('.'); proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib')
    cshape=pd.read_csv(proc/'chakar_daily_shape.csv') if (proc/'chakar_daily_shape.csv').exists() else pd.DataFrame()
    hold=float(c['benchmark']['holdout_temperature_c']); test=thin(d[d.temperature_c==hold],c['preprocessing']['max_points_per_device_gp']); pool=d[d.temperature_c!=hold]
    groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    rows=[]
    sizes=([6,12] if a.quick else c['benchmark']['train_devices_grid']); seeds=(c['benchmark']['seeds'][:2] if a.quick else c['benchmark']['seeds'])
    for nreq in sizes:
      for seed in seeds:
        rng=np.random.default_rng(seed); n=min(int(nreq),len(groups)); chosen=groups.iloc[rng.choice(len(groups),n,replace=False)]
        train=thin(pool.merge(chosen,on=['temperature_c','sample_id']),c['preprocessing']['max_points_per_device_gp'])
        specs=[('target_only',1.,False),('hartono_fixed',1.,False),('adaptive_multisource',1.,False)]
        for mult in c['benchmark']['wrong_prior_ea_multipliers']:
            if float(mult)!=1.: specs.append((f'adaptive_wrong_ea_x{mult}',float(mult),False))
        specs.append(('adaptive_reverse_temperature',1.,True))
        for kind,mult,rev in specs:
            r=eval_model(train,test,hp,cshape,c,kind,mult,rev)
            rows.append(dict(seed=seed,train_devices=n,model=kind,holdout_temperature_c=hold,**r))
    out=pd.DataFrame(rows); out.to_csv(res/'benchmark_v02.csv',index=False)
    summary=out.groupby(['train_devices','model'])[['rmse','mae','coverage95','nlpd','w_h','w_c']].agg(['mean','std']).reset_index()
    summary.to_csv(res/'benchmark_v02_summary.csv',index=False)
    print(out.groupby(['train_devices','model'])['rmse'].agg(['mean','std']).round(4).to_string())
if __name__=='__main__': main()
