"""Fair retrospective AL comparison using identical initial device sets per seed.

Strategies:
- random
- uncertainty
- disagreement (prior/posterior conflict)
- hybrid (uncertainty + disagreement + metadata diversity + temperature balancing)

The oracle reveals a whole Accelerated-v2 device group. 25 C remains external test data.
"""
import argparse
from pathlib import Path
import numpy as np,pandas as pd,joblib
from psc_prior_al.config import load_config,resolve
from psc_prior_al.models import ResidualGP
from psc_prior_al.metrics import rmse,coverage,nlpd
from psc_prior_al.transfer import default_feature,source_prior,learn_source_weights
from psc_prior_al.active_learning import point_acquisition,group_scores


def thin(df,maxn=24):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h')
        if len(g)>maxn:
            idx=np.unique(np.linspace(0,len(g)-1,maxn).round().astype(int)); g=g.iloc[idx]
        out.append(g)
    return pd.concat(out,ignore_index=True)


def mask_groups(df,groupset,inside=True):
    keys=list(zip(df.temperature_c.astype(float),df.sample_id.astype(float)))
    m=np.array([k in groupset for k in keys]); return df[m if inside else ~m].copy()


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/default.yaml'); ap.add_argument('--quick',action='store_true'); a=ap.parse_args(); c=load_config(a.config); root=Path('.')
    proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cshape=pd.read_csv(proc/'chakar_daily_shape.csv')
    hold=float(c['benchmark']['holdout_temperature_c']); maxn=c['preprocessing']['max_points_per_device_gp']
    test=thin(d[d.temperature_c==hold].copy(),maxn); pool=d[d.temperature_c!=hold].copy(); groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    histories=[]; selections=[]
    seeds=(c['benchmark']['seeds'][:2] if a.quick else c['benchmark']['seeds'][:5]); rounds=(4 if a.quick else c['active_learning']['rounds'])
    for seed in seeds:
        rng=np.random.default_rng(seed); init=min(c['active_learning']['initial_devices'],len(groups)); init_idx=rng.choice(len(groups),init,replace=False)
        initial=set((float(r.temperature_c),float(r.sample_id)) for _,r in groups.iloc[init_idx].iterrows())
        for strategy in c['active_learning']['strategies']:
            labeled=set(initial)
            for rnd in range(rounds+1):
                train=thin(mask_groups(pool,labeled,True),maxn)
                fit=learn_source_weights(train,hp,cshape,c['model']['arrhenius_ea_ev_prior'],c['model']['gp_alpha'],seed)
                wh,wc=fit['w_h'],fit['w_c']
                ptr,*_=source_prior(train,hp,cshape,c['model']['arrhenius_ea_ev_prior'],wh,wc)
                pte,*_=source_prior(test,hp,cshape,c['model']['arrhenius_ea_ev_prior'],wh,wc)
                m=ResidualGP(c['model']['gp_alpha'],seed,n_restarts_optimizer=0).fit(default_feature(train,c['model']['arrhenius_ea_ev_prior']),train.retention,ptr)
                mu,std=m.predict(default_feature(test,c['model']['arrhenius_ea_ev_prior']),pte)
                histories.append(dict(seed=seed,strategy=strategy,round=rnd,n_devices=len(labeled),rmse_25c=rmse(test.retention,mu),coverage95=coverage(test.retention,mu,std),nlpd=nlpd(test.retention,mu,std),w_h=wh,w_c=wc))
                if rnd==rounds: break
                cand=thin(mask_groups(pool,labeled,False),maxn)
                if len(cand)==0: break
                pm,hm,hs,cm,cs=source_prior(cand,hp,cshape,c['model']['arrhenius_ea_ev_prior'],wh,wc)
                cmu,cstd=m.predict(default_feature(cand,c['model']['arrhenius_ea_ev_prior']),pm)
                if strategy=='random':
                    avail=[tuple(x) for x in cand[['temperature_c','sample_id']].drop_duplicates().to_numpy()]
                    choice=avail[int(rng.integers(len(avail)))]
                else:
                    if strategy=='uncertainty': pts=cstd
                    elif strategy=='disagreement': pts=np.abs(cmu-pm)/np.sqrt(cstd**2+0.08**2)
                    else: pts=point_acquisition(cstd,cmu,pm,0.08,c['active_learning']['lambda_disagreement'])
                    ranked=group_scores(cand,pts,list(labeled),strategy,
                                        c['active_learning']['temperature_balance'] if strategy=='hybrid' else 0.,
                                        c['active_learning']['diversity_weight'] if strategy=='hybrid' else 0.)
                    rr=ranked.iloc[0]; choice=(float(rr.temperature_c),float(rr.sample_id))
                labeled.add(choice); selections.append(dict(seed=seed,strategy=strategy,round=rnd+1,temperature_c=choice[0],sample_id=choice[1]))
    H=pd.DataFrame(histories); H.to_csv(res/'active_learning_v02.csv',index=False); pd.DataFrame(selections).to_csv(res/'active_learning_selections_v02.csv',index=False)
    S=H.groupby(['strategy','n_devices'])['rmse_25c'].agg(['mean','std']).reset_index(); S.to_csv(res/'active_learning_v02_summary.csv',index=False)
    print(S.to_string(index=False))
if __name__=='__main__': main()
