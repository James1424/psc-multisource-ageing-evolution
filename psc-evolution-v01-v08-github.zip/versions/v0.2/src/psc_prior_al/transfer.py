from __future__ import annotations
import numpy as np
import pandas as pd
from .priors import hartono_prior_stats, chakar_prior_stats, combine_source_priors, arrhenius_acceleration


def _progress(df):
    u=np.zeros(len(df),float)
    for _,idx in df.groupby(['temperature_c','sample_id']).indices.items():
        ii=np.asarray(idx,dtype=int); t=df.iloc[ii].time_h.to_numpy(float); h=max(float(np.nanmax(t)),1.0); u[ii]=t/h
    return np.clip(u,0,1)

def default_feature(df, ea_ev=0.45):
    # physics-motivated coordinates: log time + log Arrhenius acceleration
    acc=arrhenius_acceleration(df['temperature_c'].to_numpy(),25.,ea_ev)
    return np.c_[np.log1p(df['time_h'].to_numpy())/np.log1p(2500.), np.log(np.clip(acc,1e-8,None))/5.]

def source_prior(df, hp, chakar_shape=None, ea_ev=0.45, w_h=1., w_c=0., reverse_temperature=False):
    # Source datasets contribute SHAPE, not absolute lifetime. Protocol progress is metadata, not a target label.
    u=_progress(df)
    h_grid=np.asarray(hp['grid_h'],float); h_t=u*float(h_grid.max())
    hm,hs=hartono_prior_stats(h_t, np.full(len(df),25.), hp, ea_ev=0.0)
    if chakar_shape is not None and len(chakar_shape):
        cmax=max(float(chakar_shape.age_h.max()),1.0); cm,cs=chakar_prior_stats(u*cmax,chakar_shape)
    else:
        cm,cs=np.ones(len(df)),np.full(len(df),.25)
    mu=combine_source_priors(hm,cm,w_h=w_h,w_c=w_c)
    if reverse_temperature:
        # explicit wrong-prior stress: invert degradation direction around retention=1
        mu=2.0-mu
    return mu,hm,hs,cm,cs

def learn_source_weights(train: pd.DataFrame, hp, chakar_shape, ea_ev, gp_alpha=0.0025, random_state=42, weight_grid=None, max_splits=4):
    if weight_grid is None:
        vals=[0.,.25,.5,.75,1.]
        weight_grid=[(wh,wc) for wh in vals for wc in vals if wh+wc<=1.00001]
    y=train.retention.to_numpy(float); groups=list(train.groupby(['temperature_c','sample_id']).indices.values()); rows=[]
    for wh,wc in weight_grid:
        p,*_=source_prior(train,hp,chakar_shape,ea_ev,wh,wc)
        errs=[]
        for idx in groups:
            ii=np.asarray(idx,dtype=int); errs.append(float(np.sqrt(np.mean((y[ii]-p[ii])**2))))
        rows.append({'w_h':float(wh),'w_c':float(wc),'cv_rmse':float(np.mean(errs))})
    rows=sorted(rows,key=lambda r:r['cv_rmse']); best=rows[0]
    return {**best,'n_groups':len(groups),'table':rows}
