from __future__ import annotations
import numpy as np
import pandas as pd


def point_acquisition(std, posterior_mean=None, prior_mean=None, prior_std=0.08,
                      lam_disagreement=0.7):
    std=np.asarray(std,float)
    if posterior_mean is None or prior_mean is None:
        return std
    ps=np.asarray(prior_std,float) if np.ndim(prior_std) else float(prior_std)
    d=np.abs(np.asarray(posterior_mean)-np.asarray(prior_mean))/np.sqrt(std**2+ps**2)
    return std + lam_disagreement*d


def group_scores(candidate_df: pd.DataFrame, point_scores, labeled_groups=None,
                 strategy='hybrid', temperature_balance=0.25, diversity_weight=0.15):
    x=candidate_df.copy(); x['_score']=np.asarray(point_scores,float)
    base=x.groupby(['temperature_c','sample_id']).agg(
        score=('_score','mean'), duration=('time_h','max')).reset_index()
    if strategy=='random':
        rng=np.random.default_rng(0); base['final_score']=rng.random(len(base)); return base
    if strategy=='uncertainty' or strategy=='disagreement' or strategy=='hybrid':
        base['final_score']=base['score']
    else:
        base['final_score']=base['score']
    labeled_groups = labeled_groups or []
    if labeled_groups:
        lt=np.array([float(g[0]) for g in labeled_groups])
        counts=pd.Series(lt).value_counts().to_dict()
        # reward underrepresented temperatures
        base['temp_bonus']=base.temperature_c.map(lambda t: 1.0/np.sqrt(1+counts.get(float(t),0)))
        # metadata-only diversity: distance in (temperature, scheduled duration)
        cand=np.c_[base.temperature_c/20., np.log1p(base.duration)/np.log1p(max(base.duration.max(),1))]
        lmeta=[]
        for T,s in labeled_groups:
            g=x[(x.temperature_c==float(T)) & (x.sample_id==float(s))]
            if len(g): lmeta.append([float(T)/20., np.log1p(g.time_h.max())/np.log1p(max(base.duration.max(),1))])
        if lmeta:
            L=np.asarray(lmeta); dist=np.sqrt(((cand[:,None,:]-L[None,:,:])**2).sum(axis=2)).min(axis=1)
        else: dist=np.ones(len(base))
        base['diversity_bonus']=dist
        base['final_score']=base['final_score'] + temperature_balance*base['temp_bonus'] + diversity_weight*base['diversity_bonus']
    return base.sort_values('final_score',ascending=False)


def acquisition(std, posterior_mean=None, prior_mean=None, prior_std=0.05, lam=0.7):
    return point_acquisition(std,posterior_mean,prior_mean,prior_std,lam)


def select_group(candidate_df, scores, group_cols=('temperature_c','sample_id')):
    tmp=candidate_df.copy(); tmp['_score']=scores
    ranked=tmp.groupby(list(group_cols))['_score'].mean().sort_values(ascending=False)
    return ranked.index[0]
