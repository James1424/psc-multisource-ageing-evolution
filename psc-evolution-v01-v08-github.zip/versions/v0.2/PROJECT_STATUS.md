# Project status — v0.2

## What changed from v0.1

v0.2 turns the prototype into an explicit prior-transfer / prior-falsification benchmark.

1. **Hartono FPCA prior** now carries both a mean trajectory and empirical trajectory uncertainty.
2. Hartono normalization uses a robust **first-12-h 90th-percentile baseline**. This fixes a real source-domain light-soaking/ramp artefact that previously produced an implausible mean prior above 1.7.
3. **Chakar 2025** continuous outdoor MPP traces are converted into a weak daily high-quantile degradation shape (421 daily points, about 10,272 h). It is not pooled row-wise with Accelerated data.
4. Hartono and Chakar are treated as **separate frozen source priors** with transparent trust weights `w_h`, `w_c` calibrated only on the currently revealed target devices.
5. Source shapes are transferred on **dimensionless protocol progress (0–1)**. Absolute time/temperature are not borrowed from Hartono, because its ~150 h source horizon is not a valid lifetime scale for Accelerated-v2 (up to ~2291 h at 25 °C).
6. Temperature enters the target GP through an Arrhenius-motivated coordinate, but because Accelerated-v1 is not available, this is intentionally only a structural feature rather than a source-learned thermal prior.
7. Added wrong-prior stress tests and four retrospective AL strategies: random, uncertainty, prior disagreement, hybrid.
8. Added paper-style learning-curve plots and grouped device-level evaluation.

## Real-data facts confirmed

- Hartono: 2,245 ageing trajectories.
- Hartono 6-component FPCA explained variance after corrected normalization: about 99.06%, 0.52%, 0.24%, 0.067%, 0.040%, 0.021%.
- Accelerated-v2 upload: 25/35/45/55/65 °C; 144 pixel traces; 39 temperature-device groups.
- Median device durations: 25 °C 2291 h; 35 °C 1201 h; 45 °C 452 h; 55 °C 315 h; 65 °C 167 h.
- Chakar upload: three continuous outdoor MPP channels plus indoor/outdoor J–V and irradiance/cell-temperature data.
- Derived Chakar weak shape: 421 daily points spanning ~10,272 h.

## v0.2 quick benchmark (real data; 25 °C fully held out)

Quick mode uses two random seeds and is a smoke/diagnostic experiment, **not a publication claim**.

### 6 revealed non-25 °C devices

- target-only GP: mean RMSE ~0.169
- fixed Hartono shape prior + residual GP: mean RMSE ~0.150
- wrong/inverted prior: mean RMSE ~0.201 in the explicit reversed-shape stress test

Interpretation: a source trajectory prior can help in the very-low-label regime, and a deliberately wrong prior hurts. This is exactly the regime the thesis hypothesis targets.

### 12 revealed devices

- target-only GP: mean RMSE ~0.164
- fixed Hartono prior: mean RMSE ~0.196

Interpretation: transfer is **not uniformly beneficial**. Once more target data are available, source mismatch can cause negative transfer. A credible paper must therefore learn/attenuate source trust rather than assume `physics prior = always good`.

### Chakar trust

The direct Chakar outdoor-shape prior is generally assigned little/no weight in the current target calibration. This is scientifically plausible because outdoor irradiance-driven ageing and accelerated indoor cycling are different protocols. It is retained as a falsifiable source expert, not forced into the predictor.

## v0.2 quick retrospective Active Learning

All strategies share the same initial devices for a seed. Whole device groups are revealed; pixels are never split across train/test.

Mean 25 °C RMSE in quick mode:

| revealed devices | random | uncertainty | disagreement | hybrid |
|---:|---:|---:|---:|---:|
| 6 | ~0.150 | ~0.150 | ~0.150 | ~0.150 |
| 8 | ~0.157 | ~0.148 | ~0.135 | ~0.135 |
| 9 | ~0.160 | ~0.153 | ~0.135 | ~0.135 |
| 10 | ~0.158 | ~0.134 | ~0.139 | ~0.139 |

Interpretation: prior disagreement is promising early, but not monotonically superior. The next methodological target is a probabilistic source-weight posterior / cost-aware expected information gain, not more model complexity.

## Important limitations

1. **No Accelerated-v1 source** is included. Therefore the thermal relation is not a source-learned Arrhenius prior yet.
2. Chakar daily high-quantile Pmax is only a weak outdoor shape proxy; it must not be interpreted as a direct PCE-retention label equivalent to Accelerated-v2.
3. Target-device count is small. Full experiments require repeated seeds and confidence intervals.
4. GP kernel convergence warnings occur in some small-label fits. They are retained because they diagnose weak identifiability; future work should compare Student-t / sparse GP or hierarchical Bayesian alternatives.
5. The quick results are diagnostic only. Run full mode before any scientific claim.

## Recommended next step

The cleanest v0.3 upgrade is to add **Accelerated-v1** as a genuinely independent thermal source and replace grid source weights with a hierarchical Bayesian posterior. Then compare sample efficiency `N_epsilon` against target-only GP, uncertainty AL, and an optional LLM-AL baseline.
