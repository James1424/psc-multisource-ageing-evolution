import numpy as np,pandas as pd
from psc_prior_al.priors import combine_source_priors,arrhenius_acceleration

def test_prior_weights_convex():
    h=np.array([1.,.8]); c=np.array([1.,.6])
    y=combine_source_priors(h,c,.5,.25)
    assert np.allclose(y,.25*1+.5*h+.25*c)

def test_arrhenius_increases_with_temperature():
    a=arrhenius_acceleration([25,45,65])
    assert np.all(np.diff(a)>0)
