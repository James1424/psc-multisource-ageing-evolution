# Multi-Source Prior Active Learning for Perovskite Ageing — v0.2

A research prototype for testing whether **frozen, explicit priors distilled from heterogeneous perovskite ageing datasets** can improve small-label degradation learning and retrospective active experiment selection.

The design deliberately avoids row-wise pooling across incompatible datasets.

## Data roles

- **Hartono ageing dataset** → generic trajectory-shape FPCA prior + source uncertainty.
- **Chakar 2025 outdoor/indoor dataset** → independent weak outdoor degradation-shape expert; allowed to receive zero target trust.
- **Accelerated ageing v2** → sole target domain and retrospective AL oracle.

Because Accelerated-v1 is not included, v0.2 does **not** claim to have learned an external thermal Arrhenius prior. Temperature is represented by an Arrhenius-motivated target feature only.

## Core model

The target model is

`retention(t,T) = source_prior(progress) + GP_residual(log time, Arrhenius coordinate)`.

Source prior trust is explicit and falsifiable. The pipeline can learn to attenuate a mismatched source rather than forcing it into the target model.

## Leakage rules

- Split/query unit = `(temperature, parent sample/device)`.
- Pixels from one parent sample are aggregated before modeling.
- 25 °C can be held out as a full external temperature domain.
- Hartono/Chakar source functions are built without Accelerated-v2 labels.
- Target labels may calibrate **trust weights**, but never reconstruct the frozen source function itself.

## Put the three raw files here

```text
data/raw/
├── 20230303_mySeriesDrop.pkl
├── dataset_SAM.zip
└── chakar_2025.zip
```

The uploaded Chakar archive can simply be renamed to `chakar_2025.zip`.

## GitHub Codespaces

Open the repository in Codespaces. The devcontainer installs the dependencies automatically.

Run a fast real-data smoke test:

```bash
python scripts/01_audit_data.py
python scripts/02_build_priors.py
python scripts/03_run_benchmark.py --quick
python scripts/04_run_active_learning.py --quick
python scripts/05_make_report.py
```

Run the configured full experiment:

```bash
python scripts/03_run_benchmark.py
python scripts/04_run_active_learning.py
python scripts/05_make_report.py
```

## Main outputs

```text
results/
├── benchmark_v02.csv
├── benchmark_v02_summary.csv
├── active_learning_v02.csv
├── active_learning_selections_v02.csv
├── active_learning_v02_summary.csv
├── benchmark_learning_curves.png
└── active_learning_curves.png
```

Processed source artifacts include `hartono_pca.joblib`, `chakar_daily_shape.csv`, device-aggregated Accelerated trajectories, and the audit inventory.

## Benchmarks in v0.2

Prediction benchmark:

- target-only GP
- fixed Hartono-shape prior + GP residual
- adaptive multi-source prior + GP residual
- wrong-activation-energy stress tests
- explicitly reversed/wrong source-shape stress test

Retrospective Active Learning:

- random
- posterior uncertainty
- source-prior disagreement
- hybrid = uncertainty + disagreement + temperature balance + metadata diversity

## Scientific interpretation

The intended thesis claim is **not** “more datasets always improve performance”. The testable claim is narrower:

> In the very-low-label regime, can an explicit source trajectory prior reduce target sample requirements, while an adaptive/falsifiable mechanism prevents negative transfer when the source becomes unhelpful?

See `PROJECT_STATUS.md` for the current real-data results and limitations.
