from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence
import numpy as np
import pandas as pd


META_CANDIDATES = (
    'temperature_c','progress','stress_h','time_h','illumination_sun','rh','humidity','protocol_code'
)


@dataclass
class DiffractionSource:
    available: bool
    mode: str
    feature_cols: tuple[str, ...]
    context_cols: tuple[str, ...]
    table: pd.DataFrame | None = None
    reason: str = ''


def load_diffraction_source(path: str | Path | None) -> DiffractionSource:
    """Load a *derived* diffraction source table, never fabricate missing diffraction.

    Supported table semantics
    -------------------------
    Each row is one diffraction observation or prototype.  Columns may include contextual
    variables (temperature_c, progress, stress_h, time_h, ...), plus either interpretable
    descriptors prefixed ``xrd_``/``giwaxs_`` or learned embeddings prefixed ``z_``.

    The table does NOT need row-wise alignment to Accelerated-v2.  It is treated as an external
    structural source and transferred through contextual kernel retrieval.
    """
    if path is None:
        return DiffractionSource(False,'missing',(),(),None,'no path supplied')
    p=Path(path)
    if not p.exists():
        return DiffractionSource(False,'missing',(),(),None,f'{p} not found')
    if p.suffix.lower() in {'.csv','.txt'}:
        df=pd.read_csv(p)
    elif p.suffix.lower() in {'.parquet'}:
        df=pd.read_parquet(p)
    else:
        return DiffractionSource(False,'unsupported',(),(),None,'expected derived CSV/Parquet embeddings or descriptors')
    feats=[c for c in df.columns if c.startswith(('xrd_','giwaxs_','z_'))]
    ctx=[c for c in META_CANDIDATES if c in df.columns]
    if not feats:
        return DiffractionSource(False,'invalid',(),tuple(ctx),df,'no xrd_/giwaxs_/z_ feature columns')
    feats=[c for c in feats if pd.api.types.is_numeric_dtype(df[c])]
    if not feats:
        return DiffractionSource(False,'invalid',(),tuple(ctx),df,'no numeric diffraction features')
    return DiffractionSource(True,'external_unpaired',tuple(feats),tuple(ctx),df,'ok')


def target_context(df: pd.DataFrame, ea_ev: float=0.45) -> pd.DataFrame:
    """Context coordinates already observable in the target experiment (label-free)."""
    out=pd.DataFrame(index=df.index)
    out['temperature_c']=df.temperature_c.to_numpy(float)
    out['time_h']=df.time_h.to_numpy(float)
    # device-wise progress is label-free
    prog=np.zeros(len(df),float)
    for _,idx in df.groupby(['temperature_c','sample_id']).indices.items():
        ii=np.asarray(idx,dtype=int); t=df.iloc[ii].time_h.to_numpy(float)
        prog[ii]=t/max(float(np.nanmax(t)),1.0)
    out['progress']=np.clip(prog,0,1)
    # Arrhenius-inspired equivalent stress coordinate; only a context coordinate, not a hard law
    kb=8.617333262145e-5
    T=out.temperature_c.to_numpy()+273.15
    Tr=25.0+273.15
    acc=np.exp(-ea_ev/kb*(1.0/T-1.0/Tr))
    out['stress_h']=np.maximum(out.time_h.to_numpy(float)*acc,0.0)
    return out


def _robust_scale(a: np.ndarray):
    med=np.nanmedian(a,axis=0)
    q1=np.nanquantile(a,.25,axis=0); q3=np.nanquantile(a,.75,axis=0)
    scl=q3-q1; scl=np.where(np.isfinite(scl)&(scl>1e-8),scl,1.0)
    return med,scl


def contextual_retrieve(df_target: pd.DataFrame, source: DiffractionSource, ea_ev: float=0.45,
                        bandwidth: float=1.0, max_features: int=8):
    """Project an unpaired diffraction source into target context.

    Returns
    -------
    z_mean : target-row structural embedding inferred by kernel retrieval
    z_unc  : scalar retrieval uncertainty (variance + context-distance penalty)
    support: effective local source support in [0,1]

    If diffraction is unavailable, returns zero features and support=0.  This is deliberate:
    missing diffraction is not imputed from ageing labels.
    """
    n=len(df_target)
    if not source.available or source.table is None:
        return np.zeros((n,0)),np.ones(n),np.zeros(n)
    tab=source.table.copy()
    ctx_t=target_context(df_target,ea_ev)
    common=[c for c in source.context_cols if c in ctx_t.columns]
    feats=list(source.feature_cols)[:max_features]
    Z=tab[feats].to_numpy(float)
    good=np.all(np.isfinite(Z),axis=1)
    if common:
        C=tab[common].to_numpy(float); good &= np.all(np.isfinite(C),axis=1)
    if not np.any(good):
        return np.zeros((n,len(feats))),np.ones(n),np.zeros(n)
    Z=Z[good]
    if not common:
        mu=np.nanmean(Z,axis=0); var=np.nanmean((Z-mu)**2,axis=0)
        return np.repeat(mu[None,:],n,axis=0),np.repeat(float(np.mean(var)),n),np.repeat(min(1.,len(Z)/50.),n)
    C=tab.loc[good,common].to_numpy(float); Ct=ctx_t[common].to_numpy(float)
    med,scl=_robust_scale(C); Cn=(C-med)/scl; Ctn=(Ct-med)/scl
    # standardized structure features so one latent dimension cannot dominate
    zm,zs=_robust_scale(Z); Zn=(Z-zm)/zs
    out=np.zeros((n,Zn.shape[1])); unc=np.zeros(n); support=np.zeros(n)
    bw=max(float(bandwidth),1e-4)
    for i,x in enumerate(Ctn):
        d2=np.sum((Cn-x[None,:])**2,axis=1)
        w=np.exp(-0.5*d2/(bw*bw))
        sw=float(np.sum(w))
        if sw<1e-12:
            j=int(np.argmin(d2)); out[i]=Zn[j]; unc[i]=1.+float(np.sqrt(d2[j])); support[i]=0.
            continue
        w=w/sw; mu=np.sum(w[:,None]*Zn,axis=0); var=np.sum(w[:,None]*(Zn-mu)**2,axis=0)
        out[i]=mu
        neff=1.0/max(float(np.sum(w*w)),1e-12)
        dbar=float(np.sum(w*np.sqrt(np.maximum(d2,0))))
        unc[i]=float(np.mean(var))+dbar/(1.+dbar)
        support[i]=float((1.-np.exp(-neff/5.0))*np.exp(-dbar/4.0))
    return out,unc,np.clip(support,0,1)


def availability_gate(uncertainty: np.ndarray, support: np.ndarray, tau: float=1.0):
    """Trust diffraction only where context retrieval is supported and not uncertain."""
    u=np.asarray(uncertainty,float); s=np.asarray(support,float)
    return np.clip(s*np.exp(-u/max(float(tau),1e-6)),0,1)


def write_template(path: str | Path):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    cols=['temperature_c','time_h','progress','stress_h','giwaxs_phase_purity','giwaxs_orientation','giwaxs_peak_width','giwaxs_strain','z_0','z_1']
    pd.DataFrame(columns=cols).to_csv(p,index=False)
    return p
