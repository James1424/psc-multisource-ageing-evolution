import numpy as np, pandas as pd
from psc_prior_al.optional_diffraction import load_diffraction_source,contextual_retrieve,availability_gate


def _target():
    return pd.DataFrame({'temperature_c':[35.,45.],'sample_id':[1.,2.],'time_h':[10.,20.]})


def test_missing_diffraction_is_exactly_gated_off(tmp_path):
    src=load_diffraction_source(tmp_path/'missing.csv')
    z,u,s=contextual_retrieve(_target(),src)
    assert z.shape==(2,0)
    assert np.allclose(s,0)
    assert np.allclose(availability_gate(u,s),0)


def test_external_diffraction_context_retrieval(tmp_path):
    p=tmp_path/'d.csv'
    pd.DataFrame({
        'temperature_c':[35.,45.,55.], 'time_h':[10.,20.,30.],
        'giwaxs_phase_purity':[.8,.7,.5], 'z_0':[0.,1.,2.]
    }).to_csv(p,index=False)
    src=load_diffraction_source(p)
    z,u,s=contextual_retrieve(_target(),src)
    assert src.available
    assert z.shape==(2,2)
    assert np.all(np.isfinite(z))
    assert np.all((s>=0)&(s<=1))
