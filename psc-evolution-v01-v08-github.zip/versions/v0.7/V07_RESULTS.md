# v0.7 preliminary result — optional diffraction source

## Data availability in this run
No real diffraction/GIWAXS/XRD source table was supplied by the user in this iteration.
Therefore the structural source D is marked unavailable.  The code does **not** synthesize D
from ageing labels or from Hartono/Chakar.

## External 25 C audit (3 device-split seeds, N=12)

| model | mean RMSE | std | mean D gate |
|---|---:|---:|---:|
| v0.6 no diffraction | 0.10771 | 0.01841 | 0 |
| v0.7 optional diffraction | 0.10771 | 0.01841 | 0 |

The numerical equality is an intentional safety property: when diffraction evidence is missing,
the expanded model class does not invent structural evidence and exactly falls back to v0.6.

## What has and has not been demonstrated
Demonstrated now:
- missing-modality safety;
- a context-conditioned interface for unpaired external diffraction embeddings/descriptors;
- uncertainty/support gating;
- compatibility with future paired or external diffraction sources without redesigning the target model.

Not demonstrated now:
- that diffraction improves PSC degradation prediction;
- which structural descriptors/pathways are most useful;
- that an external GIWAXS encoder transfers to this Accelerated-v2 target.

Those claims require real diffraction data.
