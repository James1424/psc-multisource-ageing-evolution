"""v0.7 optional diffraction/scattering source experiment.

No diffraction data are fabricated.  If ``data/raw/diffraction_source.csv`` is absent, the
structural expert is explicitly unavailable and the v0.7 predictor must reduce to the v0.6
adaptive-granularity predictor.  If a derived GIWAXS/XRD descriptor/embedding table is supplied,
its structure latent is transferred by context-kernel retrieval with an uncertainty-aware gate.

This script therefore tests the safety property today and becomes a real multimodal experiment
without changing the target-side code once diffraction data arrive.
"""
from pathlib import Path
import argparse,warnings
import numpy as np,pandas as pd,joblib
from sklearn.kernel_ridge import KernelRidge
from psc_prior_al.config import load_config,resolve
from psc_prior_al.adaptive_granularity import fit_adaptive_granularity,predict_adaptive_granularity
from psc_prior_al.optional_diffraction import load_diffraction_source,contextual_retrieve,availability_gate,write_template
warnings.filterwarnings('ignore')


def thin(df,maxn=6):
    out=[]
    for _,g in df.groupby(['temperature_c','sample_id']):
        g=g.sort_values('time_h'); i=np.unique(np.linspace(0,len(g)-1,min(maxn,len(g))).round().astype(int)); out.append(g.iloc[i])
    return pd.concat(out,ignore_index=True)

def rmse(y,p): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))

def device_context_features(df, z, gate):
    # row features for a residual structural correction; multiplied by gate so unsupported regions vanish
    if z.shape[1]==0: return np.zeros((len(df),0))
    return np.c_[z*gate[:,None], gate[:,None]]

def fit_diffraction_residual(train, residual, z, gate, alpha=0.5):
    X=device_context_features(train,z,gate)
    if X.shape[1]==0 or np.max(gate)<1e-8:
        return None
    m=KernelRidge(alpha=alpha,kernel='rbf',gamma=0.5)
    m.fit(X,residual)
    return m

def predict_diffraction_residual(model,df,z,gate):
    if model is None: return np.zeros(len(df))
    return model.predict(device_context_features(df,z,gate))


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seeds',type=int,default=3); ap.add_argument('--n',type=int,default=12); ap.add_argument('--diffraction',default='data/raw/diffraction_source.csv'); a=ap.parse_args()
    c=load_config('configs/default.yaml'); root=Path('.'); proc=resolve(root,c['paths']['processed']); res=resolve(root,c['paths']['results']); res.mkdir(exist_ok=True)
    d=pd.read_csv(proc/'accelerated_device_curves.csv.gz'); hp=joblib.load(proc/'hartono_pca.joblib'); cs=pd.read_csv(proc/'chakar_daily_shape.csv'); cstress=pd.read_csv(proc/'chakar_stress_shape.csv'); ea=float(c['model']['arrhenius_ea_ev_prior']); hold=float(c['benchmark']['holdout_temperature_c'])
    test=thin(d[d.temperature_c==hold]); pool=d[d.temperature_c!=hold]; groups=pool[['temperature_c','sample_id']].drop_duplicates().reset_index(drop=True)
    src=load_diffraction_source(a.diffraction)
    if not src.available:
        write_template('data/raw/diffraction_source_TEMPLATE.csv')
    rows=[]
    for seed in range(a.seeds):
        rng=np.random.default_rng(seed); ch=groups.iloc[rng.choice(len(groups),a.n,replace=False)]; tr=thin(pool.merge(ch,on=['temperature_c','sample_id']))
        fg=fit_adaptive_granularity(tr,hp,cs,cstress,ea_ev=ea,maxiter=16)
        p6,_,_=predict_adaptive_granularity(tr,test,fg,hp,cs,cstress,ea_ev=ea)
        # fit/predict v0.6 on training rows for structural residual target
        p6tr,_,_=predict_adaptive_granularity(tr,tr,fg,hp,cs,cstress,ea_ev=ea)
        ztr,utr,str_=contextual_retrieve(tr,src,ea_ev=ea); zte,ute,ste=contextual_retrieve(test,src,ea_ev=ea)
        gtr=availability_gate(utr,str_); gte=availability_gate(ute,ste)
        dm=fit_diffraction_residual(tr,tr.retention.to_numpy(float)-p6tr,ztr,gtr)
        delta=predict_diffraction_residual(dm,test,zte,gte)
        # safety blend: structural correction cannot act where source support is absent
        local_gate=gte
        p7=p6+local_gate*delta
        rows += [
            {'seed':seed,'train_devices':a.n,'model':'v06_no_diffraction','rmse_25C':rmse(test.retention,p6),'diffraction_available':float(src.available),'mean_D_gate':0.0},
            {'seed':seed,'train_devices':a.n,'model':'v07_optional_diffraction','rmse_25C':rmse(test.retention,p7),'diffraction_available':float(src.available),'mean_D_gate':float(np.mean(gte))},
        ]
    out=pd.DataFrame(rows); out.to_csv(res/'optional_diffraction_v07.csv',index=False)
    summ=out.groupby('model').agg(rmse=('rmse_25C','mean'),std=('rmse_25C','std'),D_available=('diffraction_available','mean'),D_gate=('mean_D_gate','mean')).reset_index(); summ.to_csv(res/'optional_diffraction_v07_summary.csv',index=False)
    print('Diffraction source:',src.mode,src.reason,'features=',src.feature_cols,'context=',src.context_cols)
    print(summ.round(5).to_string(index=False))
    if not src.available: print('Safety result expected: v0.7 == v0.6 exactly because no diffraction evidence is fabricated.')

if __name__=='__main__': main()
