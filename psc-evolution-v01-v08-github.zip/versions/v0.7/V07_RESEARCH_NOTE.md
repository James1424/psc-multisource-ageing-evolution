# v0.7 — Optional Structural-Scattering Expert

## Why this version exists
GIWAXS/XRD is scientifically important for perovskite structure, phase evolution, orientation,
strain and degradation.  However, diffraction is often unavailable for the exact devices and
time points used in ageing datasets.  Row-wise concatenation would therefore be methodologically
wrong and would sharply reduce the heterogeneous-data generality of the project.

v0.7 treats diffraction as an **optional structural expert D**, not as a mandatory target feature.

## Three admissible data regimes
1. **Paired D**: diffraction is measured on the same sample/time point.  D can enter as a local
   structural state.
2. **Unpaired external D**: public/group GIWAXS/XRD is pre-trained or featurized independently,
   then projected into target contexts by kernel retrieval over experimental context.
3. **Missing D**: no diffraction evidence exists.  D paths are exactly shut off; the model reduces
   to v0.6.  Missing diffraction is never synthesized from target ageing labels.

## Structural source representation
Raw diffraction should be converted to either interpretable descriptors (phase fraction/purity,
q-position, FWHM, orientation/texture, strain, peak-ratio, scattering anisotropy) or self-supervised
embeddings z_D.  The current code accepts columns prefixed `xrd_`, `giwaxs_`, or `z_`.

For an external unpaired source with context c_j and embedding z_j, target context x receives

    z_D(x) = sum_j w_j(x) z_j,
    w_j(x) ∝ exp[-||c(x)-c_j||^2/(2 l_c^2)].

A retrieval uncertainty U_D and effective support S_D are calculated.  The structural gate is

    g_D(x) = S_D(x) exp[-U_D(x)/tau].

Hence diffraction can affect a target prediction only where the external structural database
actually overlaps the target context.

## Proposed full future kernel graph
v0.6 pathways remain untouched.  With D available, add separate pathway families:

- D_global
- D_phase
- D_context
- D_fine
- D × B (structure modifies thermal/stress response)
- D × H, D × C (structure mediates other source priors)
- H × C × D and D × B × progress only when transfer-CV justifies the added granularity.

This is intentionally pathway-level, because diffraction may be harmful as a direct predictor but
useful as a mediator of temperature/stress susceptibility.

## Safety property tested now
Without a diffraction source file, v0.7 must numerically equal v0.6.  This is a unit-level design
requirement, not a claim that future diffraction will improve the external test.

## Recommended data acquisition order
1. Do **not** wait for perfectly paired ageing+GIWAXS data.
2. Obtain any group/public GIWAXS/XRD first and pretrain/freeze a structure encoder.
3. Prefer a small calibration set (even 10–30 paired conditions) spanning temperature, ageing
   stage and representative compositions over many redundant images from one condition.
4. If the group can measure new data, use active acquisition on contexts with high structural
   uncertainty and high expected impact on degradation prediction.

## Literature-aligned next step
A large 2026 public benchmark contains 22,266 GIWAXS images from OPV/perovskite thin films and
explicitly includes transfer-learning utilities.  This is a plausible external pretraining source,
but it is ~7.6 GB curated and should be downloaded separately rather than silently bundled here.
Self-supervised diffraction representation learning (Crystals 2025) is particularly relevant when
property labels are scarce.
